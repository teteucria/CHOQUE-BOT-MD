const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");

const { builtinModules } = require("module");
const BUILTINS = new Set(builtinModules);

const ROOT = path.resolve(__dirname, "..");
const PKG_FILE = path.join(ROOT, "package.json");
const SCAN_DIRS = ["src", "arquivos", "settings"];
const DRY_RUN = process.argv.includes("--dry-run") || process.argv.includes("--preview");

function log(msg) {
  process.stdout.write(msg + "\n");
}

function normalize(spec) {
  if (spec.startsWith("node:") || BUILTINS.has(spec)) return null;
  if (spec.startsWith("@")) return spec.split("/").slice(0, 2).join("/");
  return spec.split("/")[0];
}

function collectReferences() {
  const refs = new Set();

  function walk(dir) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile() && /\.(js|mjs|cjs|ts|json)$/.test(entry.name)) {
        const code = fs.readFileSync(full, "utf8");
        const patterns = [
          /require\(\s*["']([^"']+)["']\s*\)/g,
          /\bfrom\s*["']([^"']+)["']/g,
          /\bimport\(\s*["']([^"']+)["']\s*\)/g
        ];
        for (const re of patterns) {
          let match;
          while ((match = re.exec(code))) {
            const name = normalize(match[1]);
            if (name) refs.add(name);
          }
        }
      }
    }
  }

  for (const dir of SCAN_DIRS) walk(path.join(ROOT, dir));
  return refs;
}

function protectedPackages() {
  const keep = new Set();
  const pkg = JSON.parse(fs.readFileSync(PKG_FILE, "utf8"));
  const direct = {
    ...(pkg.dependencies || {}),
    ...(pkg.devDependencies || {}),
    ...(pkg.optionalDependencies || {})
  };
  for (const name of Object.keys(direct)) {
    const pkgPath = path.join(ROOT, "node_modules", name, "package.json");
    try {
      const meta = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
      if (meta.peerDependencies) {
        for (const peer of Object.keys(meta.peerDependencies)) keep.add(peer);
      }
    } catch {}
  }
  return keep;
}

function deleteFolder(folder) {
  fs.rmSync(folder, { recursive: true, force: true });
}

function run(cmd) {
  if (DRY_RUN) {
    log(`  [simulado] ${cmd}`);
    return;
  }
  try {
    execSync(cmd, { cwd: ROOT, stdio: "inherit" });
  } catch (err) {
    process.exit(1);
  }
}

function main() {
  const pkg = JSON.parse(fs.readFileSync(PKG_FILE, "utf8"));
  const allDeps = {
    ...(pkg.dependencies || {}),
    ...(pkg.devDependencies || {}),
    ...(pkg.optionalDependencies || {})
  };

  log("==> Analisando imports/requires do codigo-fonte...");
  const used = collectReferences();
  const keep = protectedPackages();

  const unused = Object.keys(allDeps).filter((dep) => !used.has(dep) && !keep.has(dep));

  if (unused.length === 0) {
    log("  Nenhum modulo sem uso encontrado.");
  } else {
    log(`  Modulos sem uso detectados:`);
    for (const dep of unused) log(`    - ${dep}`);
    log(`\n==> Desinstalando ${unused.length} modulo(s)...`);
    run(`npm uninstall ${unused.join(" ")} --no-bin-links`);
  }

  log("\n==> Limpando cache do node_modules...");
  const cacheDir = path.join(ROOT, "node_modules", ".cache");
  if (fs.existsSync(cacheDir)) {
    log(`  Removendo node_modules/.cache (${cacheDir})`);
    if (!DRY_RUN) deleteFolder(cacheDir);
  } else {
    log("  node_modules/.cache nao encontrado.");
  }

  log("  Limpando cache global do npm...");
  run("npm cache clean --force");

  log("\n==> Limpeza concluida.");
  const size = execSync("du -sh node_modules 2>/dev/null || echo '0'", { encoding: "utf8" }).trim();
  log(`Tamanho final do node_modules: ${size}`);
}

main();
