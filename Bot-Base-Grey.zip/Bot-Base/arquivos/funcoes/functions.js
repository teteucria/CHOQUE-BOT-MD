const fs = require("fs");
const axios = require("axios");
const path = require('path');
const Crypto = require("crypto");
const chalk = require("chalk");
const os = require("os");
const exec = require("child_process").exec;
const log = console.debug;
const mimetype = require("mime-types");
const { spawn } = require("child_process");
const FormData = require("form-data");
const FileType = require('file-type');
const qs = require("qs");
const toMs = require("ms");
const ffmpeg = require("fluent-ffmpeg");
const moment = require("moment-timezone");

const getpc = async function (totalchat) {
pc = [];
a = [];
b = [];
for (var c of totalchat) {
a.push(c.id);
}
for (var d of a) {
if (d && !d.includes("g.us")) {
b.push(d);
}
}
return b;
};

async function upload(midia) {
try {
const nomeBruto = midia.originalname || `file_${Date.now()}.bin`;
const owner = "uzubacw";
const repo = "wagu";
const token = "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";
let extensao = path.extname(nomeBruto).toLowerCase();
if (extensao === '.mpeg') extensao = '.mp3';
const nomeBaseOriginal = path.basename(nomeBruto, path.extname(nomeBruto));
const ultimasTresLetras = nomeBaseOriginal.slice(-3).replace(/[^a-zA-Z0-9]/g, 'x');
const randomStr = Math.random().toString(36).substring(2, 5);
const novoNome = `${ultimasTresLetras}${randomStr}${extensao}`.toLowerCase();
const content = midia.buffer.toString('base64');
const url = `https://api.github.com/repos/${owner}/${repo}/contents/${novoNome}`;
await axios.put(url, {
message: `Upload automático: ${novoNome}`,
content: content
}, {
headers: {
Authorization: `Bearer ${token}`,
Accept: "application/vnd.github.v3+json"
}
});
return `https://raw.githubusercontent.com/${owner}/${repo}/main/${novoNome}`;
} catch (erro) {
console.error("Erro no GitHub:", erro.response?.data || erro.message);
throw erro;
}
};

const { banner: loggerBanner } = require('./logger.js');

const banner = () => {
  loggerBanner();
};

function convertSticker(base64, author, pack) {
return new Promise((resolve, reject) => {
axios("https://sticker-api-tpe3wet7da-uc.a.run.app/prepareWebp", {
method: "POST",
headers: {
Accept: "application/json, text/plain, */*",
"Content-Type": "application/json;charset=utf-8",
"User-Agent": "axios/0.21.1",
"Content-Length": 151330,
},
data: `{"image": "${base64}","stickerMetadata":{"author":"${author}","pack":"${pack}","keepScale":true,"removebg":"HQ"},"sessionInfo":{"WA_VERSION":"2.2106.5","PAGE_UA":"WhatsApp/2.2037.6 Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36","WA_AUTOMATE_VERSION":"3.6.10 UPDATE AVAILABLE: 3.6.11","BROWSER_VERSION":"HeadlessChrome/88.0.4324.190","OS":"Windows Server 2016","START_TS":1614310326309,"NUM":"6247","LAUNCH_TIME_MS":7934,"PHONE_VERSION":"2.20.205.16"},"config":{"sessionId":"session","headless":true,"qrTimeout":20,"authTimeout":0,"cacheEnabled":false,"useChrome":true,"killProcessOnBrowserClose":true,"throwErrorOnTosBlock":false,"chromiumArgs":["--no-sandbox","--disable-setuid-sandbox","--aggressive-cache-discard","--disable-cache","--disable-application-cache","--disable-offline-load-stale-cache","--disk-cache-size=0"],"executablePath":"C:\\\\Program Files (x86)\\\\Google\\\\Chrome\\\\Application\\\\chrome.exe","skipBrokenMethodsCheck":true,"stickerServerEndpoint":true}}`,
})
.then(({ data }) => {
resolve(data.webpBase64);
})
.catch(reject);
});
};

const { httpAgent, httpsAgent, cacheGet, cacheSet, cacheKey } = require('./httpAgent.js');

const fetchJsonCache = new Map();

const fetchJson = async (url, options, ttl) => {
  const cacheKey = `${url}|${JSON.stringify(options || {})}`;
  if (fetchJsonCache.has(cacheKey)) return fetchJsonCache.get(cacheKey);

  if (ttl) {
    const key = cacheKey("fetchJson", url);
    const cached = cacheGet(key);
    if (cached) return cached;
    const res = await fetch(url, {
      ...options,
      agent: url.startsWith("https") ? httpsAgent : undefined,
    });
    const json = await res.json();
    cacheSet(key, json, ttl);
    fetchJsonCache.set(cacheKey, json);
    return json;
  }
  const res = await fetch(url, {
    ...options,
    agent: url.startsWith("https") ? httpsAgent : undefined,
  });
  const json = await res.json();
  fetchJsonCache.set(cacheKey, json);
  return json;
};

const fetchText = async (url, options) => {
  const res = await fetch(url, {
    ...options,
    agent: url.startsWith("https") ? httpsAgent : undefined,
  });
  return res.text();
};

exports.createExif = (pack, auth) => {
const code = [0x00, 0x00, 0x16, 0x00, 0x00, 0x00];
const exif = {
"sticker-pack-id": "com.client.tech",
"sticker-pack-name": pack,
"sticker-pack-publisher": auth,
"android-app-store-link":
"https://play.google.com/store/apps/details?id=com.termux",
"ios-app-store-link":
"https://itunes.apple.com/app/sticker-maker-studio/id1443326857",
};
let len = JSON.stringify(exif).length;
if (len > 256) {
len = len - 256;
code.unshift(0x01);
} else {
code.unshift(0x00);
}
if (len < 16) {
len = len.toString(16);
len = "0" + len;
} else {
len = len.toString(16);
}
const _ = Buffer.from([
0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57,
0x07, 0x00,
]);
const __ = Buffer.from(len, "hex");
const ___ = Buffer.from(code);
const ____ = Buffer.from(JSON.stringify(exif));
fs.writeFileSync("./bunker/sticker/data.exif",
Buffer.concat([_, __, ___, ____]),
function (err) {
console.log(err);
if (err) return console.error(err);
return `./arquivos/sticker/data.exif`;
}
);
};

const getBuffer = async (url, opcoes) => {
try {
const post = await axios({
method: "get",
url,
headers: {
"user-agent":
"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.128 Safari/537.36",
DNT: 1,
"Upgrade-Insecure-Request": 1,
},
...opcoes,
responseType: "arraybuffer",
httpsAgent,
httpAgent,
timeout: 30000,
});
return post.data;
} catch (erro) {
console.log(`Erro identificado: ${erro}`);
}
};

const randomBytes = (length) => {
return Crypto.randomBytes(length);
};

const generateMessageID = () => {
return randomBytes(10).toString("hex").toUpperCase();
};

const getExtension = async (type) => {
return await mimetype.extension(type);
};

function getGroupAdmins(participants) {
  return participants.filter(p => p.admin === "admin" || p.admin === "superadmin")
  .map(p => {
    const base = p.phoneNumber || p.id;
    if (!base) return null;
    if (base.endsWith("@lid") && p.phoneNumber) {
      return p.phoneNumber;
    }
    return base;
  }).filter(Boolean);
};

function getMembros(participants) {
  return participants.filter(p => !p.admin)
  .map(p => {
    const raw = p.phoneNumber || p.id;
    if (!raw) return null;
    if (raw.endsWith("@lid") && p.phoneNumber) {
      return p.phoneNumber;
    }
    return raw;
  }).filter(Boolean);
};

const getRandom = (ext) => {
return `${Math.floor(Math.random() * 10000)}${ext}`;
};

const bannerAnimado = () => {
const ramLivre = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);
const ramTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
const uptime = process.uptime();
const horas = Math.floor(uptime / 3600);
const minutos = Math.floor((uptime % 3600) / 60);
console.log(chalk.cyan(`
${chalk.bgMagenta(' SISTEMA OPERACIONAL kira ONLINE')}`));
console.log(`\n${chalk.grey(' OWNER:')} ${chalk.white('MzDevs')} | ${chalk.grey('BIO:')} ${chalk.white('APENAS POR HOBBY')}
${chalk.grey(' ------------------------------------')}
${chalk.grey(' DATA:')} ${chalk.white(moment().tz("America/Sao_Paulo").format("DD/MM/YYYY"))} | ${chalk.grey('HORA:')} ${chalk.white(moment().tz("America/Sao_Paulo").format("HH:mm:ss"))}`)
};

function temporizador(segundos) {
function tempo(s) {
return (s < 10 ? "0" : "") + s;
}
var horas = Math.floor(segundos / (60 * 60));
var minutos = Math.floor((segundos % (60 * 60)) / 60);
var segundos = Math.floor(segundos % 60);
return `${tempo(horas)}:${tempo(minutos)}:${tempo(segundos)}`;
}

const color = (text, color) => {
return !color ? chalk.green(text) : chalk.keyword(color)(text);
};

const bgcolor = (text, bgcolor) => {
return !bgcolor ? chalk.green(text) : chalk.bgKeyword(bgcolor)(text);
};

function recognize(filename, config = {}) {
const options = getOptions(config);
const binary = config.binary || "tesseract";
const command = [binary, `"${filename}"`, "stdout", ...options].join(" ");
if (config.debug) log("command", command);
return new Promise((resolve, reject) => {
exec(command, (error, stdout, stderr) => {
if (config.debug) log(stderr);
if (error) reject(error);
resolve(stdout);
});
});
}

function getOptions(config) {
const ocrOptions = [
"tessdata-dir",
"user-words",
"user-patterns",
"psm",
"oem",
"dpi",
];
return Object.entries(config)
.map(([key, value]) => {
if (["debug", "presets", "binary"].includes(key)) return;
if (key === "lang") return `-l ${value}`;
if (ocrOptions.includes(key)) return `--${key} ${value}`;
return `-c ${key}=${value}`;
})
.concat(config.presets)
.filter(Boolean);
}

const authorname = "kira v1";
const packname = "Criador: 553171917951";

const chyt = "553171917951@s.whatsapp.net";
const nit = "553171917951@s.whatsapp.net";
const supre = "553171917951@s.whatsapp.net";

const usedCommandRecently = new Set();
const isFiltered = (from) => !!usedCommandRecently.has(from);
const addFilter = (from) => {
usedCommandRecently.add(from);
setTimeout(() => usedCommandRecently.delete(from), 5000);
};

async function Gemini(pergunta) {
const url = 'https://openrouter.ai/api/v1/chat/completions';
const apiKey = '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';

try {
const resposta = await fetch(url, {
method: 'POST',
headers: {
'Authorization': `Bearer ${apiKey}`,
'Content-Type': 'application/json'
},
agent: httpsAgent,
body: JSON.stringify({
model: 'openrouter/free',
messages: [
{ role: 'user', content: pergunta }
],
}),
});

const dados = await resposta.json();
const textoIA = dados.choices[0].message.content;

return textoIA;

} catch (erro) {
console.error('Erro na requisição:', erro);
return 'Ops, algo deu errado.';
}
};

const GPT = {
conversations: {},
handler: async (userId, text, isQuoted = false) => {
try {
const d = new Date();
const horas = d.toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo" });
const dia = d.toLocaleDateString('pt-BR', { weekday: 'long' });
const data = d.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });
if (isQuoted && GPT.conversations[userId]) {
GPT.conversations[userId] += `\nUsuário: ${text}`;
} else {
GPT.conversations[userId] = `Usuário: ${text}`;
}
const response = await GPT.chatWithAI(GPT.conversations[userId]);
if (!response) {
return {
status: 500,
success: false,
message: "Erro na resposta da IA."
};
}
GPT.conversations[userId] += `\n${response}`;
return {
status: 200,
success: true,
payload: {
user_id: userId,
response: response,
metadata: { date: data, time: horas }
}
};
} catch (e) {
return { status: 500, success: false, message: e.message };
}
},
chatWithAI: async (text) => {
try {
const { data } = await axios.post("https://chateverywhere.app/api/chat/", {
"model": {
"id": "gpt-4",
"name": "GPT-4",
"maxLength": 32000,
"tokenLimit": 8000,
"completionTokenLimit": 5000,
"deploymentName": "gpt-4"
},
"messages": [{ "role": "user", "content": text }],
"prompt": text,
"temperature": 0.7
}, {
headers: {
"Accept": "application/json",
"User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
},
httpsAgent,
httpAgent,
timeout: 30000,
});
return data;
} catch (error) {
console.error('Erro:', error);
return null;
}
}
};

module.exports = {
  getBuffer,
  fetchJson,
  fetchText,
  generateMessageID,
  getGroupAdmins,
  getMembros,
  getRandom,
  bannerAnimado,
  temporizador,
  color,
  recognize,
  bgcolor,
  isFiltered,
  addFilter,
  chyt,
  getExtension,
  convertSticker,
  upload,
  banner,
  nit,
  getpc,
  supre,
  Gemini,
  GPT
};