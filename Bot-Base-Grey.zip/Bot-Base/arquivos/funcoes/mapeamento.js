const fs = require("fs-extra");
const path = require("path");

const MAP_PATH = path.join(__dirname, "..", "database", "mapping_lid.json");

let mappingCache = null;

function carregarMapa() {
  if (mappingCache) return mappingCache;
  try {
    if (fs.existsSync(MAP_PATH)) {
      const raw = JSON.parse(fs.readFileSync(MAP_PATH, "utf8"));
      mappingCache = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
    } else {
      mappingCache = {};
    }
  } catch {
    mappingCache = {};
  }
  return mappingCache;
}

function salvarMapa() {
  try {
    fs.writeFileSync(MAP_PATH, JSON.stringify(mappingCache || {}, null, 2));
  } catch {}
}

function paraJidBase(jid) {
  if (!jid) return "";
  const s = String(jid);
  if (s.includes("@")) return s.split("@")[0];
  return s;
}

function sincronizarGrupo(groupId, participants) {
  if (!groupId || !Array.isArray(participants)) return;
  const map = carregarMapa();
  if (!map[groupId]) map[groupId] = {};

  for (const p of participants) {
    const id = p?.id || p?.jid || p?.phoneJid || "";
    const lid = p?.lid || p?.lidJid || "";
    const phone = p?.phoneJid || p?.phoneNumber || "";

    const idBase = paraJidBase(id);
    const lidBase = paraJidBase(lid);
    const phoneBase = paraJidBase(phone);

    if (lidBase && idBase) {
      map[groupId][`${lidBase}@lid`] = `${idBase}@s.whatsapp.net`;
    } else if (lidBase && phoneBase) {
      map[groupId][`${lidBase}@lid`] = `${phoneBase}@s.whatsapp.net`;
    }
  }

  salvarMapa();
}

function lidParaJid(groupId, lidJid) {
  if (!lidJid) return "";
  if (lidJid.includes("@s.whatsapp.net")) return lidJid;
  if (lidJid.includes("@lid")) {
    const map = carregarMapa();
    const mapped = groupId && map[groupId] ? map[groupId][lidJid] : null;
    if (mapped) return mapped;
    return `${paraJidBase(lidJid)}@s.whatsapp.net`;
  }
  if (lidJid.includes("@g.us") || lidJid.includes("@broadcast")) return lidJid;
  return `${paraJidBase(lidJid)}@s.whatsapp.net`;
}

module.exports = { lidParaJid, sincronizarGrupo, carregarMapa, salvarMapa };
