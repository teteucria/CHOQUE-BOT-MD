const http = require("http");
const https = require("https");
const NodeCache = require("node-cache");

const httpAgent = new http.Agent({
  keepAlive: true,
  maxSockets: 25,
  maxFreeSockets: 10,
  timeout: 60000,
  keepAliveMsecs: 30000,
});

const httpsAgent = new https.Agent({
  keepAlive: true,
  maxSockets: 25,
  maxFreeSockets: 10,
  timeout: 60000,
  keepAliveMsecs: 30000,
});

const apiCache = new NodeCache({
  stdTTL: 300,
  checkperiod: 120,
  useClones: false,
});

const CACHE_TTL = {
  ytSearch: 1800,
  tiktokSearch: 900,
  pinterest: 3600,
  igStalk: 600,
  amazon: 900,
  playstore: 900,
  pensador: 1800,
  lyrics: 3600,
  wikipedia: 21600,
  weather: 600,
  books: 3600,
  static: 86400,
};

function cacheGet(key) {
  return apiCache.get(key);
}

function cacheSet(key, value, ttl) {
  apiCache.set(key, value, ttl || 300);
}

function cacheKey(...parts) {
  return parts.join("|");
}

function cacheStats() {
  return apiCache.getStats();
}

function cacheFlush() {
  apiCache.flushAll();
}

async function cachedFetchJson(url, options, ttl) {
  const key = cacheKey("fetchJson", url);
  const cached = cacheGet(key);
  if (cached) return cached;

  const result = await fetch(url, options).then((r) => r.json());
  cacheSet(key, result, ttl || 300);
  return result;
}

async function cachedFetchText(url, options, ttl) {
  const key = cacheKey("fetchText", url);
  const cached = cacheGet(key);
  if (cached) return cached;

  const result = await fetch(url, options).then((r) => r.text());
  cacheSet(key, result, ttl || 300);
  return result;
}

async function cachedGetBuffer(url, ttl) {
  const key = cacheKey("buffer", url);
  const cached = cacheGet(key);
  if (cached) return cached;

  const result = await fetch(url, {
    agent: { https: httpsAgent },
  }).then((r) => r.arrayBuffer());
  const buffer = Buffer.from(result);
  cacheSet(key, buffer, ttl || 120);
  return buffer;
}

module.exports = {
  httpAgent,
  httpsAgent,
  apiCache,
  CACHE_TTL,
  cacheGet,
  cacheSet,
  cacheKey,
  cacheStats,
  cacheFlush,
  cachedFetchJson,
  cachedFetchText,
  cachedGetBuffer,
};