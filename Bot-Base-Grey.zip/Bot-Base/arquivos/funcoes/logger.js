const chalk = require("chalk");
const moment = require("moment-timezone");
const os = require("os");
const cfonts = require("cfonts");

const M = (text) => chalk.magenta(text);
const C = (text) => chalk.cyan(text);
const G = (text) => chalk.green(text);
const Y = (text) => chalk.yellow(text);
const GR = (text) => chalk.gray(text);
const W = (text) => chalk.white(text);
const B = (text) => chalk.blue(text);
const DIM = (text) => chalk.dim(text);
const BOLD = (text) => chalk.bold(text);
const BG_MAGENTA = (text) => chalk.bgMagenta(text);
const BG_CYAN = (text) => chalk.bgCyan(text);
const BG_GREEN = (text) => chalk.bgGreen.black(text);
const BG_YELLOW = (text) => chalk.bgYellow.black(text);
const BG_RED = (text) => chalk.bgRed.white(text);

const now = () => moment.tz("America/Sao_Paulo");
const timestamp = () => now().format("HH:mm:ss");
const datestamp = () => now().format("DD/MM/YYYY");

const LINE = GR("────────────────────────────────────────────");
const THIN = GR("┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄");

const banner = () => {
process.stdout.write('\x1Bc');
cfonts.say('kira', {
font: 'block',
align: 'center',
colors: ['magenta', 'cyan'],
background: 'transparent',
letterSpacing: 1,
lineHeight: 1,
space: true,
maxLength: '0',
});

cfonts.say(`OWNER: Mz\nVERSION UPDATE: V11`, {
font: 'console',
align: 'center',
colors: ['white'],
background: 'transparent',
letterSpacing: 1,
lineHeight: 1,
space: true,
maxLength: '0',
});
console.log('');
};

function formatUptime(seconds) {
const d = Math.floor(seconds / 86400);
const h = Math.floor((seconds % 86400) / 3600);
const m = Math.floor((seconds % 3600) / 60);
const s = Math.floor(seconds % 60);
const parts = [];
if (d > 0) parts.push(`${d}d`);
if (h > 0) parts.push(`${h}h`);
if (m > 0) parts.push(`${m}m`);
parts.push(`${s}s`);
return parts.join(" ");
}

function connectionLog(status, detail) {
const time = timestamp();
const icon = status === "online" ? G("●") : status === "connecting" ? Y("●") : status === "close" ? GR("●") : GR("●");
const label = status === "online" ? G("ONLINE") : status === "connecting" ? Y("CONNECTING") : status === "close" ? GR("CLOSED") : GR(status.toUpperCase());
const detailStr = detail ? ` ${GR("·")} ${DIM(detail)}` : "";

console.log(`\n${GR("┌─")} ${G("kira")} ${GR("│")} ${time} ${GR("│")} ${icon} ${label}${detailStr}`);
console.log(`${GR("└─")}${THIN}`);
}

function mongodbLog(connected) {
const time = timestamp();
if (connected) {
console.log(`${GR("┌─")} ${G("kira")} ${GR("│")} ${time} ${GR("│")} ${G("●")} ${G("MONGODB")} ${GR("·")} ${G("conectado com sucesso")}`);
} else {
console.log(`${GR("┌─")} ${G("kira")} ${GR("│")} ${time} ${GR("│")} ${Y("●")} ${Y("MONGODB")} ${GR("·")} ${Y("conectando...")}`);
}
console.log(`${GR("└─")}${THIN}`);
}

function messageLog({ type, pushname, sender, command, isCmd, isGroup, groupName }) {
const time = timestamp();
const typeIcon = getTypeIcon(type);
const cmdTag = isCmd ? ` ${GR("›")} ${M(command)}` : "";
const groupTag = isGroup ? ` ${GR("›")} ${DIM(groupName || "grupo")}` : "";

const name = pushname || "Sem Nome";
const number = sender.split("@")[0];

console.log(`\n${GR("┌")} ${typeIcon} ${GR("│")} ${W(name)} ${GR("·")} ${DIM(number)}${cmdTag}${groupTag}`);
console.log(`${GR("└─")} ${DIM(time)} ${GR("│")} ${GR("msg recebida")}`);
}

function getTypeIcon(type) {
const icons = {
"Áudio": Y("🎵"),
"Figurinha": G("⭐"),
"Imagem": M("🖼"),
"Vídeo": M("🎬"),
"Documento": GR("📄"),
"Contato": B("👤"),
"Localização": Y("📍"),
};
const text = String(type);
if (text.startsWith("Reação")) return M("❤");
return icons[text] || C("💬");
}

function commandLog(command, user, status) {
const time = timestamp();
const statusIcon = status === "ok" ? G("✓") : status === "error" ? GR("✗") : Y("⟳");
console.log(`${GR("│")} ${statusIcon} ${M(command)} ${GR("·")} ${DIM(user)} ${GR("·")} ${DIM(time)}`);
}

function errorLog(context, error) {
const time = timestamp();
console.log(`\n${BG_RED(" ERROR ")} ${GR(time)} ${GR(context)}`);
if (error) console.log(`${GR("│")} ${GR(error.message || error)}`);
}

function successLog(msg) {
console.log(`\n${G("✓")} ${G(msg)}`);
}

function infoLog(msg) {
console.log(`\n${C("ℹ")} ${C(msg)}`);
}

function warnLog(msg) {
console.log(`\n${Y("⚠")} ${Y(msg)}`);
}

function sectionStart(title) {
console.log(`\n${M("┌─")} ${BOLD(M(title))}`);
}

function sectionEnd() {
console.log(`${M("└─")}${THIN}`);
}

module.exports = {
banner,
connectionLog,
mongodbLog,
messageLog,
commandLog,
errorLog,
successLog,
infoLog,
warnLog,
sectionStart,
sectionEnd,
timestamp,
datestamp,
LINE,
THIN,
M,
C,
G,
Y,
GR,
W,
B,
DIM,
BOLD,
BG_MAGENTA,
BG_CYAN,
BG_GREEN,
BG_YELLOW,
BG_RED,
};