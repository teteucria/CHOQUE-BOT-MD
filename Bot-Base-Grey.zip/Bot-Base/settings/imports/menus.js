
exports.menuPrincipal = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🤍 𝗠𝗲 𝗰𝗼𝗻𝗵𝗲𝗰̧𝗮 𝗺𝗲𝗹𝗵𝗼𝗿 🖤
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}dados (info)
│ 🖤 → ${prefix}criador (info)
│ 🖤 → ${prefix}infobv (info)
│ 🖤 → ${prefix}ping (info)
╰════════════════╯
╭════════════════╮
║ 🖤 𝗕𝗮𝗶𝘅𝗮𝗿 𝗽𝗿𝗮 𝘃𝗼𝗰𝗲̂ 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}play (nome)
│ 🖤 → ${prefix}playvid (nome)
│ 🖤 → ${prefix}playdoc (nome)
│ 🖤 → ${prefix}tiktok (link)
│ 🖤 → ${prefix}tiksearch (nome)
│ 🖤 → ${prefix}tiktok_audio (link)
│ 🖤 → ${prefix}instagram (link)
│ 🖤 → ${prefix}facebook (link)
│ 🖤 → ${prefix}gdrive (link)
│ 🖤 → ${prefix}mediafire (link)
│ 🖤 → ${prefix}pinterest (nome)
│ 🖤 → ${prefix}pinvideo (link)
│ 🖤 → ${prefix}tiktok_video (link)
│ 🖤 → ${prefix}tiktok2 (link)
│ 🖤 → ${prefix}soundcloud (link)
│ 🖤 → ${prefix}snapchat (link)
│ 🖤 → ${prefix}face_video (link)
│ 🖤 → ${prefix}threads (link)
│ 🖤 → ${prefix}twtdl (link)
│ 🖤 → ${prefix}twitter (link)
╰════════════════╯
╭════════════════╮
║ 🤍 𝗕𝘂𝘀𝗰𝗮𝘀 𝗲 𝗽𝗲𝘀𝗾𝘂𝗶𝘀𝗮𝘀 🖤
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}transcrever (audio)
│ 🖤 → ${prefix}celular (marca)
│ 🖤 → ${prefix}amazon (infos)
│ 🖤 → ${prefix}printsite (url)
│ 🖤 → ${prefix}gimage (infos)
│ 🖤 → ${prefix}pinterest (nome)
│ 🖤 → ${prefix}ytsearch (nome)
│ 🖤 → ${prefix}scep (número)
│ 🖤 → ${prefix}animesearch (nome)
│ 🖤 → ${prefix}aptoide (app)
│ 🖤 → ${prefix}binance (info)
│ 🖤 → ${prefix}carbon (código)
│ 🖤 → ${prefix}clima (cidade)
│ 🖤 → ${prefix}codestral (texto)
│ 🖤 → ${prefix}coin (moeda)
│ 🖤 → ${prefix}dafont (fonte)
│ 🖤 → ${prefix}deepseek (texto)
│ 🖤 → ${prefix}encomenda (código)
│ 🖤 → ${prefix}futeareas (info)
│ 🖤 → ${prefix}futebol (info)
│ 🖤 → ${prefix}github (repo)
│ 🖤 → ${prefix}gitrepo (link)
│ 🖤 → ${prefix}gptimage (prompt)
│ 🖤 → ${prefix}groq (texto)
│ 🖤 → ${prefix}handwriting (texto)
│ 🖤 → ${prefix}horoscopo (signo)
│ 🖤 → ${prefix}igstalk (usuário)
│ 🖤 → ${prefix}imagine (descrição)
│ 🖤 → ${prefix}mistral (texto)
│ 🖤 → ${prefix}nasa (info)
│ 🖤 → ${prefix}newsbbc (info)
│ 🖤 → ${prefix}newscnn (info)
│ 🖤 → ${prefix}newstube (info)
│ 🖤 → ${prefix}pensador (tema)
│ 🖤 → ${prefix}pesquisaytb (nome)
│ 🖤 → ${prefix}sauracnn (info)
│ 🖤 → ${prefix}sauranews (info)
│ 🖤 → ${prefix}saurasource (info)
│ 🖤 → ${prefix}screenshot (url)
│ 🖤 → ${prefix}spotify-search (nome)
│ 🖤 → ${prefix}spotify (link)
│ 🖤 → ${prefix}tgstalk (usuário)
│ 🖤 → ${prefix}threadstalk (usuário)
│ 🖤 → ${prefix}tiktokstalk (usuário)
│ 🖤 → ${prefix}tradutor (texto|idioma)
│ 🖤 → ${prefix}wallsearch (nome)
│ 🖤 → ${prefix}worldnews (info)
│ 🖤 → ${prefix}ytplaylist (nome)
╰════════════════╯
╭════════════════╮
║ 🖤 𝗙𝗶𝗴𝘂𝗿𝗶𝗻𝗵𝗮𝘀 𝗽𝗿𝗮 𝘃𝗼𝗰𝗲̂ 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}rename (marcar)
│ 🖤 → ${prefix}fsticker (marcar)
│ 🖤 → ${prefix}sticker (marcar)
│ 🖤 → ${prefix}toimg (marcar)
│ 🖤 → ${prefix}attp (seu-text)
│ 🖤 → ${prefix}roubar (text)
│ 🖤 → ${prefix}take (marcar)
│ 🖤 → ${prefix}rgtake (text)
│ 🖤 → ${prefix}ttp_white (texto)
│ 🖤 → ${prefix}ttp_brat (texto)
│ 🖤 → ${prefix}attp_white (texto)
│ 🖤 → ${prefix}attp_white_video (texto)
│ 🖤 → ${prefix}attp_brat_video (texto)
│ 🖤 → ${prefix}attp_brat (texto)
│ 🖤 → ${prefix}figaleatoria (1-5)
│ 🖤 → ${prefix}figuemoji (1-5)
│ 🖤 → ${prefix}figuflork (1-5)
│ 🖤 → ${prefix}figumemes (1-5)
│ 🖤 → ${prefix}figucoreana (1-5)
│ 🖤 → ${prefix}figuanime (1-5)
│ 🖤 → ${prefix}figuanimais (1-5)
│ 🖤 → ${prefix}figudesenho (1-5)
│ 🖤 → ${prefix}figuraiva (1-5)
│ 🖤 → ${prefix}figubebe (1-5)
│ 🖤 → ${prefix}figuroblox (1-5)
│ 🖤 → ${prefix}rntake (text)
╰════════════════╯
╭════════════════╮
║ 🖤 𝗦𝗼́ 𝗽𝗿𝗮 𝗾𝘂𝗲𝗺 𝗲́ 𝗱𝗲 𝗺𝗮𝗶𝗼𝗿 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}plaq (seu-nick)
│ 🖤 → ${prefix}plaq1 (seu-nick)
│ 🖤 → ${prefix}plaq2 (seu-nick)
│ 🖤 → ${prefix}plaq3 (seu-nick)
│ 🖤 → ${prefix}plaq4 (seu-nick)
│ 🖤 → ${prefix}plaq5 (seu-nick)
│ 🖤 → ${prefix}plaq6 (seu-nick)
│ 🖤 → ${prefix}plaq7 (seu-nick)
│ 🖤 → ${prefix}plaq8 (seu-nick)
│ 🖤 → ${prefix}plaq9 (seu-nick)
│ 🖤 → ${prefix}plaq10 (seu-nick)
╰════════════════╯
╭════════════════╮
║ 🤍 𝗗𝗶𝘃𝗲𝗿𝘀𝗮̃𝗼 𝗲 𝗯𝗿𝗶𝗻𝗰𝗮𝗱𝗲𝗶𝗿𝗮 🖤
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}getperfil (info)
│ 🖤 → ${prefix}metadinha (img)
│ 🖤 → ${prefix}obesidade (peso)
│ 🖤 → ${prefix}gerarlink2 (mídia)
│ 🖤 → ${prefix}imgpralink (mídia)
│ 🖤 → ${prefix}upload (mídia)
│ 🖤 → ${prefix}playstore (nome)
│ 🖤 → ${prefix}encurtalink (link)
│ 🖤 → ${prefix}countdays (data)
│ 🖤 → ${prefix}gerarqr (nome)
│ 🖤 → ${prefix}contardias (data)
│ 🖤 → ${prefix}fazernick (nome)
│ 🖤 → ${prefix}calcular (1+1)
│ 🖤 → ${prefix}gitclone (link)
│ 🖤 → ${prefix}qrcode (txt/url)
╰════════════════╯`;
};

exports.adms = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🖤 𝗣𝗿𝗮 𝗾𝘂𝗲𝗺 𝗺𝗮𝗻𝗱𝗮 𝗻𝗼 𝗴𝗿𝘂𝗽𝗼 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}antiimg (on)
│ 🖤 → ${prefix}antivideo (on)
│ 🖤 → ${prefix}antiaudio (on)
│ 🖤 → ${prefix}antisticker (on)
│ 🖤 → ${prefix}antiloc (on)
│ 🖤 → ${prefix}anticontato (on)
│ 🖤 → ${prefix}antidoc (on)
│ 🖤 → ${prefix}antilinkhard (on)
│ 🖤 → ${prefix}antilink (on)
│ 🖤 → ${prefix}antiporno (on)
│ 🖤 → ${prefix}bemvindo (on)
│ 🖤 → ${prefix}antilinkgp (on)
│ 🖤 → ${prefix}antispam (on)
│ 🖤 → ${prefix}setantispam (on)
│ 🖤 → ${prefix}agendargp (data)
│ 🖤 → ${prefix}delagendargp (off)
│ 🖤 → ${prefix}antilinkeasy (on)
│ 🖤 → ${prefix}prefixos (on)
│ 🖤 → ${prefix}add_prefixo (on)
│ 🖤 → ${prefix}tirar_prefixo (on)
│ 🖤 → ${prefix}multiprefix (on)
│ 🖤 → ${prefix}antinotas (on)
│ 🖤 → ${prefix}antistatus (on)
│ 🖤 → ${prefix}anticatalogo (on)
│ 🖤 → ${prefix}legendabv (on)
│ 🖤 → ${prefix}legendabv2 (on)
│ 🖤 → ${prefix}legendasaiu (on)
│ 🖤 → ${prefix}mute (user)
│ 🖤 → ${prefix}desmute (user)
│ 🖤 → ${prefix}roletarussa (user)
│ 🖤 → ${prefix}simih (on)
│ 🖤 → ${prefix}autosticker (on)
│ 🖤 → ${prefix}autodown (on)
│ 🖤 → ${prefix}autorepo (on)
│ 🖤 → ${prefix}odelete (on)
│ 🖤 → ${prefix}autofigu (on)
│ 🖤 → ${prefix}x9visuunica (on)
│ 🖤 → ${prefix}x9 (on/off)
│ 🖤 → ${prefix}so_adm (0/1)
│ 🖤 → ${prefix}descriçãogp (text)
│ 🖤 → ${prefix}fotogp (image)
│ 🖤 → ${prefix}linkgroup (link)
│ 🖤 → ${prefix}novolink (link)
│ 🖤 → ${prefix}recrutar (user)
│ 🖤 → ${prefix}aceitar (pedido)
│ 🖤 → ${prefix}recusar (pedido)
│ 🖤 → ${prefix}regras (infos)
│ 🖤 → ${prefix}cita (mensagem)
│ 🖤 → ${prefix}linkproibido (link)
│ 🖤 → ${prefix}addlink (link)
│ 🖤 → ${prefix}listalinks (lista)
│ 🖤 → ${prefix}dellink (link)
│ 🖤 → ${prefix}marcarwa (marca)
│ 🖤 → ${prefix}listadmins (lista)
│ 🖤 → ${prefix}deletar (mensagem)
│ 🖤 → ${prefix}revelar (vizuunica)
│ 🖤 → ${prefix}add 5511...
│ 🖤 → ${prefix}reviver (pessoa)
│ 🖤 → ${prefix}kick [@]
│ 🖤 → ${prefix}ban (pessoa)
│ 🖤 → ${prefix}promover [@]
│ 🖤 → ${prefix}rebaixar [@]
│ 🖤 → ${prefix}descgp (text)
│ 🖤 → ${prefix}nomegp (nome)
│ 🖤 → ${prefix}totag (pessoa)
│ 🖤 → ${prefix}grupo (a/f)
│ 🖤 → ${prefix}status (info)
│ 🖤 → ${prefix}limpar (função)
│ 🖤 → ${prefix}linkgp (convite)
│ 🖤 → ${prefix}revlinkgp (link)
│ 🖤 → ${prefix}grupoinfo (info)
│ 🖤 → ${prefix}hidetag (marca)
│ 🖤 → ${prefix}listafake (lista)
│ 🖤 → ${prefix}listafakes (lista)
│ 🖤 → ${prefix}brlist (lista)
│ 🖤 → ${prefix}listabr (lista)
│ 🖤 → ${prefix}listaddi (lista)
│ 🖤 → ${prefix}ddilist (lista)
│ 🖤 → ${prefix}listaddd (lista)
│ 🖤 → ${prefix}dddlist (lista)
│ 🖤 → ${prefix}marcar (@)
│ 🖤 → ${prefix}marcar2 (wa.me)
╰════════════════╯`;
};

exports.menudono = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🤍 𝗥𝗲𝘀𝗲𝗿𝘃𝗮𝗱𝗼 𝗽𝗿𝗮 𝘃𝗼𝗰𝗲̂, 𝗺𝗲𝘂 𝗱𝗼𝗻𝗼 🖤
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}prefixo-bot (prefix)
│ 🖤 → ${prefix}sairgp (on)
│ 🖤 → ${prefix}convite (link)
│ 🖤 → ${prefix}entrar (link)
│ 🖤 → ${prefix}seradm (on)
│ 🖤 → ${prefix}reiniciar (on)
│ 🖤 → ${prefix}getcase (nome)
│ 🖤 → ${prefix}sermembro (on)
│ 🖤 → ${prefix}nome-bot (nome)
│ 🖤 → ${prefix}nick-dono (nome)
│ 🖤 → ${prefix}logoicon (image)
│ 🖤 → ${prefix}numero-dono (dono)
│ 🖤 → ${prefix}setprefix (prefix)
│ 🖤 → ${prefix}listagp (lista)
│ 🖤 → ${prefix}antipalavrão (on)
│ 🖤 → ${prefix}antiligar (on)
│ 🖤 → ${prefix}antipv (on)
│ 🖤 → ${prefix}so_adm (on)
│ 🖤 → ${prefix}boton (on)
│ 🖤 → ${prefix}botoff (on)
│ 🖤 → ${prefix}visualizarmsg (on)
│ 🖤 → ${prefix}ausente (frase)
│ 🖤 → ${prefix}ativo (0/1)
│ 🖤 → ${prefix}addvip (nmr)
│ 🖤 → ${prefix}delvip (nmr)
│ 🖤 → ${prefix}viplist (listvip)
│ 🖤 → ${prefix}savegp (grupo)
│ 🖤 → ${prefix}lista-aluguel (grupo)
│ 🖤 → ${prefix}calendario (grupo)
│ 🖤 → ${prefix}iddogrupo (grupo)
│ 🖤 → ${prefix}verificado-global (on)
│ 🖤 → ${prefix}configurar-bot (info)
│ 🖤 → ${prefix}addaluguel (@/dias)
│ 🖤 → ${prefix}modoaluguel (on)
╰════════════════╯`;
};

exports.brincadeiras = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🖤 𝗕𝗿𝗶𝗻𝗰𝗮𝗱𝗲𝗶𝗿𝗮𝘀 𝗾𝘂𝗲 𝗲𝘂 𝗮𝗺𝗼 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}feio (marca)
│ 🖤 → ${prefix}carinho (marca)
│ 🖤 → ${prefix}fiel (marca)
│ 🖤 → ${prefix}infiel (marca)
│ 🖤 → ${prefix}vesgo (marca)
│ 🖤 → ${prefix}bebado (marca)
│ 🖤 → ${prefix}gostoso (marca)
│ 🖤 → ${prefix}gostosa (marca)
│ 🖤 → ${prefix}sigma (marca)
│ 🖤 → ${prefix}beta (marca)
│ 🖤 → ${prefix}baiano (marca)
│ 🖤 → ${prefix}baiana (marca)
│ 🖤 → ${prefix}carioca (marca)
│ 🖤 → ${prefix}louco (marca)
│ 🖤 → ${prefix}louca (marca)
│ 🖤 → ${prefix}safada (marca)
│ 🖤 → ${prefix}safado (marca)
│ 🖤 → ${prefix}macaco (marca)
│ 🖤 → ${prefix}macaca (marca)
│ 🖤 → ${prefix}puta (marca)
│ 🖤 → ${prefix}matar (marca)
│ 🖤 → ${prefix}tapa (marca)
│ 🖤 → ${prefix}chute (marca)
│ 🖤 → ${prefix}dogolpe (marca)
│ 🖤 → ${prefix}nazista (marca)
│ 🖤 → ${prefix}chance (fale algo)
│ 🖤 → ${prefix}surubao (pessoa)
│ 🖤 → ${prefix}quando (text)
│ 🖤 → ${prefix}mencionar (text)
│ 🖤 → ${prefix}death (nome)
│ 🖤 → ${prefix}corno (marca)
╰════════════════╯
╭════════════════╮
║ 🤍 𝗥𝗮𝗻𝗸𝗶𝗻𝗴𝘀 𝗽𝗶𝗰𝗮𝗻𝘁𝗲𝘀 🖤
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}rankgays
│ 🖤 → ${prefix}rankfieis
│ 🖤 → ${prefix}rankinfieis
│ 🖤 → ${prefix}rankgados
│ 🖤 → ${prefix}rankcornos
│ 🖤 → ${prefix}suruba
│ 🖤 → ${prefix}rankgostosos
│ 🖤 → ${prefix}rankgostosas
│ 🖤 → ${prefix}ranknazistas
│ 🖤 → ${prefix}rankotaku
│ 🖤 → ${prefix}ranksigmas
│ 🖤 → ${prefix}rankbetas
│ 🖤 → ${prefix}rankbaianos
│ 🖤 → ${prefix}rankbaianas
│ 🖤 → ${prefix}rankcariocas
│ 🖤 → ${prefix}rankloucos
│ 🖤 → ${prefix}rankloucas
│ 🖤 → ${prefix}ranksafadas
│ 🖤 → ${prefix}ranksafados
│ 🖤 → ${prefix}rankmacacos
│ 🖤 → ${prefix}rankmacacas
│ 🖤 → ${prefix}rankputas
│ 🖤 → ${prefix}rankgado
│ 🖤 → ${prefix}rankcorno
│ 🖤 → ${prefix}rankgostoso
│ 🖤 → ${prefix}rankgostosa
│ 🖤 → ${prefix}ranknazista
│ 🖤 → ${prefix}rankotakus
│ 🖤 → ${prefix}rankpau
│ 🖤 → ${prefix}ranksigma
│ 🖤 → ${prefix}rankbeta
│ 🖤 → ${prefix}rankbaiano
│ 🖤 → ${prefix}rankbaiana
│ 🖤 → ${prefix}rankcarioca
│ 🖤 → ${prefix}ranksafado
│ 🖤 → ${prefix}ranksafada
│ 🖤 → ${prefix}ranklouco
│ 🖤 → ${prefix}ranklouca
│ 🖤 → ${prefix}rankmacaco
│ 🖤 → ${prefix}rankmacaca
│ 🖤 → ${prefix}rankputa
│ 🖤 → ${prefix}rankfiel
│ 🖤 → ${prefix}rankinfiel
╰════════════════╯`;
};

exports.menutinder = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🖤 𝗖𝗼𝗿𝗮𝗰̧𝗼̃𝗲𝘀 𝗲 𝗰𝗮𝘀𝗮𝗶𝘀 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}tinder (info)
│ 🖤 → ${prefix}tinderrg (info)
│ 🖤 → ${prefix}tindereditar (info)
│ 🖤 → ${prefix}tinderperfil (info)
│ 🖤 → ${prefix}tinderbusca (nome)
│ 🖤 → ${prefix}tinderlike (id)
│ 🖤 → ${prefix}tinderdeslike (id)
│ 🖤 → ${prefix}tindermeet (info)
│ 🖤 → ${prefix}tindermatches (info)
│ 🖤 → ${prefix}tinderranking (info)
│ 🖤 → ${prefix}consentimento (sim/não)
╰════════════════╯`;
};

exports.menulogos = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🤍 𝗟𝗼𝗴𝗼𝘀 𝗰𝗼𝗺 𝗲𝘀𝘁𝗶𝗹𝗼 · 𝟭 🖤
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}3dcomic (text)
│ 🖤 → ${prefix}typographymultilayers (text)
│ 🖤 → ${prefix}dragonball (text)
│ 🖤 → ${prefix}narutoshippuden (text)
│ 🖤 → ${prefix}3dfoilballoon (text)
│ 🖤 → ${prefix}glossysilver3d (text)
│ 🖤 → ${prefix}colorfulneonlight (text)
│ 🖤 → ${prefix}blackpinkbornpink (text)
│ 🖤 → ${prefix}typographypavement (text)
│ 🖤 → ${prefix}pixelglitch (text)
│ 🖤 → ${prefix}neonglitch (text)
│ 🖤 → ${prefix}digitalglitch (text)
│ 🖤 → ${prefix}erasertext (text)
│ 🖤 → ${prefix}blackpinklogo (text)
│ 🖤 → ${prefix}glowingtext (text)
│ 🖤 → ${prefix}3dbeachtext (text)
│ 🖤 → ${prefix}3dunderwater (text)
│ 🖤 → ${prefix}foggyglass (text)
│ 🖤 → ${prefix}vintagetv (text)
│ 🖤 → ${prefix}cartoongraffiti (text)
│ 🖤 → ${prefix}graffitiwall (text)
│ 🖤 → ${prefix}embroidery (text)
│ 🖤 → ${prefix}3dpapercut (text)
│ 🖤 → ${prefix}glittertext (text)
│ 🖤 → ${prefix}watercolortext (text)
│ 🖤 → ${prefix}futuristiclight (text)
│ 🖤 → ${prefix}cloudssky (text)
│ 🖤 → ${prefix}vintagebulb (text)
│ 🖤 → ${prefix}3dgradient (text)
│ 🖤 → ${prefix}sandbeach (text)
│ 🖤 → ${prefix}luxurygold (text)
│ 🖤 → ${prefix}neonsignatures (text)
│ 🖤 → ${prefix}wetglass (text)
│ 🖤 → ${prefix}sandbeach2 (text)
│ 🖤 → ${prefix}retroneon (text)
│ 🖤 → ${prefix}fireworks (text)
│ 🖤 → ${prefix}1917style (text)
│ 🖤 → ${prefix}neongalaxy (text)
│ 🖤 → ${prefix}royaltext (text)
│ 🖤 → ${prefix}doubleexposure (text)
│ 🖤 → ${prefix}hollywoodstar (text)
│ 🖤 → ${prefix}3dhologram (text)
│ 🖤 → ${prefix}galaxyname (text)
│ 🖤 → ${prefix}greenneon (text)
│ 🖤 → ${prefix}glossychrome (text)
│ 🖤 → ${prefix}metalavatar (text)
│ 🖤 → ${prefix}goldtext (text)
│ 🖤 → ${prefix}moderngold (text)
│ 🖤 → ${prefix}capercut (text)
│ 🖤 → ${prefix}matrixtext (text)
│ 🖤 → ${prefix}greenbrush (text)
│ 🖤 → ${prefix}nightlend (text)
│ 🖤 → ${prefix}zombie3d (text)
│ 🖤 → ${prefix}writingcakes (text)
│ 🖤 → ${prefix}dragonfire (text)
│ 🖤 → ${prefix}noelchristmas (text)
│ 🖤 → ${prefix}thundertext (text)
│ 🖤 → ${prefix}blackpinksignatures (text)
│ 🖤 → ${prefix}arrowsignature (text)
│ 🖤 → ${prefix}americanflag3d (text)
│ 🖤 → ${prefix}roundthunder (text)
│ 🖤 → ${prefix}3dcastle (text)
│ 🖤 → ${prefix}3dsmartphone (text)
│ 🖤 → ${prefix}typographyavatar (text)
│ 🖤 → ${prefix}blueneonavatar (text)
│ 🖤 → ${prefix}graffitigirl (text)
│ 🖤 → ${prefix}pornhubstyle (text)
│ 🖤 → ${prefix}tiktoktext (text)
│ 🖤 → ${prefix}3dcolorfulpaint (text)
│ 🖤 → ${prefix}trianglemountain (text)
│ 🖤 → ${prefix}watercolorpainting (text)
│ 🖤 → ${prefix}portraitfence (text)
│ 🖤 → ${prefix}galaxywallpaper (text)
╰════════════════╯
╭════════════════╮
║ 🖤 𝗟𝗼𝗴𝗼𝘀 𝗰𝗼𝗺 𝗲𝘀𝘁𝗶𝗹𝗼 · 𝟮 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}wolfgalaxy (text1 & text2)
│ 🖤 → ${prefix}freefire (text1 & text2)
│ 🖤 → ${prefix}apexlegends (text1 & text2)
│ 🖤 → ${prefix}deadpoollogo (text1 & text2)
│ 🖤 → ${prefix}thorlogo (text1 & text2)
│ 🖤 → ${prefix}starwarsmascot (text1 & text2)
│ 🖤 → ${prefix}teamlogobw (text1 & text2)
│ 🖤 → ${prefix}bearlogo (text1 & text2)
│ 🖤 → ${prefix}footballlogo (text1 & text2)
│ 🖤 → ${prefix}blackpinklogo2 (text1 & text2)
│ 🖤 → ${prefix}assassingaming (text1 & text2)
│ 🖤 → ${prefix}fpsgaming (text1 & text2)
│ 🖤 → ${prefix}blueneonlogo (text1 & text2)
│ 🖤 → ${prefix}metalmascot (text1 & text2)
│ 🖤 → ${prefix}circlemascot (text1 & text2)
│ 🖤 → ${prefix}companylogo (text1 & text2)
│ 🖤 → ${prefix}gradient3dlogo (text1 & text2)
│ 🖤 → ${prefix}textlogo (text1 & text2)
│ 🖤 → ${prefix}luxurylogo (text1 & text2)
│ 🖤 → ${prefix}minimallogo (text1 & text2)
│ 🖤 → ${prefix}astronautlogo (text1 & text2)
│ 🖤 → ${prefix}teamlogo (text1 & text2)
│ 🖤 → ${prefix}avengers3d (text1 & text2)
│ 🖤 → ${prefix}marvellogo (text1 & text2)
│ 🖤 → ${prefix}bwlayerlogo (text1 & text2)
│ 🖤 → ${prefix}metallogo (text1 & text2)
│ 🖤 → ${prefix}gamergirlmascot (text1 & text2)
│ 🖤 → ${prefix}captainamerica (text1 & text2)
╰════════════════╯`;
};

exports.menuanimes = (NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu) => {
return `╭════════════════╮
║  𖹭 *Bot*: ${NomeDoBot}
║  𖹭 *Você*: ${pushname}
║  𖹭 *Status*: ${isCargo}
║  𖹭 *Hoje*: ${date()}
║  𖹭 *Horas*: ${hora()}
╰════════════════╯
╭════════════════╮
║ 🤍 𝗜𝗺𝗮𝗴𝗲𝗻𝘀 𝗱𝗲 𝗮𝗻𝗶𝗺𝗲 🖤
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}akira (img)
│ 🖤 → ${prefix}akiyama (img)
│ 🖤 → ${prefix}ana (img)
│ 🖤 → ${prefix}asuna (img)
│ 🖤 → ${prefix}ayuzawa (img)
│ 🖤 → ${prefix}boruto (img)
│ 🖤 → ${prefix}chiho (img)
│ 🖤 → ${prefix}chitoge (img)
│ 🖤 → ${prefix}cogan (img)
│ 🖤 → ${prefix}cogan2 (img)
│ 🖤 → ${prefix}deidara (img)
│ 🖤 → ${prefix}doraemon (img)
│ 🖤 → ${prefix}eba (img)
│ 🖤 → ${prefix}elaina (img)
│ 🖤 → ${prefix}emilia (img)
│ 🖤 → ${prefix}erza (img)
│ 🖤 → ${prefix}gremory (img)
│ 🖤 → ${prefix}hestia (img)
│ 🖤 → ${prefix}hinata (img)
│ 🖤 → ${prefix}inori (img)
│ 🖤 → ${prefix}islamic (img)
│ 🖤 → ${prefix}isuzu (img)
│ 🖤 → ${prefix}itachi (img)
│ 🖤 → ${prefix}itori (img)
│ 🖤 → ${prefix}kaga (img)
│ 🖤 → ${prefix}kagura (img)
│ 🖤 → ${prefix}kakasih (img)
│ 🖤 → ${prefix}kaori (img)
│ 🖤 → ${prefix}kartun (img)
│ 🖤 → ${prefix}katakata (img)
│ 🖤 → ${prefix}keneki (img)
│ 🖤 → ${prefix}kotori (img)
│ 🖤 → ${prefix}kurumi (img)
│ 🖤 → ${prefix}madara (img)
│ 🖤 → ${prefix}megumin (img)
│ 🖤 → ${prefix}mikasa (img)
│ 🖤 → ${prefix}miku (img)
│ 🖤 → ${prefix}minato (img)
│ 🖤 → ${prefix}mountain (img)
│ 🖤 → ${prefix}naruto (img)
│ 🖤 → ${prefix}nekonime (img)
│ 🖤 → ${prefix}nezuko (img)
│ 🖤 → ${prefix}onepiece (img)
│ 🖤 → ${prefix}pokemon (img)
│ 🖤 → ${prefix}programming
│ 🖤 → ${prefix}rize (img)
│ 🖤 → ${prefix}sagiri (img)
│ 🖤 → ${prefix}sakura (img)
│ 🖤 → ${prefix}sasuke (img)
│ 🖤 → ${prefix}shina (img)
│ 🖤 → ${prefix}shinka (img)
│ 🖤 → ${prefix}shinomiya (img)
│ 🖤 → ${prefix}shizuka (img)
│ 🖤 → ${prefix}tejina (img)
│ 🖤 → ${prefix}toukachan (img)
│ 🖤 → ${prefix}tsunade (img)
│ 🖤 → ${prefix}waifu (img)
│ 🖤 → ${prefix}wallhp2 (img)
│ 🖤 → ${prefix}yotsuba (img)
│ 🖤 → ${prefix}yuki (img)
│ 🖤 → ${prefix}yumeko (img)
╰════════════════╯
╭════════════════╮
║ 🖤 𝗜𝗺𝗮𝗴𝗲𝗻𝘀 𝗽𝗿𝗮 𝗿𝗶𝗿 🤍
╰════════════════╯
╭════════════════╮
│ 🖤 → ${prefix}aesthetic (img)
│ 🖤 → ${prefix}anjing (img)
│ 🖤 → ${prefix}blackpink (img)
│ 🖤 → ${prefix}boneka (img)
│ 🖤 → ${prefix}cecan (img)
│ 🖤 → ${prefix}cosplay (img)
│ 🖤 → ${prefix}dadu (img)
│ 🖤 → ${prefix}hekel (img)
│ 🖤 → ${prefix}justina (img)
│ 🖤 → ${prefix}kayes (img)
│ 🖤 → ${prefix}kpop (img)
│ 🖤 → ${prefix}kucing (img)
│ 🖤 → ${prefix}mobil (img)
│ 🖤 → ${prefix}montor (img)
│ 🖤 → ${prefix}notnot (img)
│ 🖤 → ${prefix}profil (img)
│ 🖤 → ${prefix}pubg (img)
│ 🖤 → ${prefix}rose (img)
│ 🖤 → ${prefix}ryujin (img)
│ 🖤 → ${prefix}wallhp (img)
│ 🖤 → ${prefix}wallml (img)
╰════════════════╯`;
};