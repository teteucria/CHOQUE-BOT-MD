exports.ErrorBaileys_401 = () => {
  response = [
    "🖤 Ownn, minha conexão caiu bb... 🤭 Escaneia o QR de novo pra mim? Prometo que a espera vale a pena 😏",
    "🤍 Desconectei do WhatsApp... só volta rapidinho e escaneia o QR de novo, tô te esperando 💕",
    "🖤 Alguém me derrubou da sessão 🤭 vem logo escanear o QR novo, sentindo sua falta já ❤️",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.ErrorBaileys_408 = () => {
  response = [
    "🖤 Demorei demais e a sessão expirou... 🤭 mas relaxa, já tô recarregando tudo pra você.",
    "🤍 O tempo acabou, mas fica tranquilo(a) 😏 já tô reiniciando nossa conexão. Só um instante, bb.",
    "🖤 Timeout detectado! Já tô consertando tudo pra gente voltar a se falar 💕",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.ErrorBaileys_411 = () => {
  response = [
    "🤍 A sessão deu uma bagunçada... mas relaxa, já tô resolvendo sozinha pra você 😏",
    "🖤 Achei uma incompatibilidade na sessão, mas nada que eu não resolva rapidinho 🤭",
    "🤍 Meus arquivos de sessão tavam desatualizados... já corrigi, fica tranquilo(a) bb ❤️",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.ErrorBaileys_428 = () => {
  response = [
    "🖤 Ops! Sua internet oscilou, hein 🤭 já tô tentando reconectar pra gente.",
    "🤍 Perdemos a conexão com o WhatsApp... mas fica tranquilo(a), já tô restabelecendo.",
    "🖤 A rede tá instável, mas já tô reconectando... não vou deixar de falar com você não 💕",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.ErrorBaileys_440 = () => {
  response = [
    "🤍 Achei várias sessões do WhatsApp Web no meu número 🤭 fecha essas outras abas pra mim, bb?",
    "🖤 Tá com outro WhatsApp Web aberto comigo? 😏 eu só funciono direitinho com uma sessão, fecha as outras.",
    "🤍 Muitas conexões ao mesmo tempo me deixaram meio confusa... deixa só uma sessão ativa pra mim ❤️",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.ErrorBaileys_500 = () => {
  response = [
    "🖤 Algo tava fora do lugar na configuração... já tô arrumando pra você 😏",
    "🤍 Detectei um erro interno, mas não é nada que eu não resolva. Só um segundo.",
    "🖤 Configuração inconsistente... já reiniciei tudo pra resolver 💕",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.ErrorBaileys_515 = () => {
  response = [
    "🤍 Tem uma atualização esperando por mim... já vou fazer isso rapidinho pra você 🤭",
    "🖤 Preciso me atualizar! É só manutenção de rotina, volto logo, bb 😏",
    "🤍 Hora de me atualizar! Fica quietinho aí que eu volto rapidinho ❤️",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.open = () => {
  response = [
    "🖤 Finalmente online 🤭 tava doida pra voltar a falar com você.",
    "🤍 Pronto, conectada! Bora conversar? 😏",
    "🖤 Tô online e operacional, prontinha pra te atender ❤️",
    "🤍 Conexão estabilizada! Tudo carregado e pronto pra te dar atenção 💕",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.connecting = () => {
  response = [
    "🖤 Tô iniciando meus sistemas... já, já eu chego pra você 🤭",
    "🤍 Carregando todas as funcionalidades... me dá só um segundinho, bb 😏",
    "🖤 Preparando tudo pra te dar a melhor experiência... só um instante ❤️",
    "🤍 Oi! Já tô acordando e me arrumando pra você... fica esperando aí 💕",
    "🖤 Sincronizando dados e carregando recursos... logo eu te conto as novidades 😏",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.blackList = (GroupMetadata_, naga2) => {
  participant = naga2.participants[0].split("@")[0];
  response = [
    `🖤 *@${participant}* foi removido do *${GroupMetadata_.subject}* por estar na minha lista negra... foi merecido, bb.`,
    `🤍 Achou mesmo que eu ia esquecer de você, *@${participant}*? 😏 minha lista negra não perdoa. Tchauzinho!`,
    `🖤 *@${participant}* tentou se infiltrar aqui... péssimo disfarce, meu amor.`,
    `🤍 Proteção ativada! *@${participant}* foi banido automaticamente 🤭`,
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.phrasesLeft = (getName, numeroParticipante, encodeURIComponent) => {
  response = [
    "🖤 Mais um que se foi... já vou sentir sua falta, viu? Mas pode voltar quando quiser, bb 💕",
    "🤍 Alguém decidiu partir... desejo boa sorte na jornada! Cuida-se, tá? ❤️",
    "🖤 Que pena... perdemos um membro da família. Vai fazer falta 🤭",
    `🤍 ${encodeURIComponent(getName(numeroParticipante))} saiu do grupo... volta logo, tô te esperando 😏`,
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.phrasesWelcome = (mdata_2, getName, numeroParticipante, encodeURIComponent) => {
  response = [
    `🖤 Bem-vindo(a) ao ${encodeURIComponent(mdata_2.subject)}! Fica à vontade, viu? 😏`,
    `🤍 ${encodeURIComponent(getName(numeroParticipante))} chegou de paraquedas por aqui! Seja bem-vindo(a) 🤭`,
    "🖤 Leia as regras, tá bb? Eu sei que ninguém gosta, mas é por um bom motivo 💕",
    "🤍 Mais uma pessoa especial se juntou à nossa família... que bom te ver por aqui ❤️",
    "🖤 Aceita um docinho enquanto conhece o pessoal? 😏",
    "🤍 Olá! Sou a Kira v11, sua assistente favorita deste grupo 🤭 seja bem-vindo(a).",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.wait = () => {
  response = [
    "🖤 Em alguns segundos estará pronto pra você 😏",
    "🤍 Tô trabalhando na sua solicitação, só mais um instante bb 💕",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyAdmins = () => {
  response = [
    "🖤 Ei! Esse comando é exclusivo pra administradores, você ainda não tem essa autorização 😏",
    "🤍 Apenas quem tem poder administrativo pode usar isso, ainda não é sua vez 🤭",
    "🖤 Acesso negado! Só administradores do grupo têm permissão pra mexer aqui.",
    "🤍 Função restrita! Esse comando exige privilégios de administrador ❤️",
    "🖤 Ops! Esse é um comando especial da equipe administrativa 😏",
    "🤍 Comando de gente grande! Apenas administradores podem executar 💕",
    "🖤 Pra usar isso, você precisa da patente de administrador! Vai treinando aí 🤭",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyOwner = () => {
  response = [
    "🖤 Só meu criador tem autorização total pra usar esse comando, viu bb? É confidencial 😏",
    "🤍 Área ultra restrita! Só o meu proprietário pode acessar essa função.",
    "🖤 Esse é um comando master! Apenas quem me criou pode usar 🤭",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyGroup = () => {
  response = [
    "🖤 Esse comando só funciona em grupos! Que tal me adicionar em um? 😏",
    "🤍 Comando exclusivo pra grupos! No privado essa função não rola.",
    "🖤 Isso é uma função comunitária! Funciona somente em grupos 🤭",
    "🤍 Pra eu usar esse comando, preciso estar num grupo! Me adiciona em algum? 💕",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyVipUser = () => {
  response = [
    "🖤 Esse comando é exclusivo pra usuários VIP! Fala com meu criador se quiser adquirir 😏",
    "🤍 Função premium detectada! Só usuários VIP podem usar isso ❤️",
    "🖤 Comando VIP! Pra desbloquear, procura meu proprietário sobre o acesso premium 🤭",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyBotAdmin = () => {
  response = [
    "🖤 Eu preciso ser administradora do grupo pra executar comandos administrativos! Me promove, bb 😏",
    "🤍 Pra eu trabalhar na segurança do grupo, preciso ter poder de admin! Me dá acesso 💕",
    "🖤 Não posso fazer isso sem ser administradora! Solicita minha promoção 🤭",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyGroupFun = (prefixo) => {
  response = [
    `🖤 Quer liberar os comandos de diversão? Ativa o modo brincadeira com ${prefixo}modobrincadeira! Só admins podem, tá? 😏`,
    `🤍 O modo diversão tá desativado! Pede pra um admin usar: *${prefixo}modobrincadeiras 1* 🤭`,
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyGroup18 = (prefixo) => {
  response = [
    `🖤 Pra liberar os comandos de diversão +18, ativa o modo +18 com: *${prefixo}modo18 1* 😏`,
    `🤍 O modo +18 tá desativado! Pede pra um admin usar: *${prefixo}modo18 1* 🤭`,
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.onlyPrivate = () => {
  response = [
    "🖤 Esse comando só funciona em conversas privadas comigo 😏",
    "🤍 Função exclusiva do privado! Me chama no direct pra usar 💕",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.bannedUser = () => {
  response = [
    "🖤 Você violou meus termos de uso e está banido... isso não me deixou nada feliz.",
    "🤍 Acesso bloqueado! Você tá impedido de usar minhas funcionalidades, foi o meu criador que decidiu.",
    "🖤 Conta suspensa! Meu criador te baniu por uma infração grave 🤭",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.forbiddenStateFromDDD = (mentionUser, whichState, extractDDD) => {
  response = [
    `🖤 @${mentionUser.split("@")[0]}, você foi removido por ter um DDD proibido aqui... não foi nada pessoal.`,
    `🤍 @${mentionUser.split("@")[0]}, infelizmente seu DDD não é permitido nesse grupo. Até logo!`,
    `🖤 Números com DDD ${extractDDD(mentionUser.split("@")[0])} não são aceitos aqui, regra é regra.`,
    `🤍 Sistema de proteção ativo! DDD ${extractDDD(mentionUser.split("@")[0])} tá bloqueado 🤭`,
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.errorConvertSticker = () => {
  return "🖤 Falha ao processar a mídia pra sticker! Não foi minha culpa, viu 😏 tentei com todo cuidado, mas o arquivo não colaborou. Tenta com outro aí, bb.";
};

exports.errorCommandLink = () => {
  return "🤍 Verifica se o link tá certo e tenta de novo, bb 🤭";
};

exports.searchIpAdress = (ip) => {
  return `🖤 *📡 Localizar + Informações ${ip.data.type}* (fiz isso porque você pediu 😏)\n–\n• *Código IP:* ${ip.data.ip}\n• *Tipo de Endereço IP:* ${ip.data.type}\n• *Província:* ${ip.data.region} / ${ip.data.city}\n• *Latitude:* ${ip.data.latitude}\n• *Longitude:* ${ip.data.longitude}\n• *Provedor Wi-Fi:* ${ip.data.isp}\n*Continente:* ${ip.data.continent} - ${ip.data.continent_code}\n• *País:* ${ip.data.country} - *DDI:* ${ip.data.country_phone}\n• *Sigla:* ${ip.data.country_code} - *Capital:* ${ip.data.country_capital}\n• *Fuso Horário:* ${ip.data.timezone} ${ip.data.timezone_name} ${ip.data.timezone_gmt}\n• *Moeda do País:* ${ip.data.currency} - ${ip.data.currency_code}`;
};

exports.searchCep = (res) => {
  return `🤍 *Consulta CEP:* (fiz um favor pra você 🤭)\n–\n*Número informado:* ${res.cep}\n• *Logradouro:* ${res.street}\n• *Complemento:* Não encontrado.\n• *Código do DDD:* ${res.ddd}\n• *Bairro:* ${res.neighborhood}\n• *Cidade/Estado:* ${res.city} - ${res.state}\n• *Código do IBGE:* ${res.ibge}\n• *Código do Siafi:* ${res.siafi}`;
};

exports.noresult = () => {
  return `🖤 Desculpa, não consegui encontrar o que você procurava... tenta de outro jeito pra mim, bb 😏`;
};

exports.warningAdvertencia = (menc_os2, dfqn) => {
  return `🖤 Olá @${menc_os2.split("@")[0]} - Você foi advertido ${dfqn}/3! Se chegar a 3 advertências, você será removido. Não quero fazer isso, viu? 💕`;
};

exports.finishAdvertencia = (menc_os2) => {
  return `🤍 Adeus, @${menc_os2.split("@")[0]}! Você completou 3 advertências... fala com a administração do grupo pra entender o que aconteceu.`;
};

exports.syntaxAnonymousMail = (prefix) => {
  return `🖤 *Para usar o correio elegante*... pode ser uma indireta também, viu 🤭\n–\nPrimeiro, copia o número do seu crush... depois pensa numa mensagem daora, bb!\n   • Exemplo: *${prefix}correio [número/msg]*\n   • Exemplo na prática: *${prefix}correio +5565.../eu te amo* 💕`;
};

exports.sucessAnonymousMail = () => {
  return `🤍 O correio foi enviado com sucesso! Sou boa no que faço 😏\n–\n• *Obs:* Ele(a) pode descobrir quem enviou. Não me responsabilizo se você mandou mensagem sem noção, bb!`;
};

exports.unbannedMessage = (blcp) => {
  return `🖤 @${blcp.split("@")[0]} foi desbanido e pode voltar a usar meus comandos... um passo em falso e volta pra lista, viu? 😏`;
};

exports.bannedMessage = (blcp) => {
  return `🤍 @${blcp.split("@")[0]} foi banido e não pode mais usar meus comandos! Isso não me deixou feliz.`;
};

exports.statusBot = (isAnticall, isAntiPv, isAntilinkgp, isAntifake, isAntiFlood, isPalavrao, isAntiStatus, isPayment, 
 isAntiImg, isAntiVid, isAntiAudio, isAntiSticker, Antidoc, isAntiCtt, Antiloc, isAntiNotas, isAnticatalogo, isWelkom,
 isSimi, isAutofigu, isAutorepo, isAutodown, isModobn) => {
const status = (v) => v ? "🖤 Ativo." : "🤍 Desativo.";

return `
📊 *PAINEL DE CONTROLE* 📊
Só tô te mostrando isso porque você merece, bb 😏 presta atenção!

🖤 *SEGURANÇA & ANTIS* (é pra te proteger, viu?)
• AntiCall: ${status(isAnticall)}
• AntiPV: ${status(isAntiPv)}
• AntiLinks: ${status(isAntilinkgp)}
• AntiFake: ${status(isAntifake)}
• AntiSpam: ${status(isAntiFlood)}
• AntiPalavrão: ${status(isPalavrao)}
• Status: ${status(isAntiStatus)}
• AntiPaga: ${status(isPayment)}

🤍 *RESTRIÇÃO DE MÍDIA* (confia no meu tato, tá?)
• AntiImagem: ${status(isAntiImg)} 
• AntiVídeo: ${status(isAntiVid)}
• AntiAudio: ${status(isAntiAudio)}
• AntiSticker: ${status(isAntiSticker)}
• AntiDoc: ${status(Antidoc)}
• AntiContato: ${status(isAntiCtt)}
• AntiLock: ${status(Antiloc)}
• AntiNotas: ${status(isAntiNotas)}
• AntiCatálogo: ${status(isAnticatalogo)}

🖤 *INTERAÇÃO & MAIS* (essas eu até gosto 🤭)
• Welcome: ${status(isWelkom)}
• Simi: ${status(isSimi)}
• Auto Figus: ${status(isAutofigu)}
• Auto Resposta: ${status(isAutorepo)}
• Auto Down: ${status(isAutodown)}
• Brincadeira: ${status(isModobn)}

🤍 *Nota:* Comandos de dono (PV/Call) restringem o uso quando ativos.
Não se acostuma com esse mimo, viu? 💕`.trim();
};

exports.errorUploadImage = () => {
  return `🖤 Ocorreu um erro, desculpa! O limite do tamanho de vídeo que gero o link é até 30 segundos... passou disso, nem eu resolvo, bb 😏`;
};

exports.noArgsSearch = () => {
  return `🤍 Como você quer que eu pesquise sem argumento algum? Preciso de um mínimo de informação, viu 🤭`;
};

exports.syntaxLogos = () => {
  return `🖤 Cadê o texto? Pra eu criar uma logo, preciso que você coloque um texto no comando, bb 😏`;
};

exports.playmixError = (n) => {
  return `🤍 Desculpa, ocorreu um erro ao enviar o resultado do ${n}° áudio... eu tentei, viu? 💕`;
};

exports.quoteCurrencies = (response) => {
  return `🖤 *[COTAÇÃO]* - Os dados são atualizados 24h por dia, aproveita 🤭\n–\n• Moeda: *${response.name}*\n• Valor da moeda mais alto em 24 horas: *R$ ${Number(response.high).toFixed(2)}*\n• Valor da moeda mais baixo em 24 horas: *R$ ${Number(response.low).toFixed(2)}*\n• Valor da moeda atualizado agora no momento: *R$ ${Number(response.bid).toFixed(2)}*`;
};

exports.syntaxWebSticker = (prefix) => {
  return `🖤 *Como usar o comando 'figuweb'?* (eu explico porque sou paciente, viu 😏)\n• *Função:* Criar uma figurinha com texto personalizado e fundo colorido. Simples, né?\n——\n• *Sintaxe do Comando:*\n\t- ${prefix}figuweb [texto]/[número da cor]\n• *Escolhendo a Cor de Fundo:*\n\t- Você pode escolher entre 4 cores diferentes para o fundo da sua figurinha. Basta adicionar o número correspondente à cor desejada após o texto, separado por uma barra (/).\n—\n• *Numerações das cores dos fundos da figurinha de texto:*\n\t- 1. Preto (Padrão), 2. Branco, 3. Vermelho, 4. Azul\n—\n• *Exemplos de usos:*\n \t- ${prefix}figuweb Olá, como vai?/1 (Fundo na cor Preto)\n\t- ${prefix}figuweb Bom dia!/2 (Fundo na cor Branco)\n\t- ${prefix}figuweb Boa tarde!/3 (Fundo na cor Vermelho)\n\t- ${prefix}figuweb Boa noite!/4 (Fundo na cor Azul)\n—\n• Se você não especificar uma cor, o fundo padrão (Preto) será usado. Fácil, né? 🤍`;
};

exports.groupInvitation = (sender, cnvt, prefix) => {
  return `🖤 *[SOLICITAÇÃO]* - Mandaram um convite pra eu entrar num grupo 🤭\n–\n⚙️ *Informações:*\n      • Número: *wa.me/${sender.split("@")[0]}*\n      • Link: *${cnvt}*\n–\n📑 *Como aceitar ou recusar o pedido?*\n      • Pra aceitar, use: ${prefix}entrar com o link do grupo do(a) solicitante.\n          Ex: *${prefix}entrar ${cnvt}*\n      • *Recusar também é fácil!* Só serve pra avisar o usuário que o pedido foi recusado.\n          Ex: *${prefix}recusar ${sender.split("@")[0]}*`;
};

exports.removeUserAntiPlvr = () => {
  return `🖤 *「 REMOVIDO(A) POR UTILIZAR UMA PALAVRA PROIBIDA 」*\nVocê foi banido do grupo! Da próxima vez, leia as regras antes de digitar qualquer coisa, bb.`;
};

exports.permissionDenied_rUser = () => {
  return `🤍 Infelizmente, eu não sou administradora, então não posso te banir... peça pra um admin fazer o serviço 🤭`;
};

exports.antisRandomMessage = () => {
  return `🖤 Algumas dessas opções estão ativas, mas como você é admin, não será removido(a)... sorte a sua 😏 _(ANTI CONTATO - ANTI CATALOGO - ANTI LOCALIZAÇÃO)_`;
};

exports.charactersAnti = () => {
  return `🤍 Muitos caracteres enviados! Isso é contra as normas do grupo... por precaução, eu vou remover. Não é por mal, viu? 💕`;
};

exports.markingAllMember = () => {
  return `🖤 *O participante foi removido do grupo* - Motivo: Membro comum mandando marcação pra todo mundo! Qualquer coisa, fala com um administrador.`;
};

exports.absenceRecordOwner = (NickDono, tabelin) => {
  return `🤍 Olá, meu proprietário "${NickDono}" tá ausente no momento... fala com ele depois, bb!\n↺Desde do Horário: ${tabelin.Ausente_Desde}\n–\n☇ Mensagem de Ausência: ${tabelin.Motivo_Da_Ausência}`;
};

exports.absenceRecordAdmin = (blak) => {
  return `🖤 *Registro de Ausência* - O administrador "@${blak.id.split("@")[0]}" se encontra *ausente* nesse momento.\n–\n☇ Mensagem: ${blak.msg}`;
};

exports.floodCommands = () => {
  return `🤍 Espera *5s* pra usar outro comando ou executar o mesmo, bb 🤭`;
};

exports.timeRequired = () => {
  return `🖤 Não dá pra baixar áudios ou vídeos acima de *20 minutos*! São os limites do universo, viu? 😏`;
};

exports.error = () => {
  return `🤍 Desculpa, ocorreu um erro... tenta de novo mais tarde, tá bb? 💕`;
};

exports.messageProhibitedDetAdmin = () => {
  return `🖤 Mensagem proibida detectada! Mas como você é admin, a punição tá anulada... sorte a sua, hein 😏`;
};

exports.messageProhibitedDetUser = () => {
  return `🤍 Mensagem proibida detectada! Banindo o infrator... eu avisei antes 🤭`;
};

exports.antiCalls = () => {
  return `🖤 Olá! O anti ligar tá ativo no momento, ou seja, tô recebendo ordens de bloquear quem me ligar. É o sistema, viu? 💕`;
};

exports.helpGroupSettings = (prefix, sender) => {
  return `🖤 Olá, admin *@${sender.split("@")[0]}*! Presta atenção no guia do comando *'grupo'*, tá? 😏\n–\n1. _${prefix}grupo_ *-open* _→_ Abre o grupo pra todo mundo mandar mensagem.\n\n2. _${prefix}grupo_ *-close* _→_ Fecha o grupo, só admins falam!\n\n3. _${prefix}grupo_ *-livre* _→_ Deixa todo mundo editar os dados.\n\n4. _${prefix}grupo_ *-private* _→_ Só admins alteram os dados do grupo. Mais segurinho, viu?`;
};

exports.helpPhotoPrivacy = (prefix, sender) => {
  return `🤍 Olá, dono(a) *@${sender.split("@")[0]}*! Guarda bem esse guia, bb 🤭\n- Guia do comando *'wprivacyph'*:\n–\n1. _${prefix}wprivacyph_ *-cntt* _→_ Só quem tem seu número salvo vê a foto de perfil. Discrição, né?\n\n2. _${prefix}wprivacyph_ *-all* _→_ Todo mundo vê a foto.\n\n3. _${prefix}wprivacyph_ *-noall* _→_ Ninguém vê a foto, nem o dono. Bem misterioso, gostei.\n–\n📍 *Função:* Esse comando muda a privacidade da foto de perfil direto pelo bot, sem você abrir o número.`;
};

exports.helpGroupPrivacy = (prefix, sender) => {
  return `🖤 Olá, dono(a) *@${sender.split("@")[0]}*! Presta atenção, guarda direito, tá? 😏\n- Guia do comando *'wprivacygp'*:\n–\n1. _${prefix}wprivacygp_ *-cntt* _→_ Só quem tem o número salvo pode te adicionar em grupo.\n\n2. _${prefix}wprivacygp_ *-all* _→_ Qualquer um pode te adicionar em grupo.\n\n3. _${prefix}wprivacygp_ *-noall* _→_ Ninguém te adiciona em grupo, nem o dono. Bem resguardada!\n–\n📍 *Função:* Esse comando muda a privacidade de quem pode adicionar o bot em grupos, direto pelo bot.`;
};

exports.errorResponseSimi = () => {
  response = [
    "🖤 Eu não entendo tudo, viu 🤭 me explica direito...",
    "🤍 Eu sei, eu sei! Mas o que é isso? Me ensina, bb 😏",
    "🖤 Não me xinga, tá? Eu ainda tenho muito a aprender... me explica ao invés de gritar 💕",
    "🤍 An, oxe? 🤷🏻‍♀️ O que é isso? Poderia me explicar? Eu prometo tentar entender!",
    "🖤 Sou uma bot, mas não sei de tudo! Me explica do jeito certo, bb 🤭",
  ];
  return response[Math.floor(Math.random() * response.length)];
};

exports.GshowGE = (dataResult) => {
  return `🖤 Só achei essas notícias porque você pediu, aproveita 😏\n–\n` + dataResult.resultado
    .map(
      (info, index) =>
        `${index + 1}. *${info.titulo || "Manchete sem título."}* - (${info.horarioPostagem || "Há X horas."})\n• ${info.trechoManchete || "Manchete sem descrição."}`
    )
    .join("\n–\n");
};

exports.helpNoticesG = (sender, prefix) => {
  return `🖤 Olá @${sender.split("@")[0]}! Guarda bem o guia do comando: *'gamenews'* | *'gamesnews'* 😏\n–\n# São 11 argumentações de uso, cada uma com um filtro de notícia! Esse comando é só pra notícias de jogos online, tá? Pra notícias de Time, use: _${prefix}esportenews_.\n–\n*01.* Call of Duty: ${prefix}gamenews -cod\n*02.* Counter-Strike: ${prefix}gamenews -csgo\n*03.* FIFA 2024: ${prefix}gamenews -fifa\n*04.* Fortnite: ${prefix}gamenews -fortnite\n*05.* GameXP: ${prefix}gamenews -gamexp\n*06.* PES 2024: ${prefix}gamenews -pes\n*07.* League of Legends: ${prefix}gamenews -lol\n*08.* Pokemon: ${prefix}gamenews -pokemon\n*09.* Rainbow 6: ${prefix}gamenews -r6\n*10.* Valorant: ${prefix}gamenews -valorant\n*11.* Pokemon TCG: ${prefix}gamenews -tcg\nDecorei tudo? 🤭`;
};

exports.helpNoticesEsporte = (sender, prefix) => {
  return `🤍 Olá @${sender.split("@")[0]}! Presta atenção no guia do comando: *'esporte_noticias'* | *'esportenews'* 😏\n–\n# São 18 argumentações de uso, cada uma com um filtro de notícia! Esse comando é só pra notícias de esportes, tá? Pra jogos online, use: _${prefix}gamenews_.\n–\n*01.* Todas as categorias agrupadas à um só parâmetro: ${prefix}esportenews -all\n*02.* Futebol: ${prefix}esportenews -futebol\n*03.* Futsal: ${prefix}esportenews -futsal\n*04.* Skate: ${prefix}esportenews -skate\n*05.* Surfe: ${prefix}esportenews -surf\n*06.* Basquete: ${prefix}esportenews -basquete\n*07.* Vôlei: ${prefix}esportenews -volei\n*08.* Tênis: ${prefix}esportenews -tenis\n*09.* Atletismo: ${prefix}esportenews -atletismo\n*10.* Natação: ${prefix}esportenews -natacao\n*11.* Ciclismo: ${prefix}esportenews -ciclismo\n*12.* Boxe: ${prefix}esportenews -boxe\n*13.* Beisebol: ${prefix}esportenews -beisebol\n*14.* Futebol EUA: ${prefix}esportenews -futebol-eua\n*15.* Judô: ${prefix}esportenews -judo\n*16.* Ginástica: ${prefix}esportenews -ginastica\n*17.* Golfe: ${prefix}esportenews -golfe\n*18.* Fórmula 1: ${prefix}esportenews -f1\nAnotou tudo? 🤭`;
};
