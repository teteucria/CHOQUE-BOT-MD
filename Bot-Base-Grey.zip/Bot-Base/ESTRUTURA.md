# kira Bot - Documentação da Estrutura do Projeto

## Visão Geral
Takira é um bot de WhatsApp construído com ourin-baileys (fork do Baileys). Versão 3.0.0.

## Estrutura de Diretórios

```
kira/
├── src/ # Código fonte principal (MODULAR)
│   ├── index.js # Ponto de entrada - inicialização do bot
│   ├── config/
│   │   └── index.js # Configuração centralizada (settings.json, links_img.json, logos.json)
│   ├── database/
│   │   └── index.js # Camada de banco de dados (JsonStore, GroupStore, modelos)
│   ├── core/
│   │   └── connection.js # Conexão Baileys, reconexão, pareamento
│   ├── commands/
│   │   ├── registry.js # Registro de comandos (carregar, registrar, alias, categoria)
│   │   ├── dispatcher.js # Execução de comandos com verificação de permissões
│   │   ├── admin/ # Comandos de admin (antilink, antispam, ban, etc.)
│   │   ├── downloads/ # Comandos de download (ytmp3, ytmp4, tiktok, etc.)
│   │   ├── membros/ # Comandos para membros (figurinhas, pesquisa, etc.)
│   │   ├── pesquisas/ # Comandos de busca (google, youtube, wikipedia, etc.)
│   │   ├── owner/ # Comandos exclusivos do dono (config, gerenciar, etc.)
│   │   ├── menus/ # Comandos de menu (menu admin, brincadeiras, etc.)
│   │   ├── ephotologos/ # Comandos de geração de logos e-foto
│   │   └── brincadeira/ # Comandos divertidos/random (rank, sigma, etc.)
│   ├── handlers/
│   │   ├── messageUtils.js # Extração de corpo, flags de mídia, getBaileys, etc.
│   │   ├── dataLoader.js # Carregamento lazy de dados de grupo/global
│   │   ├── antiSpam.js # Anti-spam, anti-palavrão, mute, anti-status
│   │   ├── antiLink.js # Anti-link hard/easy
│   │   ├── antiMedia.js # Anti-mídia (imagem, vídeo, áudio, figurinha, etc.)
│   │   ├── autoDown.js # Auto-download de vídeos de redes sociais
│   │   ├── autoSticker.js # Auto-conversão de mídia para figurinhas
│   │   ├── welcome.js # Mensagens de boas-vindas/saída + antifake/anti-DDD
│   │   └── specials.js # Eval (>), simi IA, prefixo echo
│   └── utils/
│       ├── helpers.js # Funções utilitárias (isUrl, sleep, readJSON, etc.)
│       ├── messages.js # Mensagens de erro/resposta (objeto mess)
│       ├── logger.js # Logger Pino + banner cfonts
│       └── commandList.js # Lista de comandos para sugestões de similaridade
├── settings/ # Arquivos de configuração
│   ├── settings.json # Config do bot (prefixo, nome, dono, chaves de API)
│   ├── links_img.json # Links/imagens para menus/ranks
│   ├── logos.json # Assets de logos
│   └── imports/
│       └── antispam.json # Lista de palavras anti-spam
├── arquivos/ # Arquivos utilitários originais (mantidos intactos)
│   ├── funcoes/ # Funções utilitárias (functions.js, antispam.js, etc.)
│   ├── stickers/ # Processamento de figurinhas (exif, rename, etc.)
│   └── database/ # Arquivos de armazenamento do banco de dados
│       ├── usuarios/ # Dados de usuários (mute, take, banned)
│       ├── grupos/ # Dados de mapeamento de grupos
│       └── antilink_proibido.json
├── db/ # Diretório do banco de dados (criado automaticamente)
│   └── data/ # Arquivos de banco de dados (grupos/, nesc.json, etc.)
├── logs/ # Arquivos de log (criado automaticamente)
├── package.json # Dependências e scripts
└── PROJECT_STRUCTURE.md # Este arquivo
```

## Arquivos Principais e Onde Editar

### Configuração
| Arquivo | Propósito |
|---------|-----------|
| `settings/settings.json` | Config do bot (prefixo, nome, dono, chaves de API) |
| `settings/links_img.json` | Links de imagens para menus/ranks |
| `settings/logos.json` | Assets de logos |
| `settings/imports/antispam.json` | Lista de palavras anti-spam |

### Ponto de Entrada
| Arquivo | Propósito |
|---------|-----------|
| `src/index.js` | Ponto de entrada principal - loop de processamento de mensagens |

### Banco de Dados
| Arquivo | Propósito |
|---------|-----------|
| `src/database/index.js` | Modelos de banco de dados (Grupo, Nescessario, Muted, Banned, Take) |
| `db/data/` | Arquivos de banco de dados criados automaticamente |

### Conexão
| Arquivo | Propósito |
|---------|-----------|
| `src/core/connection.js` | Conexão Baileys, código QR, lógica de reconexão |

### Comandos
| Arquivo | Propósito |
|---------|-----------|
| `src/commands/registry.js` | Sistema de registro de comandos |
| `src/commands/dispatcher.js` | Execução de comandos com verificação de permissões |
| `src/commands/admin/` | Comandos de admin/moderação |
| `src/commands/downloads/` | Comandos de download |
| `src/commands/membros/` | Comandos utilitários para membros |
| `src/commands/pesquisas/` | Comandos de busca |
| `src/commands/owner/` | Comandos exclusivos do dono |
| `src/commands/menus/` | Comandos de exibição de menu |
| `src/commands/ephotologos/` | Comandos de geração de logos e-foto |
| `src/commands/brincadeira/` | Comandos divertidos/random |

### Handlers
| Arquivo | Propósito |
|---------|-----------|
| `src/handlers/messageUtils.js` | Parsing de mensagens, flags de mídia, detecção de tipo |
| `src/handlers/antiSpam.js` | Anti-spam, anti-palavrão, mute, anti-status |
| `src/handlers/antiLink.js` | Anti-link hard/easy |
| `src/handlers/antiMedia.js` | Anti-mídia (imagem, vídeo, áudio, figurinha, contato, etc.) |
| `src/handlers/autoDown.js` | Auto-download de vídeos de redes sociais |
| `src/handlers/autoSticker.js` | Auto-conversão de mídia para figurinhas |
| `src/handlers/welcome.js` | Mensagens de boas-vindas/saída |
| `src/handlers/specials.js` | Eval (>), simi IA, prefixo echo |
| `src/handlers/dataLoader.js` | Carregamento lazy de dados para grupos |

### Utilitários
| Arquivo | Propósito |
|---------|-----------|
| `src/utils/helpers.js` | Funções utilitárias principais |
| `src/utils/messages.js` | Mensagens de erro/resposta (objeto mess) |
| `src/utils/logger.js` | Logger Pino + banner |
| `src/utils/commandList.js` | Lista de comandos para sugestões de similaridade |

## Adicionando um Novo Comando

1. Crie o arquivo na pasta de categoria apropriada dentro de `src/commands/`
2. Exporte com `module.exports = { nome: ["command", "alias"], executar: async (ctx) => { ... } }`
3. O comando é carregado automaticamente pelo registry na inicialização

## Adicionando um Novo Handler

1. Crie o arquivo em `src/handlers/`
2. Exporte a função handler
3. Importe e chame-a em `src/index.js` dentro de `processMessages()`

## Adicionando uma Nova Função Utilitária

1. Adicione a `src/utils/helpers.js`
2. Exporte no `module.exports` no final do arquivo
3. Importe onde necessário usando `require("../utils/helpers")`

## Notas Importantes

- **NÃO modifique** arquivos em `arquivos/funcoes/` a menos que saiba o que está fazendo
- **NÃO modifique** arquivos em `arquivos/stickers/` a menos que saiba o que está fazendo
- A pasta `settings/imports/` deve conter apenas `antispam.json`
- A pasta `db/` é criada e gerenciada automaticamente pela camada de banco de dados
- A pasta `logs/` é criada automaticamente pelo logger

## Executando o Bot

```bash
npm start # Inicia o bot
npm run dev # Inicia com auto-reinício em mudanças de arquivo
```