# Grey Pack integrado na Bot-Base

Pacote inspirado nas funções públicas presentes no grey-bot-free, adaptado para o sistema modular da Bot-Base.
Não substitui `src/index.js`, `registry.js`, `dispatcher.js` ou a conexão.

Comandos adicionados:
- cantada / cantadas
- conselho / conselhos
- fato / fatos
- caracoroa / caracoroa
- dado / dados
- 8ball / bola8
- saldo / coins / dinheiro
- daily / diario
- rankcoins / rankingcoins
- anagrama
- minado / mines

Os dados novos ficam em `db/data/grey/`.
