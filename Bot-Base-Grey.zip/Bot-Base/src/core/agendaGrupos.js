// Motor do agendamento de abrir/fechar grupo (-agendargp).
// Sem isso, o comando só salvava o horário num arquivo mas nada
// realmente fechava/abria o grupo na hora certa.

const moment = require("moment-timezone");
const { getFecharAbrir } = require("../utils/ctxExtras");

const executadosHoje = new Map(); // key: `${grupo}_${tipo}_${horario}` -> "YYYY-MM-DD" já executado

function horaAtual() {
  return moment().tz("America/Sao_Paulo").format("HH:mm");
}

function diaAtual() {
  return moment().tz("America/Sao_Paulo").format("YYYY-MM-DD");
}

async function verificarAgendamentos(kira) {
  const agendados = getFecharAbrir();
  if (!Array.isArray(agendados) || !agendados.length) return;

  const agora = horaAtual();
  const hoje = diaAtual();

  for (const item of agendados) {
    if (!item?.ativo || !item?.grupo) continue;

    if (item.fechar === agora) {
      const chave = `${item.grupo}_fechar_${item.fechar}`;
      if (executadosHoje.get(chave) !== hoje) {
        executadosHoje.set(chave, hoje);
        try {
          await kira.groupSettingUpdate(item.grupo, "announcement");
          await kira.sendMessage(item.grupo, {
            text: "🔐 Hmph! Já bateu a hora marcada... Fechei o grupo, só admin fala agora, viu?!"
          });
        } catch (e) {
          console.log("❌ [agendaGrupos] Erro ao fechar:", e?.message || e);
        }
      }
    }

    if (item.abrir === agora) {
      const chave = `${item.grupo}_abrir_${item.abrir}`;
      if (executadosHoje.get(chave) !== hoje) {
        executadosHoje.set(chave, hoje);
        try {
          await kira.groupSettingUpdate(item.grupo, "not_announcement");
          await kira.sendMessage(item.grupo, {
            text: "🔓 Hmph! Já bateu a hora marcada... Abri o grupo de novo, podem voltar a falar!"
          });
        } catch (e) {
          console.log("❌ [agendaGrupos] Erro ao abrir:", e?.message || e);
        }
      }
    }
  }
}

function iniciarAgendadorGrupos(kira) {
  setInterval(() => {
    verificarAgendamentos(kira).catch((e) => console.log("❌ [agendaGrupos]:", e?.message || e));
  }, 60 * 1000);
}

module.exports = { iniciarAgendadorGrupos };
