const fs = require("fs-extra");
const { Readable } = require("stream");
const { getBuffer } = require("../../arquivos/funcoes/functions.js");

let _fileTypeModule = null;
async function getFileTypeModule() {
  if (!_fileTypeModule) _fileTypeModule = await import("file-type");
  return _fileTypeModule;
}

const MIME_BY_EXT = {
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp",
  gif: "image/gif", bmp: "image/bmp", svg: "image/svg+xml",
  mp4: "video/mp4", mov: "video/quicktime", avi: "video/x-msvideo",
  webm: "video/webm", mkv: "video/x-matroska", m4v: "video/x-m4v",
  mp3: "audio/mpeg", m4a: "audio/mp4", ogg: "audio/ogg", opus: "audio/opus",
  wav: "audio/wav", aac: "audio/aac", amr: "audio/amr",
  pdf: "application/pdf", doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ppt: "application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  txt: "text/plain", zip: "application/zip", rar: "application/vnd.rar",
  "7z": "application/x-7z-compressed", apk: "application/vnd.android.package-archive",
  json: "application/json", csv: "text/csv",
};

function extFromSource(value) {
  const clean = String(value || "").split("?")[0].split("#")[0];
  const match = clean.match(/\.([a-zA-Z0-9]{2,5})$/);
  return match ? match[1].toLowerCase() : null;
}

async function detectMimetype(bytes, source, fallback) {
  try {
    const ft = await getFileTypeModule();
    if (bytes && bytes.length) {
      const res = await ft.fileTypeFromBuffer(bytes);
      if (res && res.mime) return res.mime;
    }
  } catch {}
  const ext = extFromSource(source);
  if (ext && MIME_BY_EXT[ext]) return MIME_BY_EXT[ext];
  return fallback;
}

async function resolveMediaInput(input, fallbackMime) {
  if (input == null) throw new Error("Mídia ausente");
  if (Buffer.isBuffer(input)) {
    return { media: input, mimetype: await detectMimetype(input, "", fallbackMime) };
  }
  if (input instanceof ArrayBuffer) {
    const buf = Buffer.from(input);
    return { media: buf, mimetype: await detectMimetype(buf, "", fallbackMime) };
  }
  if (input instanceof Uint8Array) {
    const buf = Buffer.from(input);
    return { media: buf, mimetype: await detectMimetype(buf, "", fallbackMime) };
  }
  if (typeof input === "string") {
    if (/^data:/.test(input)) {
      const buf = Buffer.from(String(input).split(",")[1] || "", "base64");
      return { media: buf, mimetype: await detectMimetype(buf, "", fallbackMime) };
    }
    if (/^https?:\/\//i.test(input)) {
      const buf = await getBuffer(input);
      if (!buf) throw new Error("Falha ao baixar mídia remota: " + String(input).slice(0, 80));
      return { media: buf, mimetype: await detectMimetype(buf, input, fallbackMime) };
    }
    if (fs.existsSync(input)) {
      return { media: input, mimetype: await detectMimetype(null, input, fallbackMime) };
    }
    return { media: input, mimetype: fallbackMime };
  }
  if (input && typeof input === "object" && input.url) {
    return resolveMediaInput(input.url, fallbackMime);
  }
  throw new Error("Tipo de mídia não suportado");
}

const HEADER_MEDIA_CACHE = new Map();

async function uploadHeaderMedia(kira, url, kind) {
  const cacheKey = kind + ":" + url;
  if (HEADER_MEDIA_CACHE.has(cacheKey)) return HEADER_MEDIA_CACHE.get(cacheKey);
  const resolved = await resolveMediaInput(url, kind === "image" ? "image/png" : "video/mp4");
  const up = await kira.client.message.upload(resolved.media, {
    type: kind,
    mimetype: resolved.mimetype,
  });
  const fields = {
    url: up.url,
    directPath: up.directPath,
    mediaKey: up.mediaKey,
    fileSha256: up.fileSha256,
    fileEncSha256: up.fileEncSha256,
    fileLength: up.fileLength,
    mediaKeyTimestamp: up.mediaKeyTimestamp,
    mimetype: up.mimetype || resolved.mimetype,
  };
  HEADER_MEDIA_CACHE.set(cacheKey, fields);
  return fields;
}

async function buildInteractiveProto(im, kira) {
  const interactive = {
    body: { text: im.title || "" },
  };
  if (im.footer) interactive.footer = { text: im.footer };
  if (im.image && im.image.url) {
    interactive.header = {
      imageMessage: await uploadHeaderMedia(kira, im.image.url, "image"),
      hasMediaAttachment: true,
    };
  } else if (im.video && im.video.url) {
    interactive.header = {
      videoMessage: await uploadHeaderMedia(kira, im.video.url, "video"),
      hasMediaAttachment: true,
    };
  }
  if (im.buttons && im.buttons.length) {
    interactive.nativeFlowMessage = {
      buttons: im.buttons.map((b) => ({
        name: b.name || "quick_reply",
        buttonParamsJson: b.buttonParamsJson || JSON.stringify({}),
      })),
      messageVersion: 1,
    };
  }
  return { interactiveMessage: interactive };
}

function toEditKey(edit) {
  if (!edit) return undefined;
  if (edit.key) return { id: edit.key.id, participant: edit.key.participant };
  return { id: edit.id, participant: edit.participant };
}

function buildKeyResult(jid, result) {
  return { key: { remoteJid: jid, id: result.id, fromMe: true }, result };
}

async function translateSend(kira, jid, content, options = {}) {
  const opts = { ...options };
  if (opts.quoted) {
    opts.quote = opts.quoted;
    delete opts.quoted;
  }

  let payload = content;
  if (content && typeof content === "object" && !Array.isArray(content)) {
    payload = { ...content };
    if (payload.edit) {
      opts.editKey = toEditKey(payload.edit);
      delete payload.edit;
    }
    if (payload.mentions && !opts.mentions) {
      opts.mentions = payload.mentions;
      delete payload.mentions;
    }
  }

  if (payload && typeof payload === "object" && !Array.isArray(payload)) {
    if (payload.text !== undefined) {
      const textContent = { type: "text", text: String(payload.text ?? "") };
      if (payload.contextInfo) textContent.contextInfo = { raw: payload.contextInfo };
      const result = await kira.client.message.send(jid, textContent, opts);
      if (payload.react) {
        await kira.client.message.send(jid, {
          type: "reaction",
          emoji: payload.react.text || "",
          target: payload.react.key,
        }, {});
      }
      return buildKeyResult(jid, result);
    }

    if (payload.react) {
      const result = await kira.client.message.send(jid, {
        type: "reaction",
        emoji: payload.react.text || "",
        target: payload.react.key,
      }, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.delete) {
      const d = payload.delete;
      const result = await kira.client.message.send(jid, {
        type: "revoke",
        target: {
          remoteJid: d.remoteJid,
          id: d.id,
          fromMe: !!d.fromMe,
          participant: d.participant,
        },
      }, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.interactiveMessage) {
      const proto = await buildInteractiveProto(payload.interactiveMessage, kira);
      const result = await kira.client.message.send(jid, proto, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.image !== undefined) {
      const resolved = await resolveMediaInput(payload.image, "image/jpeg");
      const imgContent = { type: "image", media: resolved.media, mimetype: resolved.mimetype };
      if (payload.caption !== undefined) imgContent.caption = payload.caption;
      if (payload.gifPlayback) imgContent.gifPlayback = true;
      const result = await kira.client.message.send(jid, imgContent, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.video !== undefined) {
      const resolved = await resolveMediaInput(payload.video, "video/mp4");
      const videoContent = {
        type: "video",
        media: resolved.media,
        mimetype: payload.mimetype || resolved.mimetype,
      };
      if (payload.caption !== undefined) videoContent.caption = payload.caption;
      if (payload.gifPlayback) videoContent.gifPlayback = true;
      const result = await kira.client.message.send(jid, videoContent, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.audio !== undefined) {
      const resolved = await resolveMediaInput(payload.audio, "audio/mp4");
      const audioContent = {
        type: "audio",
        media: resolved.media,
        mimetype: payload.mimetype || resolved.mimetype,
      };
      if (payload.ptt) audioContent.ptt = true;
      const result = await kira.client.message.send(jid, audioContent, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.sticker !== undefined) {
      const resolved = await resolveMediaInput(payload.sticker, "image/webp");
      const stickerContent = {
        type: "sticker",
        media: resolved.media,
        mimetype: payload.mimetype || resolved.mimetype,
      };
      const result = await kira.client.message.send(jid, stickerContent, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.document !== undefined) {
      const resolved = await resolveMediaInput(payload.document, "application/octet-stream");
      const docContent = {
        type: "document",
        media: resolved.media,
        mimetype: payload.mimetype || resolved.mimetype,
      };
      if (payload.fileName) docContent.fileName = payload.fileName;
      if (payload.caption) docContent.caption = payload.caption;
      const result = await kira.client.message.send(jid, docContent, opts);
      return buildKeyResult(jid, result);
    }

    if (payload.poll) {
      const result = await kira.client.message.send(jid, {
        type: "poll",
        name: payload.poll.name || "",
        options: payload.poll.options || [],
        selectableCount: payload.poll.selectableCount || 1,
      }, opts);
      return buildKeyResult(jid, result);
    }
  }

  const fallback = typeof payload === "string" ? payload : payload?.message || payload;
  const result = await kira.client.message.send(jid, fallback, opts);
  return buildKeyResult(jid, result);
}

function toBaileysGroup(m) {
  return {
    id: m.jid,
    subject: m.subject || "",
    subjectOwner: m.subjectOwner,
    subjectTime: m.subjectTime,
    owner: m.owner,
    desc: m.desc || "",
    descId: m.descId,
    restrict: m.restrict,
    announce: m.announce,
    creation: m.creation,
    ephemeral: m.ephemeral,
    participants: (m.participants || []).map((p) => ({
      id: p.phoneNumber || p.jid,
      phoneNumber: p.phoneNumber,
      lid: p.lid || (p.jid && p.jid.endsWith("@lid") ? p.jid : undefined),
      admin: p.isAdmin ? "admin" : p.isSuperAdmin ? "superadmin" : undefined,
    })),
  };
}

function mapParticipantResults(list, results) {
  const safe = results && results.length ? results : null;
  return list.map((jid) => {
    const r = safe ? safe.find((x) => x.jid === jid) : undefined;
    if (r) return { jid, status: String(r.code), code: r.code, raw: r.raw };
    return { jid, status: "500", code: 500 };
  });
}

function buildkira(client) {
  const kira = {
    user: { id: "", name: "kira" },
    client,
    refreshUser() {
      try {
        const creds = client.getCredentials();
        if (creds && creds.meJid) {
          kira.user.id = creds.meJid;
          kira.user.name = creds.meDisplayName || creds.pushName || "kira";
        }
      } catch {}
    },
    async sendMessage(jid, content, options) {
      return translateSend(kira, jid, content, options);
    },
    async groupMetadata(jid) {
      const m = await client.group.queryGroupMetadata(jid);
      return toBaileysGroup(m);
    },
    async groupFetchAllParticipating() {
      const groups = await client.group.queryAllGroups();
      const result = {};
      for (const g of groups) result[g.jid] = toBaileysGroup(g);
      return result;
    },
    async groupParticipantsUpdate(jid, participants, action) {
      const list = Array.isArray(participants) ? participants : [participants];
      try {
        let results;
        if (action === "add") results = await client.group.addParticipants(jid, list);
        else if (action === "remove") results = await client.group.removeParticipants(jid, list);
        else if (action === "promote") results = await client.group.promoteParticipants(jid, list);
        else if (action === "demote") results = await client.group.demoteParticipants(jid, list);
        else throw new Error("Ação desconhecida: " + action);
        return mapParticipantResults(list, results);
      } catch (e) {
        return list.map((jid) => ({ jid, status: "500", code: 500 }));
      }
    },
    async groupUpdateSubject(jid, subject) {
      await client.group.setSubject(jid, subject);
    },
    async groupUpdateDescription(jid, description) {
      await client.group.setDescription(jid, description);
    },
    async groupSettingUpdate(jid, setting) {
      const map = {
        announcement: ["announcement", true],
        not_announcement: ["announcement", false],
        locked: ["restrict", true],
        unlocked: ["restrict", false],
        unrestrict: ["restrict", false],
      };
      const [name, enabled] = map[setting] || [];
      if (!name) throw new Error("Configuração desconhecida: " + setting);
      await client.group.setSetting(jid, name, enabled);
    },
    async groupInviteCode(jid) {
      return client.group.queryInviteCode(jid);
    },
    async groupRevokeInvite(jid) {
      const r = await client.group.revokeInvite(jid);
      return { code: r.code };
    },
    async groupAcceptInvite(code) {
      return client.group.joinGroupViaInvite(code);
    },
    async groupLeave(jid) {
      await client.group.leaveGroup([jid]);
    },
    async groupRequestParticipantsList(jid) {
      const list = await client.group.queryMembershipApprovalRequests(jid);
      return (list || []).map((r) => ({ jid: r.jid }));
    },
    async groupRequestParticipantsUpdate(jid, participants, action) {
      const list = Array.isArray(participants) ? participants : [participants];
      if (action === "approve") await client.group.approveMembershipRequests(jid, list);
      else if (action === "reject") await client.group.cancelMembershipRequests(jid, list);
      else throw new Error("Ação desconhecida: " + action);
    },
    async sendImageAsSticker(jid, url, options = {}) {
      const { sendImageAsSticker } = require("../../arquivos/stickers/rename.js");
      return sendImageAsSticker(this, jid, url, undefined, options);
    },
    async sendVideoAsSticker(jid, url, options = {}) {
      const { sendVideoAsSticker } = require("../../arquivos/stickers/rename.js");
      return sendVideoAsSticker(this, jid, url, undefined, options);
    },
    async profilePictureUrl(jid, type = "image") {
      const r = await client.profile.getProfilePicture(jid, type);
      return r ? r.url : undefined;
    },
    async updateProfilePicture(jid, { url } = {}) {
      const resolved = await resolveMediaInput(url, "image/jpeg");
      return client.profile.setProfilePicture(resolved.media, jid);
    },
    async updateBlockStatus(jid, action) {
      if (action === "block") return client.privacy.blockUser(jid);
      if (action === "unblock") return client.privacy.unblockUser(jid);
      throw new Error("Ação de bloqueio desconhecida: " + action);
    },
    async sendPresenceUpdate(type = "available") {
      return client.presence.send(type === "available" ? "available" : "unavailable");
    },
    async readMessages(keys) {
      for (const k of keys || []) {
        try {
          await client.message.sendReceipt(k.remoteJid, k.id, {
            type: "read",
            participant: k.participant,
          });
        } catch {}
      }
    },
    async onWhatsApp(id) {
      return [{ exists: true, jid: require("zapo-js").normalizeRecipientJid(String(id)) }];
    },
    async downloadMediaMessage(msg, type = "buffer") {
      const proto = msg?.message || msg;
      if (type === "stream") return client.message.download(proto);
      const bytes = await client.message.downloadBytes(proto);
      return Buffer.from(bytes);
    },
  };
  return kira;
}

function createZapoClient({ client, onMessage, onGroupParticipants, onCall, connState }) {
  const kira = buildkira(client);

  const isSessionOpen = () => !connState || connState.open === true;

  const isFreshMessage = (event) => {
    const ts = event.timestampSeconds;
    if (typeof ts !== "number") return true;
    const openAt = connState?.openAt || 0;
    return openAt === 0 || ts * 1000 >= openAt;
  };

  client.on("message", async (event) => {
    if (!onMessage) return;
    if (!event.message) return;
    if (!isSessionOpen()) return;
    if (!isFreshMessage(event)) return;
    const info = {
      key: event.key,
      message: event.message,
      pushName: event.pushName || "",
      messageTimestamp: event.timestampSeconds,
      participantAlt: event.key?.participantAlt,
      remoteJidAlt: event.key?.remoteJidAlt,
    };
    await onMessage(kira, { type: "notify", messages: [info] });
  });

  client.on("group", async (event) => {
    if (!onGroupParticipants) return;
    if (!isSessionOpen()) return;
    const acoesAceitas = [
      "add", "remove", "promote", "demote",
      "subject", "description", "restrict", "announce"
    ];
    if (!acoesAceitas.includes(event.action)) return;
    if (!event.groupJid) return;
    const baileysEvent = {
      id: event.groupJid,
      author: event.authorJid,
      action: event.action,
      subject: event.subject,
      description: event.description,
      enabled: event.enabled,
      participants: (event.participants || [])
        .map((p) => p.phoneJid || p.jid || p.lidJid)
        .filter(Boolean),
    };
    await onGroupParticipants(kira, baileysEvent);
  });

  client.on("picture", async (event) => {
    if (!onGroupParticipants) return;
    if (!isSessionOpen()) return;
    if (!event.chatJid || !event.chatJid.endsWith("@g.us")) return; // só grupos
    const baileysEvent = {
      id: event.chatJid,
      author: event.authorJid,
      action: "picture",
      pictureAction: event.action, // 'set' ou 'delete'
      participants: [],
    };
    await onGroupParticipants(kira, baileysEvent);
  });

  client.on("call", (event) => {
    if (!isSessionOpen()) return;
    if (onCall) onCall(event);
  });

  return kira;
}

module.exports = {
  createZapoClient,
  buildkira,
  translateSend,
  resolveMediaInput,
};
