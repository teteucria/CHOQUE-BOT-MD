const readline = require("readline");
const path = require("path");
const fs = require("fs-extra");
const chalk = require("chalk");
const cfonts = require("cfonts");

// Força o WebSocket do undici mesmo em Node novo (>=22) que já tem WebSocket nativo,
// pois a implementação nativa se comporta diferente e causa timeout com o zapo-js.
globalThis.WebSocket = require("undici").WebSocket;

const nodeCrypto = require("crypto");
if (typeof nodeCrypto.hash !== "function") {
  nodeCrypto.hash = (algorithm, data, outputEncoding) =>
    nodeCrypto.createHash(algorithm).update(data).digest(outputEncoding);
}

const { WaClient, createStore, createPinoLogger } = require("zapo-js");
const { createJsonStoreBackend } = require("./jsonStoreBackend");
const { createZapoClient } = require("./zapoClient");
const { kiraLogger } = require("../utils/logger");
const { connState, setOpen, setClosed, setShuttingDown } = require("./connState");

function banner() {
  cfonts.say("Kira V11", {
    font: "block",
    align: "center",
    colors: ["cyan", "magenta"],
    background: "transparent",
    letterSpacing: 1,
    lineHeight: 1,
    space: true,
    maxLength: "0",
    gradient: false,
    independentGradient: false,
    transitionGradient: false,
    env: "node",
  });
};

function collectNumbers(inputString) {
  return inputString.replace(/\D/g, "");
}

let restarting = false;

async function waitPairingReady(client, logger, timeoutMs = 60000) {
  const isReady = () => {
    try { return client.getState()?.connected; } catch { return false; }
  };
  if (isReady()) return;
  await new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearInterval(interval);
      client.off("auth_qr", finish);
      client.off("auth_pairing_required", finish);
      resolve();
    };
    const interval = setInterval(() => { if (isReady()) finish(); }, 500);
    client.once("auth_qr", finish);
    client.once("auth_pairing_required", finish);
    setTimeout(() => {
      if (done) return;
      logger.warnLog("⏰Operando  Timeout ,aguardando conexão para pareamento 😍.");
      finish();
    }, timeoutMs);
    interval.unref?.();
  });
}

async function startConnection({ onMessage, onGroupParticipants, onCall }) {
  const authDir = path.join(__dirname, "..", "..", "arquivos", "database", "session");
  const jsonDir = path.join(authDir, "zapo", "json");
  fs.ensureDirSync(jsonDir);

  const store = createStore({
    backends: {
      json: createJsonStoreBackend({ dir: jsonDir }),
    },
    providers: {
      auth: "json",
      signal: "json",
      preKey: "json",
      session: "json",
      identity: "json",
      senderKey: "json",
      appState: "json",
      privacyToken: "json",
      messages: "none",
      threads: "none",
      contacts: "none",
    },
  });

  const logger = await createPinoLogger({ level: "error", name: "kira-zapo" });

  const client = new WaClient(
    {
      store,
      sessionId: "kira",
      deviceBrowser: "chrome",
      deviceOsDisplayName: "Linux",
      markOnlineOnConnect: true,
      recoverFromClientTooOld: true,
      connectTimeoutMs: 45000,
      iqTimeoutMs: 60000,
      messageAckTimeoutMs: 30000,
    },
    logger
  );

  const kira = createZapoClient({ client, onMessage, onGroupParticipants, onCall, connState });

  let persistedCreds = null;
  try {
    persistedCreds = await client.stores.auth.load();
  } catch {}
  const isFirstSession = !persistedCreds || !persistedCreds.meJid;
  let firstOpenHandled = false;

  kiraLogger.infoLog("🔐 Estou Iniciando conexão com WhatsApp 🫦...");
  kiraLogger.debugLog("📁 Diretório de auth", jsonDir);

  const runConnect = async () => {
    try {
      await client.connect();
    } catch (e) {
      kiraLogger.errorLog("❌ Erro ao conectar: " + (e?.message || e));
      setTimeout(() => {
        if (!restarting) runConnect();
      }, 5000);
    }
  };

  client.on("connection", (event) => {
    if (event.status === "open") {
      setOpen();
      banner();
      kiraLogger.infoLog("✅ Sessão aberta com sucesso!");
      kira.refreshUser();
      kiraLogger.infoLog(`🫦Nome: ${kira.user?.name || "Kira"}`);
      kira.sendPresenceUpdate("available").catch(() => {});

      if (isFirstSession && !firstOpenHandled) {
        firstOpenHandled = true;
        kiraLogger.infoLog("🎉 Primeira conexão confirmada! Vou reiniciar para estabilizar 🫦...");
        restarting = true;
        setTimeout(() => process.exit(0), 2000);
      }
    } else if (event.status === "close") {
      setClosed();
      if (!connState.shuttingDown) {
        kiraLogger.connectionLog("close", `reason: ${event.reason}, code: ${event.code}`);
      }

      if (event.isLogout) {
        process.exit(1);
      } else if (!connState.shuttingDown) {
        setTimeout(() => {
          if (!restarting) runConnect();
        }, 3000);
      }
    }
  });

  if (isFirstSession) {
    banner();
    console.log(`${chalk.cyan("Oii bb, estou operando em Modo pareamento — aguardando número 🫦..")}`);
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const question = (text) => new Promise((resolve) => rl.question(text, resolve));
    const phoneNumber = await question(`${chalk.magenta(" 📞 Insira o número (ex: 5588999999): ")}`);
    rl.close();
    const numerosColetados = collectNumbers(phoneNumber);

    const maxPairingAttempts = 3;
    let code = null;

    for (let attempt = 1; attempt <= maxPairingAttempts; attempt++) {
      kiraLogger.infoLog(`🔄 Tentativa de conexão ${attempt}/${maxPairingAttempts}...`);

      let connectFailed = false;
      await client.connect().catch((e) => {
        connectFailed = true;
        kiraLogger.errorLog("❌ 🤭 falha no pareamento: " + (e?.message || e));
      });

      if (!connectFailed) {
        await waitPairingReady(client, kiraLogger);
      }

      try {
        code = await client.auth.requestPairingCode(numerosColetados, true);
        break;
      } catch (e) {
        kiraLogger.errorLog(`❌ Não consegui pegar o código (tentativa ${attempt}): ` + (e?.message || e));
        if (attempt < maxPairingAttempts) {
          await new Promise((r) => setTimeout(r, 3000));
        }
      }
    }

    if (!code) {
      kiraLogger.errorLog("❌ Falha ao gerar código de pareamento após várias tentativas. Verifique sua conexão de internet e tente novamente.");
      process.exit(1);
    }

    console.log(`${chalk.magenta("Aqui bb, seu código pra por no WhatsApp 🫦:")} ${chalk.yellow.bold(code)}`);

    await client.connect();
  } else {
    runConnect();
  }

  process.on("SIGINT", async () => {
    setShuttingDown();
    try {
      await client.disconnect();
    } catch {}
    process.exit(0);
  });

  return kira;
}

module.exports = { startConnection };