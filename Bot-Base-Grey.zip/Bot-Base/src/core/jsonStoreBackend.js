const fs = require("fs-extra");
const path = require("path");
const { signalAddressKey } = require("zapo-js/protocol");
const { bytesToHex, uint8Equal } = require("zapo-js/util");
const { APP_STATE_EMPTY_LT_HASH } = require("zapo-js/appstate");

const SAVE_DEBOUNCE_MS = 300;
const HOST_DOMAIN = "s.whatsapp.net";

function toJSON(value, seen = new WeakSet()) {
  if (value === null || value === undefined) return value;
  const t = typeof value;
  if (t === "number" || t === "string" || t === "boolean") return value;
  if (t === "bigint") return value.toString();
  if (Buffer.isBuffer(value)) return { $b64: value.toString("base64") };
  if (value instanceof Uint8Array) {
    return { $b64: Buffer.from(value.buffer, value.byteOffset, value.byteLength).toString("base64") };
  }
  if (value instanceof ArrayBuffer) return { $arr: Array.from(new Uint8Array(value)) };
  if (ArrayBuffer.isView(value)) {
    return { $arr: Array.from(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)) };
  }
  if (typeof value !== "object") return value;
  if (seen.has(value)) return undefined;
  seen.add(value);
  if (Array.isArray(value)) {
    const out = [];
    for (const v of value) out.push(toJSON(v, seen));
    return out;
  }
  const out = {};
  for (const k of Object.keys(value)) out[k] = toJSON(value[k], seen);
  return out;
}

function fromJSON(value) {
  if (value === null || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map(fromJSON);
  if (Object.prototype.hasOwnProperty.call(value, "$b64")) return Buffer.from(value.$b64, "base64");
  if (Object.prototype.hasOwnProperty.call(value, "$arr")) return Buffer.from(value.$arr);
  const out = {};
  for (const k of Object.keys(value)) out[k] = fromJSON(value[k]);
  return out;
}

const allStores = new Set();
let lifecycleRegistered = false;

function registerStore(store) {
  allStores.add(store);
  if (lifecycleRegistered) return;
  lifecycleRegistered = true;
  process.on("exit", () => {
    for (const s of allStores) s.flush();
  });
  for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {
    process.on(sig, () => {
      for (const s of allStores) s.flush();
    });
  }
}

function sanitize(id) {
  return String(id || "default").replace(/[^A-Za-z0-9_.-]/g, "_");
}

class BaseJsonStore {
  constructor(sessionId, dir, domain) {
    this.sessionId = sanitize(sessionId);
    this.dir = path.join(dir, domain);
    this.file = path.join(this.dir, `${this.sessionId}.json`);
    this._loaded = false;
    this._data = {};
    this._timer = null;
    registerStore(this);
  }

  _load() {
    if (this._loaded) return this._data;
    this._loaded = true;
    try {
      const raw = fs.readFileSync(this.file, "utf8");
      this._data = fromJSON(JSON.parse(raw)) || {};
    } catch {
      this._data = {};
    }
    if (typeof this._data !== "object" || Array.isArray(this._data)) this._data = {};
    return this._data;
  }

  _save() {
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this._write(), SAVE_DEBOUNCE_MS);
    this._timer.unref && this._timer.unref();
  }

  _write() {
    clearTimeout(this._timer);
    this._timer = null;
    try {
      fs.ensureDirSync(this.dir);
      fs.writeFileSync(this.file, JSON.stringify(toJSON(this._data)));
    } catch {}
  }

  flush() {
    if (!this._loaded) return;
    this._write();
  }
}

class AuthJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "auth");
  }
  async load() {
    return this._load().credentials ?? null;
  }
  async save(credentials) {
    this._load().credentials = credentials;
    this._save();
  }
  async clear() {
    this._load().credentials = null;
    this._save();
  }
}

class SignalJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "signal");
  }
  async getRegistrationInfo() {
    return this._load().registrationInfo ?? null;
  }
  async setRegistrationInfo(info) {
    this._load().registrationInfo = info;
    this._save();
  }
  async getSignedPreKey() {
    return this._load().signedPreKey ?? null;
  }
  async setSignedPreKey(record) {
    this._load().signedPreKey = record;
    this._save();
  }
  async getSignedPreKeyById(keyId) {
    const rec = this._load().signedPreKey;
    return rec && rec.keyId === keyId ? rec : null;
  }
  async setSignedPreKeyRotationTs(value) {
    this._load().signedPreKeyRotationTs = value;
    this._save();
  }
  async getSignedPreKeyRotationTs() {
    return this._load().signedPreKeyRotationTs ?? null;
  }
  async clear() {
    const d = this._load();
    d.registrationInfo = null;
    d.signedPreKey = null;
    d.signedPreKeyRotationTs = null;
    this._save();
  }
}

class PreKeyJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "preKey");
  }
  async putPreKey(record) {
    const d = this._load();
    d.preKeys = d.preKeys || {};
    d.preKeys[record.keyId] = record;
    const next = d.nextPreKeyId ?? 1;
    if (record.keyId >= next) d.nextPreKeyId = record.keyId + 1;
    this._save();
  }
  async getOrGenPreKeys(count, generator) {
    if (!Number.isSafeInteger(count) || count <= 0) throw new Error(`invalid prekey count: ${count}`);
    const d = this._load();
    d.preKeys = d.preKeys || {};
    d.uploaded = d.uploaded || {};
    d.nextPreKeyId = d.nextPreKeyId ?? 1;
    const availableKeyIds = [];
    for (const rawId of Object.keys(d.preKeys)) {
      if (!d.uploaded[rawId]) availableKeyIds.push(Number(rawId));
    }
    availableKeyIds.sort((a, b) => a - b);
    const out = [];
    for (const id of availableKeyIds) {
      const record = d.preKeys[id];
      if (!record) continue;
      out.push(record);
      if (out.length >= count) return out;
    }
    while (out.length < count) {
      const record = await generator(d.nextPreKeyId++);
      d.preKeys[record.keyId] = record;
      out.push(record);
    }
    this._save();
    return out;
  }
  async getPreKeyById(keyId) {
    return this._load().preKeys?.[keyId] ?? null;
  }
  async getPreKeysById(keyIds) {
    const d = this._load();
    const out = new Array(keyIds.length);
    for (let i = 0; i < keyIds.length; i++) out[i] = d.preKeys?.[keyIds[i]] ?? null;
    return out;
  }
  async consumePreKeyById(keyId) {
    const d = this._load();
    const record = d.preKeys?.[keyId] ?? null;
    if (record) {
      delete d.preKeys[keyId];
      if (d.uploaded) delete d.uploaded[keyId];
      this._save();
    }
    return record;
  }
  async getOrGenSinglePreKey(generator) {
    const [record] = await this.getOrGenPreKeys(1, generator);
    return record;
  }
  async markKeyAsUploaded(keyId) {
    const d = this._load();
    d.preKeys = d.preKeys || {};
    d.uploaded = d.uploaded || {};
    d.nextPreKeyId = d.nextPreKeyId ?? 1;
    if (keyId < 0 || keyId >= d.nextPreKeyId) throw new Error(`prekey ${keyId} is out of boundary`);
    for (const candidate of Object.keys(d.preKeys)) {
      if (Number(candidate) <= keyId) d.uploaded[candidate] = true;
    }
    this._save();
  }
  async setServerHasPreKeys(value) {
    this._load().serverHasPreKeys = value;
    this._save();
  }
  async getServerHasPreKeys() {
    return this._load().serverHasPreKeys ?? false;
  }
  async markKeysUploaded(keyIds) {
    const d = this._load();
    d.uploaded = d.uploaded || {};
    for (const id of keyIds) d.uploaded[id] = true;
    this._save();
  }
  async setNextPreKeyId(value) {
    this._load().nextPreKeyId = value;
    this._save();
  }
  async clear() {
    const d = this._load();
    d.preKeys = {};
    d.uploaded = {};
    d.serverHasPreKeys = false;
    d.nextPreKeyId = 1;
    this._save();
  }
}

class SessionJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "session");
  }
  _key(address) {
    const server = address?.server ?? HOST_DOMAIN;
    return `${address.user}|${server}|${address.device}`;
  }
  async hasSession(address) {
    return Object.prototype.hasOwnProperty.call(this._load().sessions || {}, this._key(address));
  }
  async hasSessions(addresses) {
    const d = this._load();
    return addresses.map((a) => Object.prototype.hasOwnProperty.call(d.sessions || {}, this._key(a)));
  }
  async getSession(address) {
    return this._load().sessions?.[this._key(address)] ?? null;
  }
  async getSessionsBatch(addresses) {
    const d = this._load();
    return addresses.map((a) => d.sessions?.[this._key(a)] ?? null);
  }
  async setSession(address, session) {
    const d = this._load();
    d.sessions = d.sessions || {};
    d.sessions[this._key(address)] = session;
    this._save();
  }
  async setSessionsBatch(entries) {
    const d = this._load();
    d.sessions = d.sessions || {};
    for (const entry of entries) d.sessions[this._key(entry.address)] = entry.session;
    this._save();
  }
  async deleteSession(address) {
    const d = this._load();
    if (d.sessions) {
      delete d.sessions[this._key(address)];
      this._save();
    }
  }
  async clear() {
    this._load().sessions = {};
    this._save();
  }
}

class IdentityJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "identity");
  }
  _key(address) {
    const server = address?.server ?? HOST_DOMAIN;
    return `${address.user}|${server}|${address.device}`;
  }
  async getRemoteIdentity(address) {
    return this._load().remoteIdentities?.[this._key(address)] ?? null;
  }
  async getRemoteIdentities(addresses) {
    const d = this._load();
    return addresses.map((a) => d.remoteIdentities?.[this._key(a)] ?? null);
  }
  async setRemoteIdentity(address, identityKey) {
    const d = this._load();
    d.remoteIdentities = d.remoteIdentities || {};
    d.remoteIdentities[this._key(address)] = identityKey;
    this._save();
  }
  async setRemoteIdentities(entries) {
    const d = this._load();
    d.remoteIdentities = d.remoteIdentities || {};
    for (const entry of entries) d.remoteIdentities[this._key(entry.address)] = entry.identityKey;
    this._save();
  }
  async clear() {
    this._load().remoteIdentities = {};
    this._save();
  }
}

class SenderKeyJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "senderKey");
  }
  _key(groupId, sender) {
    const server = sender?.server ?? HOST_DOMAIN;
    return `${groupId}|${sender.user}|${server}|${sender.device}`;
  }
  async upsertSenderKey(record) {
    const d = this._load();
    d.senderKeys = d.senderKeys || {};
    d.senderKeys[this._key(record.groupId, record.sender)] = record;
    this._save();
  }
  async upsertSenderKeyDistribution(record) {
    const d = this._load();
    d.senderDistributions = d.senderDistributions || {};
    d.senderDistributions[this._key(record.groupId, record.sender)] = record;
    this._save();
  }
  async upsertSenderKeyDistributions(records) {
    const d = this._load();
    d.senderDistributions = d.senderDistributions || {};
    for (const record of records) d.senderDistributions[this._key(record.groupId, record.sender)] = record;
    this._save();
  }
  async getGroupSenderKeyList(groupId) {
    const d = this._load();
    const skList = [];
    const skDistribList = [];
    for (const record of Object.values(d.senderKeys || {})) if (record.groupId === groupId) skList.push(record);
    for (const record of Object.values(d.senderDistributions || {})) if (record.groupId === groupId) skDistribList.push(record);
    return { skList, skDistribList };
  }
  async getDeviceSenderKey(groupId, sender) {
    return this._load().senderKeys?.[this._key(groupId, sender)] ?? null;
  }
  async getDeviceSenderKeyDistributions(groupId, senders) {
    const d = this._load();
    return senders.map((s) => d.senderDistributions?.[this._key(groupId, s)] ?? null);
  }
  async deleteDeviceSenderKey(target, groupId) {
    let deleted = 0;
    const d = this._load();
    if (d.senderKeys) deleted += this._deleteMatching(d.senderKeys, target, groupId);
    if (d.senderDistributions) deleted += this._deleteMatching(d.senderDistributions, target, groupId);
    if (deleted) this._save();
    return deleted;
  }
  async markForgetSenderKey(groupId, participants) {
    let deleted = 0;
    const d = this._load();
    for (const participant of participants) {
      if (d.senderKeys) deleted += this._deleteMatching(d.senderKeys, participant, groupId);
      if (d.senderDistributions) deleted += this._deleteMatching(d.senderDistributions, participant, groupId);
    }
    if (deleted) this._save();
    return deleted;
  }
  async clear() {
    const d = this._load();
    d.senderKeys = {};
    d.senderDistributions = {};
    this._save();
  }
  _deleteMatching(map, target, groupId) {
    let deleted = 0;
    const targetKey = `${target.user}|${target.server ?? HOST_DOMAIN}|${target.device}`;
    for (const key of Object.keys(map)) {
      const record = map[key];
      const sameGroup = groupId ? record.groupId === groupId : true;
      const recordKey = `${record.sender.user}|${record.sender.server ?? HOST_DOMAIN}|${record.sender.device}`;
      if (sameGroup && recordKey === targetKey) {
        delete map[key];
        deleted++;
      }
    }
    return deleted;
  }
}

class AppStateJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "appState");
  }
  async exportData() {
    const d = this._load();
    const keys = Object.values(d.keys || {});
    const collections = {};
    for (const [name, st] of Object.entries(d.collections || {})) {
      collections[name] = {
        version: st.version,
        hash: st.hash,
        indexValueMap: st.indexValueMap || {},
      };
    }
    return { keys, collections };
  }
  async upsertSyncKeys(keys) {
    const d = this._load();
    d.keys = d.keys || {};
    let inserted = 0;
    for (const key of keys) {
      const hex = bytesToHex(key.keyId);
      const existing = d.keys[hex];
      if (existing && uint8Equal(existing.keyData, key.keyData)) continue;
      d.keys[hex] = key;
      inserted++;
    }
    if (inserted) this._save();
    return inserted;
  }
  async getSyncKeysBatch(keyIds) {
    const d = this._load();
    return keyIds.map((id) => d.keys?.[bytesToHex(id)] ?? null);
  }
  async getSyncKeyData(keyId) {
    return this._load().keys?.[bytesToHex(keyId)]?.keyData ?? null;
  }
  async getSyncKeyDataBatch(keyIds) {
    const d = this._load();
    return keyIds.map((id) => d.keys?.[bytesToHex(id)]?.keyData ?? null);
  }
  async getActiveSyncKey() {
    const keys = Object.values(this._load().keys || {});
    let active = null;
    for (const key of keys) {
      if (!active) {
        active = key;
        continue;
      }
      const currentEpoch = this._keyEpoch(active.keyId);
      const nextEpoch = this._keyEpoch(key.keyId);
      if (nextEpoch > currentEpoch) {
        active = key;
        continue;
      }
      if (nextEpoch < currentEpoch) continue;
      const nextDeviceId = this._keyDeviceId(key.keyId);
      const currentDeviceId = this._keyDeviceId(active.keyId);
      if (nextDeviceId !== null && currentDeviceId !== null && nextDeviceId < currentDeviceId) active = key;
    }
    return active;
  }
  async getCollectionState(collection) {
    const d = this._load();
    d.collections = d.collections || {};
    let st = d.collections[collection];
    if (!st) {
      st = {
        initialized: false,
        version: 0,
        hash: Buffer.from(APP_STATE_EMPTY_LT_HASH),
        indexValueMap: {},
      };
      d.collections[collection] = st;
    }
    return {
      initialized: st.initialized,
      version: st.version,
      hash: st.hash,
      indexValueMap: new Map(Object.entries(st.indexValueMap || {})),
    };
  }
  async getCollectionStates(collections) {
    const out = new Array(collections.length);
    for (let i = 0; i < collections.length; i++) out[i] = await this.getCollectionState(collections[i]);
    return out;
  }
  async setCollectionStates(updates) {
    const d = this._load();
    d.collections = d.collections || {};
    for (const update of updates) {
      const indexValueMap = {};
      if (update.indexValueMap instanceof Map) {
        for (const [key, value] of update.indexValueMap.entries()) indexValueMap[key] = value;
      } else {
        Object.assign(indexValueMap, update.indexValueMap);
      }
      d.collections[update.collection] = {
        initialized: true,
        version: update.version,
        hash: update.hash,
        indexValueMap,
      };
    }
    this._save();
  }
  async clear() {
    const d = this._load();
    d.keys = {};
    d.collections = {};
    this._save();
  }
  _keyEpoch(keyId) {
    if (!keyId || keyId.byteLength < 6) return -1;
    return keyId[2] * 16777216 + keyId[3] * 65536 + keyId[4] * 256 + keyId[5];
  }
  _keyDeviceId(keyId) {
    if (!keyId || keyId.byteLength < 6) return null;
    return (keyId[0] << 8) | keyId[1];
  }
}

class PrivacyTokenJsonStore extends BaseJsonStore {
  constructor(sessionId, dir) {
    super(sessionId, dir, "privacyToken");
  }
  async upsert(record) {
    const d = this._load();
    d.records = d.records || {};
    const existing = d.records[record.jid];
    d.records[record.jid] = existing ? this._merge(existing, record) : record;
    this._save();
  }
  async upsertBatch(records) {
    const d = this._load();
    d.records = d.records || {};
    for (const record of records) {
      const existing = d.records[record.jid];
      d.records[record.jid] = existing ? this._merge(existing, record) : record;
    }
    this._save();
  }
  async getByJid(jid) {
    return this._load().records?.[jid] ?? null;
  }
  async deleteByJid(jid) {
    const d = this._load();
    if (d.records && Object.prototype.hasOwnProperty.call(d.records, jid)) {
      delete d.records[jid];
      this._save();
      return 1;
    }
    return 0;
  }
  async clear() {
    this._load().records = {};
    this._save();
  }
  async destroy() {
    this._load().records = {};
    this._save();
  }
  _merge(existing, incoming) {
    return {
      jid: incoming.jid,
      tcToken: incoming.tcToken ?? existing.tcToken,
      tcTokenTimestamp: incoming.tcTokenTimestamp ?? existing.tcTokenTimestamp,
      tcTokenSenderTimestamp: incoming.tcTokenSenderTimestamp ?? existing.tcTokenSenderTimestamp,
      nctSalt: incoming.nctSalt ?? existing.nctSalt,
      updatedAtMs: incoming.updatedAtMs,
    };
  }
}

function createJsonStoreBackend({ dir }) {
  return {
    stores: {
      auth: (sessionId) => new AuthJsonStore(sessionId, dir),
      signal: (sessionId) => new SignalJsonStore(sessionId, dir),
      preKey: (sessionId) => new PreKeyJsonStore(sessionId, dir),
      session: (sessionId) => new SessionJsonStore(sessionId, dir),
      identity: (sessionId) => new IdentityJsonStore(sessionId, dir),
      senderKey: (sessionId) => new SenderKeyJsonStore(sessionId, dir),
      appState: (sessionId) => new AppStateJsonStore(sessionId, dir),
      privacyToken: (sessionId) => new PrivacyTokenJsonStore(sessionId, dir),
    },
    async destroy() {
      for (const s of allStores) s.flush();
    },
  };
}

module.exports = { createJsonStoreBackend, toJSON, fromJSON };
