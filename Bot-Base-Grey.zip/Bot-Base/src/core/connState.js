const state = {
  open: false,
  openAt: 0,
  shuttingDown: false,
};

module.exports = {
  connState: state,
  isOpen() {
    return state.open;
  },
  setOpen() {
    state.open = true;
    state.openAt = Date.now();
  },
  setClosed() {
    state.open = false;
  },
  setShuttingDown() {
    state.shuttingDown = true;
  },
  isShuttingDown() {
    return state.shuttingDown;
  },
};
