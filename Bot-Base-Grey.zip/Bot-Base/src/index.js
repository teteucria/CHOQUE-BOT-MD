const path = require("path");
const fs = require("fs-extra");
const moment = require("moment-timezone");
const axios = require("axios");

const config = require("./config");
const { Grupo, Nescessario, Muted, Banned, Take } = require("./database");
const { loadGroupData, loadGlobalData, loadMuted } = require("./handlers/dataLoader");
const { startConnection } = require("./core/connection");
const { iniciarAgendadorGrupos } = require("./core/agendaGrupos");
const { handleCommand, suggestCommand } = require("./commands/dispatcher");
const { handleAntiStatus, handleAntiPayment, handleAntiNotas, handleAntiPrivate, handleMute, handleAntiSpam, handleAntiPalavrao } = require("./handlers/antiSpam");
const { handleAntiFlood } = require("./handlers/antiFlood");
const { handleAntiGroupEdit } = require("./handlers/antiGroupEdit");
const {
httpAgent,
httpsAgent,
apiCache,
CACHE_TTL,
cacheGet,
cacheSet,
cacheKey,
cacheStats,
cacheFlush,
cachedFetchJson,
cachedFetchText,
cachedGetBuffer,
} = require("../arquivos/funcoes/httpAgent.js");
const { lidParaJid, sincronizarGrupo } = require("../arquivos/funcoes/mapeamento.js");
const { chyt, nit, supre } = require("../arquivos/funcoes/functions.js");
const { handleAntiLinkHard, handleAntiLinkEasy } = require("./handlers/antiLink");
const { handleAntiMedia } = require("./handlers/antiMedia");
const { handleAutoDown } = require("./handlers/autoDown");
const { handleAutoSticker, handleAutoStickerFfmpeg } = require("./handlers/autoSticker");
const { handleWelcome } = require("./handlers/welcome");
const { extractBody, extractQuotedBody, buildMediaFlags, buildQuotedFlags, getContentType } = require("./handlers/messageUtils");
const {
isUrl,
similarityCmd,
mess,
getGroupAdmins,
extractDDD,
extractStateFromDDD,
extractStateFromNumber,
getName,
sleep,
readJSON,
extractDomain,
registrarNumeroSuspeito,
jaProcessou,
marcarComoProcessado,
DLT_FL,
} = require("./utils/helpers");
const {
saveJSON,
getFecharAbrir,
saveFecharAbrir,
timeDate,
countDays,
getInfo,
pathAntiLink,
renameContextSticker,
gerarlinkUploadMedia,
pinterestSearch,
pinterestVideoV2,
obeso,
gerarCommandsJSON,
} = require("./utils/ctxExtras");
const { fundolevel, fundo2, fundo1, linklogos, imgnazista, imggay, imgcorno, imggostosa, imggostoso, imgfeio, imggado, imgvesgo, imgbebado, tapacmd, matarcmd, beijocmd, chutecmd, deathcmd, rnkgay, rnkgado, rnkcorno, rnkgostoso, rnkgostosa,
rnknazista, rnkotaku, rnkpau, suruba, minado_bomb, thumbnail, imgsigma, imgbeta, imgbaiano, imgbaiana, imgcarioca, imglouco, imglouca, imgsafada, imgsafado, imgmacaco, imgmacaca, imgputa, rnksigma, rnkbeta, rnkbaiano, rnkbaiana,
rnkcarioca, rnklouco, rnklouca, rnksafada, rnksafado, rnkmacaco, rnkmacaca, rnkputa, rnkfiel, rnkinfiel } = require("../settings/links_img.json");
const { handleEval, handleSimi, handlePrefixoEcho } = require("./handlers/specials");
const { kiraLogger } = require("./utils/logger");
const linguagem = require("../settings/imports/menus");

const { prefix, botName, ownerName, ownerNumber, apiUrl, apiKey } = config;

const commandsDir = path.join(__dirname, "commands");
require("./commands/registry").loadFromDirectory(commandsDir);

const arrayDDDs = [11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 24, 27, 28, 31, 32, 33,
34, 35, 37, 38, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 53, 54, 55,
61, 62, 63, 64, 65, 66, 67, 68, 69, 71, 73, 74, 75, 77, 79, 81, 82,
83, 84, 85, 86, 87, 88, 89, 91, 93, 94, 95, 96, 97, 98, 99];

function normalizeJid(groupId, jid) {
if (!jid) return "";
if (jid.includes("@lid")) return lidParaJid(groupId, jid);
if (jid.includes("@s.whatsapp.net")) return jid;
if (jid.includes("@g.us")) return jid;
if (jid.includes("@broadcast")) return jid;
return `${jid}@s.whatsapp.net`;
}

async function processMessages(upsert, kira) {
for (const info of upsert?.messages || []) {
if (!info.message) continue;

try {
const from = info.key.remoteJid || info.key.remoteJidAlt;
const isGroup = from?.endsWith("@g.us");
const groupMetadata = isGroup ? await kira.groupMetadata(from).catch(() => null) : null;
const groupName = groupMetadata?.subject || "";
let grupo = isGroup ? await Grupo.findOne({ groupId: from }) : null;
if (isGroup && !grupo) {
grupo = await Grupo.create({ groupId: from, name: groupName });
} else if (isGroup && grupo && grupo.name !== groupName) {
grupo.name = groupName;
await Grupo.updateOne({ groupId: from }, { $set: { name: groupName } });
}

const isStatus = from?.endsWith("@broadcast");

const pkgPath = require.resolve("zapo-js/package.json");
const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
const baileysVersion = pkg.version;

const type = getContentType(info.message);
if (type === "protocolMessage" || type === "reactionMessage" || type === "senderKeyDistributionMessage") continue;
const content = JSON.stringify(info.message);
const pushname = info.pushName || "";
const blacklist = (await Banned.findOne({})) || { numeros: {} };
const nescessario = await Nescessario.findOne({}) || await Nescessario.create({});
const muted = await Muted.find({});
const rgtake = await Take.find({});
const fecharAbrir = getFecharAbrir();
const grupoMute = (Array.isArray(muted) ? muted.find(i => i.grupo === from) : null) || { grupo: from, silenciados: [], mutados: [] };

const { visualizarmsg } = nescessario;

const emojimenu = "🌹";

if (visualizarmsg) {
await kira.readMessages([info.key]);
} else {
if (from === "status@broadcast") return;
}

const body = extractBody(info);
const Procurar_String = body || extractQuotedBody(info);

const args = body.trim().split(/ +/).slice(1);
const budy2 = body.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const isCmd = body.trim().startsWith(prefix);
const command = isCmd ? budy2.trim().slice(1).split(/ +/).shift().toLocaleLowerCase() : null;
const q = args.join(" ");
const query = args.join(" ");
const budy = type === "conversation" ? info.message?.conversation : type === "extendedTextMessage" ? info.message?.extendedTextMessage?.text : "";
const budy3 = budy.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
const PR_String = Procurar_String.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

const groupMembers = isGroup ? groupMetadata?.participants || [] : [];
const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : [];
const somembros = isGroup ? groupMembers.map(m => m.id) : [];

if (isGroup && groupMembers.length > 0) {
sincronizarGrupo(from, groupMembers);
}

const rawBotNumber = kira.user?.id?.split(":")[0] || "";
const botNumber = rawBotNumber.includes("@") ? rawBotNumber : rawBotNumber + "@s.whatsapp.net";
const rawSender = info.key.participant || info.key.participantAlt || info.key.remoteJidAlt || info.key.remoteJid || "";
const sender = isGroup ? normalizeJid(from, rawSender) : rawSender;

const numerodn = ownerNumber.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
const SoDono = sender.includes(numerodn);
if (!SoDono && !isGroup) console.log("🔎 [DEBUG DONO] sender recebido:", sender, "| esperado (numerodn):", numerodn, "| rawSender:", rawSender);
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false;
const isGroupAdmins = groupAdmins.includes(sender) || false || SoDono;
const isCargo = SoDono ? "MESTRE" : isGroupAdmins ? "ADMIN" : "MEMBRO";

const isAntiSpam = isGroup ? grupo?.antispam?.active : false;
const tempoAntiSpam = isGroup ? grupo?.antispam?.tempo : 5;
const isAntiImg = isGroup ? grupo?.antiimg : false;
const isAntiVid = isGroup ? grupo?.antivideo : false;
const isAntiAudio = isGroup ? grupo?.antiaudio : false;
const isAntiSticker = isGroup ? grupo?.antisticker : false;
const Antidoc = isGroup ? grupo?.antidoc : false;
const isAntiCtt = isGroup ? grupo?.antictt : false;
const Antiloc = isGroup ? grupo?.antiloc : false;
const isAntiDDD = isGroup ? grupo?.ANTI_DDD?.active : false;
const isAntilinkgp = isGroup ? grupo?.antilinkgp : false;
const isAntiLinkHard = isGroup ? grupo?.antilinkhard : false;
const isAntiLinkEasy = isGroup ? grupo?.antilinkeasy : false;
const isAntiNotas = isGroup ? grupo?.antinotas : false;
const isAntiStatus = isGroup ? grupo?.antistatus : false;
const isPayment = isGroup ? grupo?.antipagamento : false;
const isAnticatalogo = isGroup ? grupo?.anticatalogo : false;
const isWelkom = isGroup ? grupo?.wellcome?.[0]?.bemvindo1 : false;
const isSimi = isGroup ? grupo?.simi1 : false;
const isAutofigu = isGroup ? grupo?.autosticker?.isAutofigu : false;
const IsAutofigu = isGroup ? grupo?.autosticker?.IsAutofigu : false;
const autofigu = isGroup ? grupo?.autosticker?.autofigu : false;
const isAutorepo = isGroup ? grupo?.autoresposta : false;
const isModobn = isGroup ? grupo?.jogos : false;
const isModo18 = isGroup ? grupo?.porno : false;
const isAutodown = isGroup ? grupo?.autodown : false || true;
const isBanchat = isGroup ? grupo?.bangp : false;
const isPalavrao = isGroup ? (grupo?.antipalavrao?.palavras?.length > 0) : false;
const isAntiFlood = isGroup ? grupo?.anti_flood : false;
const isAntiPv = nescessario?.antipv || false;
const isAnticall = nescessario?.anticall || false;
const isAntifake = isGroup ? grupo?.antifake : false;
const IS_DELETE = nescessario?.Odelete || true;
const So_Adm = isGroup ? grupo?.soadm : false;
const isMultiP = isGroup ? grupo?.multiprefix : false;
const isVisualizar = nescessario?.visualizarmsg;
const isVerificado = nescessario?.verificado;
const isBotoff = nescessario?.botoff || false;
const ischyt = sender.includes(chyt);
const isnit = sender.includes(nit);
const issupre = sender.includes(supre);

const selo = info.message?.extendedTextMessage?.contextInfo;
const quoted = selo?.quotedMessage;
const isBot = sender.includes(kira.user?.id);
const dono = sender.includes(numerodn);
const ctx_selo = quoted ? { key: { remoteJid: from, fromMe: false, id: "selin", participant: selo.participant }, message: quoted } : undefined;

const { isImage, isVideo, isAudio, isSticker, isContact, isLocation, isProduct, isMedia, typeMessage } = buildMediaFlags(type);
const quotedFlags = buildQuotedFlags(type, content);

const mentionedJidArray = selo?.mentionedJid || [];
const rawMenc = mentionedJidArray[0] || (selo?.participant || "");
const menc_os2 = isGroup ? normalizeJid(from, rawMenc) : rawMenc;
const menc_jid2 = isGroup ? normalizeJid(from, menc_os2) : menc_os2;

function reply(texto) { return kira.sendMessage(from, { text: texto }, { quoted: ctx_selo }); }
function reagir(jid, emoji) { return kira.sendMessage(jid, { react: { text: emoji, key: info.key } }); }
function mention(texto, jids = [menc_os2 || sender]) {
return kira.sendMessage(from, { text: texto, mentions: jids }, { quoted: ctx_selo });
}
function getFileBuffer(msg, type) {
return kira.downloadMediaMessage({ message: { [`${type}Message`]: msg } }, type);
};
async function mencionarIMG(texto, image) {
await kira.sendMessage(from, {
image: typeof image === "string" ? { url: image } : image,
caption: texto,
mentions: somembros,
}, { quoted: ctx_selo });
}
async function replyWithReaction(texto, options) {
if (options && options.react) {
await kira.sendMessage(from, { react: { text: options.react.text, key: options.react.key } }).catch(() => {});
}
return kira.sendMessage(from, { text: texto }, { quoted: ctx_selo });
}
async function mentions(texto, jids = [], quote = true) {
const opts = { text: texto, mentions: jids };
if (quote && ctx_selo) return kira.sendMessage(from, opts, { quoted: ctx_selo });
return kira.sendMessage(from, opts);
}
const nowHour = new Date().getHours();
const tempo = nowHour >= 5 && nowHour < 12 ? "Bom dia ☀️" : nowHour >= 12 && nowHour < 18 ? "Boa tarde 🌤️" : nowHour >= 18 && nowHour < 24 ? "Boa noite 🌙" : "Boa madrugada ✨";
const isPalavras = isGroup ? (grupo?.antipalavrao?.palavras || []) : [];

const ctx = {
...require("./utils/helpers"),
kira, info, type, content, from, sender, pushname, isGroup, grupo: [grupo], dataGp: [grupo],
groupMetadata, groupName, groupMembers, groupAdmins, somembros, botNumber,
isBotGroupAdmins, isGroupAdmins, SoDono, So_Adm, isCargo,
numerodn, nescessario, setNes: async (index) => {
await Nescessario.updateOne({ _id: nescessario._id }, { $set: index });
}, setGp: async (gpArray) => {
const gp = gpArray[0];
if (gp && gp._id) await Grupo.updateOne({ _id: gp._id }, { $set: gp });
},
body, budy, budy2, budy3, args, q, query, PR_String, Procurar_String, isCmd, command, prefix, baileysVersion, selo: ctx_selo, quoted,
totalcmds: require("./commands/registry").getAll().length,
isBot, dono, blackist: blacklist, IS_DELETE, isVisualizar, isVerificado, emojimenu, muted, grupoMute, rgtake, fecharAbrir, logos: config.logos,
saveJSON, getFecharAbrir, saveFecharAbrir, timeDate, countDays, getInfo,
renameContextSticker, gerarlinkUploadMedia, pathAntiLink, pinterestSearch,
pinterestVideoV2, obeso, gerarCommandsJSON,
getFileBuffer, mencionarIMG, replyWithReaction, tempo,
mentions, isMultiP, isPalavras,
ischyt, isnit, issupre, isBotoff, nmrdn: numerodn,
fs, path, moment, axios, process, console, Buffer,
setTimeout: globalThis.setTimeout, fetch: globalThis.fetch,
isAntiImg, isAntiVid, isAntiAudio, isAntiSticker, Antidoc, isAntiCtt, Antiloc,
isAntiDDD, isAntilinkgp, isAntiLinkHard, isAntiLinkEasy, isAntiNotas, isAntiStatus,
isPayment, isAnticatalogo, isWelkom, isSimi, isAutofigu, IsAutofigu, autofigu,
isAutorepo, isModobn, isModo18, isAutodown, isBanchat, isPalavrao, isAntiFlood,
isAntiPv, isAnticall, isAntifake, isAntiSpam, tempoAntiSpam, isImage, isVideo, isAudio, isSticker, isContact,
isLocation, isProduct, isMedia, typeMessage, ...quotedFlags, arrayDDDs,
reply, reagir, mention, mess, IMG_LINKS: config.getAll(), RANK_LINKS: config.getAll(), CMD_LINKS: config.getAll(),
API_kira: apiUrl, KEY_kira: apiKey, NomeDoBot: botName, ownerName, ownerNumber,
setting: config, linguagem,
fundolevel, fundo2, fundo1, linklogos, imgnazista, imggay, imgcorno, imggostosa, imggostoso, imgfeio, imggado, imgvesgo, imgbebado, tapacmd, matarcmd, beijocmd, chutecmd, deathcmd, rnkgay, rnkgado, rnkcorno, rnkgostoso, rnkgostosa,
rnknazista, rnkotaku, rnkpau, suruba, minado_bomb, thumbnail, imgsigma, imgbeta, imgbaiano, imgbaiana, imgcarioca, imglouco, imglouca, imgsafada, imgsafado, imgmacaco, imgmacaca, imgputa, rnksigma, rnkbeta, rnkbaiano, rnkbaiana,
rnkcarioca, rnklouco, rnklouca, rnksafada, rnksafado, rnkmacaco, rnkmacaca, rnkputa, rnkfiel, rnkinfiel,
httpAgent, httpsAgent, apiCache, CACHE_TTL, cacheGet, cacheSet, cacheKey,
cacheStats, cacheFlush, cachedFetchJson, cachedFetchText, cachedGetBuffer,
menc_os2, menc_jid2, mention, mentionedJid: mentionedJidArray,
upload: require("../arquivos/funcoes/functions.js").upload,
fetchJson: require("../arquivos/funcoes/functions.js").fetchJson,
sendImageAsSticker2: require("../arquivos/stickers/rename2.js").sendImageAsSticker2,
sendVideoAsSticker2: require("../arquivos/stickers/rename2.js").sendVideoAsSticker2,
sendImageAsSticker: require("../arquivos/stickers/rename.js").sendImageAsSticker,
sendVideoAsSticker: require("../arquivos/stickers/rename.js").sendVideoAsSticker,
downloadMediaMessage: (msg, type) => kira.downloadMediaMessage(msg, type),
};

if (!info.key.fromMe && type !== "reactionMessage" && type !== "senderKeyDistributionMessage" && type !== "protocolMessage") {
kiraLogger.messageLog({ type: typeMessage, pushname, sender, from, command: isCmd ? command : null, isCmd, isGroup, groupName });
}

await handleAntiStatus(ctx);
if (isPayment) await handleAntiPayment(ctx);
await handleAntiNotas(ctx);
if (await handleAntiFlood(ctx)) return;
if (await handleAntiSpam(ctx)) return;

if (isBanchat && !SoDono) {
await kira.sendMessage(from, { text: "Pronto ,chefe , bani o grupo, mais alguma coisa 🫦??" }, { quoted: ctx_selo });
return;
}

if (isAntiImg && isImage) await handleAntiMedia(ctx);
else if (isAntiSticker && isSticker) await handleAntiMedia(ctx);
else if (Antidoc && type === "documentMessage") await handleAntiMedia(ctx);
else if (isAntiVid && isVideo) await handleAntiMedia(ctx);
else if (isAntiAudio && isAudio) await handleAntiMedia(ctx);
else if ((isAntiCtt || Antiloc || isAnticatalogo) && (isContact || isLocation || isProduct)) await handleAntiMedia(ctx);

if (isAntiLinkHard && isUrl(PR_String)) await handleAntiLinkHard(ctx);
else if (isAntiLinkEasy && isUrl(PR_String)) await handleAntiLinkEasy(ctx);

if (isAutodown) { if (await handleAutoDown(ctx)) return; }

if (isAntiPv && !isGroup && !SoDono) { await handleAntiPrivate(ctx); return; }
if (await handleMute(ctx)) return;
await handleAntiPalavrao(ctx);

if (So_Adm && !isGroupAdmins && isCmd) {
reply(mess.onlyAdmins());
return;
}

if (isCmd) {
if (await handleCommand(ctx)) return;
suggestCommand(command, prefix, require("./commands/registry").commands, similarityCmd, reagir, from, kira, ctx_selo);
return;
}

if (isAutofigu) { setTimeout(() => handleAutoSticker(ctx).catch(() => {}), 1000); }
if (IsAutofigu) { setTimeout(() => handleAutoStickerFfmpeg(ctx).catch(() => {}), 1000); }

await handleEval(ctx);
await handleSimi(ctx);
await handlePrefixoEcho(ctx);

} catch (e) {
console.error("[PROCESS ERROR]", e);
}
}
}

async function starthana() {
const kiraConectado = await startConnection({
onGroupParticipants: async (kira, event) => {
try {
const rawBotNumber_ = kira.user?.id?.split(":")[0] || "";
const botNumber_ = rawBotNumber_.includes("@") ? rawBotNumber_ : rawBotNumber_ + "@s.whatsapp.net";
await handleAntiGroupEdit(kira, event, { Grupo, botNumber: botNumber_ });
await handleWelcome({ kira, event,
Grupo, mess, NomeDoBot: botName, fundo1: config.getLinks("fundo1"), API_kira: apiUrl, KEY_kira: apiKey,
time: require("../arquivos/funcoes/functions.js").time, setting: config, getGroupAdmins,
extractDDD, extractStateFromDDD, extractStateFromNumber, getName });
} catch (e) { console.log(e); }
},
onMessage: async (kira, upsert) => {
await processMessages(upsert, kira);
}
});
iniciarAgendadorGrupos(kiraConectado);
}

starthana();

fs.watchFile(require.resolve(__filename), () => {
console.log(require("chalk").yellow("[ SISTEMA ] Arquivo alterado, reiniciando Kira.."));
setTimeout(() => { process.exit(); }, 500);
});