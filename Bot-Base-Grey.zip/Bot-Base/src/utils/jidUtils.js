const { normalizeRecipientJid } = require("zapo-js");

const lidToPn = new Map();

function learnLidMapping(lid, pn) {
  if (lid && typeof lid === "string" && lid.endsWith("@lid") && pn && typeof pn === "string") {
    lidToPn.set(lid, pn);
  }
}

function resolveLid(jid) {
  if (!jid || !jid.endsWith("@lid")) return jid;
  return lidToPn.get(jid) || jid;
}

function normalizeJid(jid) {
  if (!jid) return "";
  return normalizeRecipientJid(resolveLid(jid));
}

module.exports = { learnLidMapping, resolveLid, normalizeJid };
