const { Grupo, Nescessario, Muted, Banned, Take } = require("../database");
const path = require("path");
const config = require("../config");
const { kiraLogger } = require("./logger");
const { normalizeJid } = require("./jidUtils");
const {
  extractBody,
  extractQuotedBody,
  buildMediaFlags,
  buildQuotedFlags,
} = require("../handlers/messageUtils");

const moment = require("moment-timezone");
const fs = require("fs-extra");
const axios = require("axios");
const {
  getBuffer,
  getExtension,
  getRandom,
  convertSticker,
  Gemini,
  fetchJson,
  upload,
} = require("../../arquivos/funcoes/functions.js");
const yts = (q) => require("yt-search").search(q);

const ANTISPAM_PATH = path.join(__dirname, "..", "..", "settings", "imports", "antispam.json");

let antiSpamCache = null;
function getAntiSpamCache() {
  if (antiSpamCache) return antiSpamCache;
  try {
    antiSpamCache = fs.existsSync(ANTISPAM_PATH) ? JSON.parse(fs.readFileSync(ANTISPAM_PATH, "utf8")) : {};
  } catch {
    antiSpamCache = {};
  }
  if (!antiSpamCache || typeof antiSpamCache !== "object" || Array.isArray(antiSpamCache)) antiSpamCache = {};
  return antiSpamCache;
}

let antiSpamTimer = null;
function salvarAntiSpam() {
  if (antiSpamTimer) return;
  antiSpamTimer = setTimeout(() => {
    antiSpamTimer = null;
    try {
      fs.writeFileSync(ANTISPAM_PATH, JSON.stringify(antiSpamCache || {}, null, 2));
    } catch {}
  }, 500);
  if (antiSpamTimer.unref) antiSpamTimer.unref();
}

function verificarSpam(grupo, usuario, tempo, limite = 5) {
  const db = getAntiSpamCache();

  if (!db[grupo]) db[grupo] = {};
  if (!db[grupo][usuario]) {
    db[grupo][usuario] = {
      mensagens: 0,
      ultimoTempo: Date.now(),
    };
  }

  const agora = Date.now();
  const user = db[grupo][usuario];

  if (agora - user.ultimoTempo > tempo * 1000) {
    user.mensagens = 0;
  }
  user.mensagens += 1;
  user.ultimoTempo = agora;

  salvarAntiSpam();

  return {
    spam: user.mensagens >= limite,
    quantidade: user.mensagens,
  };
}

function resetarSpam(grupo, usuario) {
  const db = getAntiSpamCache();

  if (db[grupo] && db[grupo][usuario]) {
    delete db[grupo][usuario];
    salvarAntiSpam();
  }
}

function date() {
  return moment().tz("America/Sao_Paulo").format("DD/MM/YYYY");
}

function hora() {
  return moment().tz("America/Sao_Paulo").format("HH:mm:ss");
}

function time() {
  return moment().tz("America/Sao_Paulo").format("HH:mm:ss");
}

function TimeCount(seconds) {
  seconds = Math.floor(seconds);
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  if (m > 0) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(" ");
}

function getGroupAdmins(participants) {
  return participants.filter(p => p.admin === "admin" || p.admin === "superadmin")
    .map(p => {
      const base = p.phoneNumber || p.id;
      if (!base) return null;
      return base;
    }).filter(Boolean);
}

function extractDDD(phoneNumber) {
  const numericOnly = phoneNumber.replace(/\D/g, '');
  if (numericOnly.startsWith('55') && (numericOnly.length === 12 || numericOnly.length === 13)) {
    return numericOnly.substring(2, 4);
  }
  return null;
}

function extractStateFromDDD(ddd) {
  const dddList = {"11": "São Paulo (SP)", "12": "São Paulo (SP)", "13": "São Paulo (SP)", "14": "São Paulo (SP)", "15": "São Paulo (SP)", "16": "São Paulo (SP)", "17": "São Paulo (SP)", "18": "São Paulo (SP)", "19": "São Paulo (SP)", "21": "Rio de Janeiro (RJ)", "22": "Rio de Janeiro (RJ)", "24": "Rio de Janeiro (RJ)", "27": "Espírito Santo (ES)", "28": "Espírito Santo (ES)", "31": "Minas Gerais (MG)", "32": "Minas Gerais (MG)", "33": "Minas Gerais (MG)", "34": "Minas Gerais (MG)", "35": "Minas Gerais (MG)", "37": "Minas Gerais (MG)", "38": "Minas Gerais (MG)", "41": "Paraná (PR)", "42": "Paraná (PR)", "43": "Paraná (PR)", "44": "Paraná (PR)", "45": "Paraná (PR)", "46": "Paraná (PR)", "47": "Santa Catarina (SC)", "48": "Santa Catarina (SC)", "49": "Santa Catarina (SC)", "51": "Rio Grande do Sul (RS)", "53": "Rio Grande do Sul (RS)", "54": "Rio Grande do Sul (RS)", "55": "Rio Grande do Sul (RS)", "61": "Distrito Federal (DF)", "62": "Goiás (GO)", "63": "Tocantins (TO)", "64": "Goiás (GO)", "65": "Mato Grosso (MT)", "66": "Mato Grosso (MT)", "67": "Mato Grosso do Sul (MS)", "68": "Acre (AC)", "69": "Rondônia (RO)", "71": "Bahia (BA)", "73": "Bahia (BA)", "74": "Bahia (BA)", "75": "Bahia (BA)", "77": "Bahia (BA)", "79": "Sergipe (SE)", "81": "Pernambuco (PE)", "82": "Alagoas (AL)", "83": "Paraíba (PB)", "84": "Rio Grande do Norte (RN)", "85": "Ceará (CE)", "86": "Piauí (PI)", "87": "Pernambuco (PE)", "88": "Ceará (CE)", "89": "Piauí (PI)", "91": "Pará (PA)", "93": "Pará (PA)", "94": "Pará (PA)", "95": "Roraima (RR)", "96": "Amapá (AP)", "97": "Amazonas (AM)", "98": "Maranhão (MA)", "99": "Maranhão (MA)"};
  return dddList[ddd] || "";
}

function extractStateFromNumber(phoneNumber) {
  const numericOnly = phoneNumber.replace(/\D/g, '');
  if (numericOnly.startsWith('55') && (numericOnly.length === 12 || numericOnly.length === 13)) {
    const ddd = numericOnly.substring(2, 4);
    return extractStateFromDDD(ddd) || "Hmph! Número de fora do Brasil... não consigo identificar o estado, tá?!";
  }
  return "Hmph! Número de fora do Brasil... não consigo identificar o estado, tá?!";
}

const PUSHNAMES_PATH = path.join(__dirname, "..", "..", "arquivos", "database", "pushnames.json");
let pushnamesCache = null;
function loadPushnames() {
  if (pushnamesCache) return pushnamesCache;
  try {
    if (fs.existsSync(PUSHNAMES_PATH)) {
      const raw = JSON.parse(fs.readFileSync(PUSHNAMES_PATH, "utf8"));
      pushnamesCache = Array.isArray(raw) ? raw : [];
    } else {
      pushnamesCache = [];
    }
  } catch {
    pushnamesCache = [];
  }
  return pushnamesCache;
}

function getName(number) {
  const ps = number.includes(`@s.whatsapp.net`) ? number : number.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`;
  const pushnames = loadPushnames();
  const nick = pushnames.find((i) => i && i.id === ps)?.nick;
  return nick || "usuário(a)";
}

const sleep = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function readJSON(filePath, def) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(def, null, 2));
    return def;
  }
  return JSON.parse(fs.readFileSync(filePath));
}

function extractDomain(text) {
  try {
    const url = text.match(/https?:\/\/[^\s]+/gi);
    if (!url) return null;
    return url[0].replace(/^https?:\/\//, "").split("/")[0];
  } catch { return null; }
}

const BLACKLIST_PATH = path.join(__dirname, "..", "..", "arquivos", "database", "blacklist_global.json");
let blacklistCache = null;
function loadBlacklist() {
  if (blacklistCache) return blacklistCache;
  try {
    blacklistCache = fs.existsSync(BLACKLIST_PATH)
      ? JSON.parse(fs.readFileSync(BLACKLIST_PATH, "utf8"))
      : { numeros: {} };
  } catch {
    blacklistCache = { numeros: {} };
  }
  if (!blacklistCache || typeof blacklistCache.numeros !== "object") blacklistCache = { numeros: {} };
  return blacklistCache;
}

function registrarNumeroSuspeito(jid, dominio) {
  const blacklist = loadBlacklist();
  if (blacklist.numeros[jid]) return;
  blacklist.numeros[jid] = {
    motivo: "Divulgação de site de apostas.",
    primeiroRegistro: moment().format("YYYY-MM-DD HH:mm:ss"),
    linkDetectado: dominio
  };
  try {
    fs.writeFileSync(BLACKLIST_PATH, JSON.stringify(blacklist, null, 2));
  } catch {}
}

function isUrl(text) {
  return /https?:\/\/[^\s]+/gi.test(text);
}

function similarityCmd(txt) {
  const allCases = require('./commandList')();
  const getSimilarity = require('../../arquivos/funcoes/similaridade.js');
  const getsmlrt = getSimilarity(allCases, txt);
  if (!getsmlrt.porcentagem) {
    return [{ comando: "não encontrado", porcentagem: 0 }];
  }
  return [{ comando: config.prefix + getsmlrt.nome, porcentagem: Number(getsmlrt.porcentagem).toFixed(1) }];
}

const mess = require("./messages.js");

function DLT_FL(file) {
  try { fs.unlinkSync(file); } catch (error) {}
}

const processados = new Set();

function jaProcessou(msgId) {
  return processados.has(msgId);
}

function marcarComoProcessado(msgId) {
  processados.add(msgId);
}

module.exports = {
  normalizeJid,
  Grupo,
  Nescessario,
  Muted,
  Banned,
  Take,
  config,
  kiraLogger,
  extractBody,
  extractQuotedBody,
  buildMediaFlags,
  buildQuotedFlags,
  getGroupAdmins,
  extractDDD,
  extractStateFromDDD,
  extractStateFromNumber,
  getName,
  sleep,
  readJSON,
  extractDomain,
  registrarNumeroSuspeito,
  isUrl,
  similarityCmd,
  mess,
  jaProcessou,
  marcarComoProcessado,
  DLT_FL,
  verificarSpam,
  resetarSpam,
  date,
  hora,
  time,
  TimeCount,
  fs,
  path,
  moment,
  axios,
  getBuffer,
  getExtension,
  getRandom,
  convertSticker,
  Gemini,
  fetchJson,
  upload,
  yts,
};
