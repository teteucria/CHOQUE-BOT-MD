const mess = require("../../settings/imports/global.js");

module.exports = {
  ...mess,
  mess,
};