const fs = require("fs-extra");
const path = require("path");
const moment = require("moment-timezone");
const config = require("../config");
const { writeExifImg2 } = require("../../arquivos/stickers/exif2.js");

const AGENDAR_PATH = path.join(__dirname, "..", "database", "db", "agendargp.json");
const pathAntiLink = path.join(__dirname, "..", "..", "arquivos", "database", "antilink_proibido.json");

function saveJSON(filePath, data) {
fs.writeJsonSync(filePath, data, { spaces: 2 });
}

function getFecharAbrir() {
try {
return fs.existsSync(AGENDAR_PATH) ? fs.readJsonSync(AGENDAR_PATH) : [];
} catch {
return [];
}
}

function saveFecharAbrir(data) {
fs.ensureDirSync(path.dirname(AGENDAR_PATH));
fs.writeJsonSync(AGENDAR_PATH, Array.isArray(data) ? data : [], { spaces: 2 });
}

function timeDate(format) {
return moment().tz("America/Sao_Paulo").format(format);
}

function countDays(fromParts, toParts) {
const [fd, fm, fy] = fromParts.map(Number);
const [td, tm, ty] = toParts.map(Number);
return Math.abs(moment([ty, tm - 1, td]).diff(moment([fy, fm - 1, fd]), "days"));
}

const getInfo = {
configbot: (prefix) =>
`╭════════════════╮\n║ ⛧ *CONFIGURAÇÕES DO BOT* (Hmph! Olha e guarda, viu?)\n║ 🔖 Prefixo atual: ${prefix}\n║ ⚙️ Use os comandos de administração pra alterar... n-não é que eu me importe, é pra você parar de perguntar!\n╰════════════════╯`,
infoRent: (prefix) =>
`╭════════════════╮\n║ ⛧ *INFORMAÇÕES DE ALUGUEL* (Hmph! Eu não sou de alugar pra qualquer um, tá?!)\n║ 💠 Pra alugar o bot no seu grupo, chama o dono... mas se comporte, viu?\n║ 🔖 Comandos: ${prefix}alugar\n╰════════════════╯`,
bemvindo: (prefix) =>
`╭════════════════╮\n║ ⛧ *COMANDO DE BEM-VINDO* (Hmph! B-bom, se você vai usar, usa direito!)\n║ 📝 Use *${prefix}bemvindo texto*\n║ 📝 Use *${prefix}legendabv* pra mudar a legenda\n╰════════════════╯`,
infoOwner: (prefix, ownerName, ownerNumber, NomeDoBot, sender) =>
`╭════════════════╮\n║ ⛧ 🤖 *${NomeDoBot}* (Hmph! F-fica sabendo com quem você fala!)\n║ 👑 *Dono:* ${ownerName}\n║ 📱 *Número:* ${ownerNumber}\n║ 📌 *Prefixo:* ${prefix}\n╰════════════════╯`,
};

async function renameContextSticker(pack, author, info, kira, from, selo) {
  const stickerMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage;
  if (!stickerMsg) throw new Error("Marque uma figurinha.");
  const mediaObj = { message: { stickerMessage: stickerMsg } };
  const buff = await kira.downloadMediaMessage(mediaObj, "buffer");

  const out = await writeExifDireto(buff, { packname: pack, author });
  await kira.sendMessage(from, { sticker: out }, { quoted: selo });
  return out;
};

async function gerarlinkUploadMedia(mediaBuffer) {
const FormData = require("form-data");
const form = new FormData();
form.append("image", mediaBuffer, { filename: "media" });
const res = await fetch("https://api.imgur.com/3/image", {
method: "POST",
headers: { ...form.getHeaders(), Authorization: "Client-ID 400116076ba4b73" },
body: form,
});
const data = await res.json();
if (data && data.data && data.data.link) return data.data.link;
throw new Error("Falha ao recuperar o URL do Imgur.");
}

async function pinterestSearch(q) {
const url = `${config.apiUrl}/pinterest?text=${encodeURIComponent(q)}&apitoken=${config.apiKey}`;
const res = await fetch(url);
const data = await res.json();
let urls = [];
if (data && Array.isArray(data.urls)) urls = data.urls;
else if (data && Array.isArray(data.resultado)) urls = data.resultado.map((r) => (typeof r === "string" ? r : r?.image || r?.url)).filter(Boolean);
return { urls };
}

async function pinterestVideoV2(urlInput) {
const url = `${config.apiUrl}/pinmp4?url=${encodeURIComponent(urlInput)}&apitoken=${config.apiKey}`;
const res = await fetch(url);
const data = await res.json();
return { resultado: (data && Array.isArray(data.resultado) ? data.resultado : []) || [] };
}

function obeso(peso, altura) {
const a = Number(altura);
if (!peso || !a || a <= 0) return 0;
return Number((Number(peso) / Math.pow(a, 2)).toFixed(2));
}

function gerarCommandsJSON() {
try {
return require("../commands/registry").getAll().length;
} catch {
return 0;
}
}

module.exports = {
saveJSON,
getFecharAbrir,
saveFecharAbrir,
timeDate,
countDays,
getInfo,
pathAntiLink,
renameContextSticker,
gerarlinkUploadMedia,
pinterestSearch,
pinterestVideoV2,
obeso,
gerarCommandsJSON,
};