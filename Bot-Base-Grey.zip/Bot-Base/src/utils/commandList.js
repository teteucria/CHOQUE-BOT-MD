function loadCommands() {
  try {
    const registry = require("../commands/registry");
    const all = registry.getAll();
    const list = [];
    for (const cmd of all) {
      if (cmd.name) list.push(cmd.name);
      if (Array.isArray(cmd.aliases)) list.push(...cmd.aliases);
    }
    return list;
  } catch {
    return [];
  }
}

module.exports = loadCommands;