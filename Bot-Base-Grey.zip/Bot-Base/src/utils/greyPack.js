const fs = require("fs-extra");
const path = require("path");

const dataDir = path.join(__dirname, "../../db/data/grey");
const usersFile = path.join(dataDir, "users.json");
const gamesFile = path.join(dataDir, "games.json");

function ensure() {
  fs.ensureDirSync(dataDir);
  if (!fs.existsSync(usersFile)) fs.writeJsonSync(usersFile, {}, {spaces: 2});
  if (!fs.existsSync(gamesFile)) fs.writeJsonSync(gamesFile, {}, {spaces: 2});
}
function read(file) { ensure(); return fs.readJsonSync(file); }
function write(file, data) { ensure(); fs.writeJsonSync(file, data, {spaces: 2}); }
function user(id, name="Usuário") {
  const db=read(usersFile);
  if (!db[id]) db[id]={id,nome:name,money:100,level:1,xp:0,streak:0,lastDaily:0};
  if (name && name !== "Usuário") db[id].nome=name;
  write(usersFile,db); return db[id];
}
function saveUser(u) { const db=read(usersFile); db[u.id]=u; write(usersFile,db); return u; }
function allUsers(){ return Object.values(read(usersFile)); }
function game(key, value) {
  const db=read(gamesFile);
  if (value === undefined) return db[key];
  if (value === null) delete db[key]; else db[key]=value;
  write(gamesFile,db); return value;
}
function xp(u, amount=10) {
  u.xp += amount;
  const need = u.level * 100;
  while (u.xp >= need) { u.xp -= u.level*100; u.level++; }
  saveUser(u); return u;
}
module.exports={dataDir, user, saveUser, allUsers, game, xp};
