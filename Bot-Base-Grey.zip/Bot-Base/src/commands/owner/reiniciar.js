module.exports = {
nome: ["reiniciar"],
executar: async ({
SoDono,
mess,
process,
reply
}) => {

if (!SoDono) return reply(mess.onlyOwner());
reply("Hmph! Reiniciando o sistema... Em segundos estarei de volta, senhor(a)! Não fica aí me esperando com cara de tédio, viu?! 🙇🏻‍♂️❤️‍🩹");
setTimeout(async () => {
process.exit();
}, 1200);
}
};