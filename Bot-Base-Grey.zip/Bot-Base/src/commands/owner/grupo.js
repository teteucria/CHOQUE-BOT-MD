module.exports = {
nome: ["grupo"],
executar: async ({
args,
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mention,
mess,
prefix,
reply,
sender,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1)
return reply(`🤔 Hmph! Hmm... você está usando de forma errada, senhor(a)!\n- Saiba o uso detalhado, através do argumento: _${prefix}grupo *--help*_`);
groupI = await kira.groupMetadata(from);
if (args[0] === "--help")
return await mention(mess.helpGroupSettings(prefix, sender));
if (args[0] === "-open" || args[0] === "a") {
if (groupI.announce == false)
return reply("Hmph! O grupo já está aberto, bobinho(a)... Não dá para abrir o que já está aberto, presta atenção!");
reply(`Como você pediu, o grupo foi aberto com sucesso... Não me agradeça, não é porque eu me importo com a sua opinião ou algo assim, tá?!`);
await kira.groupSettingUpdate(from, "not_announcement");
} else if (args[0] === "-close" || args[0] === "f") {
if (groupI.announce == true)
return reply("Hmph! O grupo já está fechado, baka... Não dá para fechar o que já está fechado, entendido?!");
reply("Como você pediu, o grupo foi fechado com sucesso... Foi o que você quis, viu?! Eu só obedeci mesmo!");
await kira.groupSettingUpdate(from, "announcement");
} else if (args[0] === "-livre") {
if (groupI.restrict == false)
return reply("Hmph! O grupo não tem nenhuma restrição de alteração nos dados... Ou seja, todos já podem alterar. Não adianta pedir de novo, baka!");
reply("Como você pediu, todos os membros agora podem editar as configurações do grupo... Fiz porque quis, não me olha assim!");
await kira.groupSettingUpdate(from, "unlocked");
} else if (args[0] === "-private") {
if (groupI.restrict == true)
return reply("Hmph! O grupo já tem a restrição para administradores... Não tem como ativar duas vezes, bobinho(a)!");
reply("Como você pediu, somente os administradores podem editar as configurações do grupo... Foi rápido, né?! Eu sou boa nisso, mas não se acostume!");
await kira.groupSettingUpdate(from, "locked");
} else {
reply(`🤔 Hmph! Hmm... você está usando de forma errada, senhor(a)!\n- Saiba o uso detalhado, através do argumento: _${prefix}grupo *--help*_`);
}
}
};