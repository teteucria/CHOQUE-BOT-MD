module.exports = {
nome: ["setfotogp","fotogp"],
executar: async ({
command,
from,
fs,
getExtension,
getFileBuffer,
getRandom,
info,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
isQuotedImage,
mess,
prefix,
reply,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!isQuotedImage)
return reply(`Hmph! Use assim: ${prefix + command} <Marque uma foto>... Não é tão difícil, bobinho(a)!`);
ftgp = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage;
rane = getRandom("." + (await getExtension(ftgp.mimetype)));
buffimg = await getFileBuffer(ftgp, "image");
fs.writeFileSync(rane, buffimg);
medipp = rane;
kira.updateProfilePicture(from, { url: medipp });
reply(`Hmph! Foto do grupo alterada com sucesso... Ficou bonita, eu que fiz! Mas não se acostume, tá?!`);
}
};