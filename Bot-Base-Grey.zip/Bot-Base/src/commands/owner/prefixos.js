module.exports = {
nome: ["prefixos"],
executar: async ({
dataGp,
isGroup,
isMultiP,
mess,
  prefix,
reply
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isMultiP) return reply(`Hmph! Para usar este comando, você deve ativar o comando *multiprefix*\nExemplo: ${prefix}multiprefixo... Não fica testando minha paciência, baka!`);
if (dataGp[0].prefixos.length < 1) return reply("Hmph! Não contém nenhum prefixo extra adicionado neste grupo... Tanto faz, nada para mostrar mesmo!");
reply(`Hmph! Lista de prefixos para uso do bot, no Grupo: *${groupName}*:\n• *[Total: ${dataGp[0].prefixos.length}]* - ${dataGp[0].prefixos.map((v, index) => `( ${v} )`).join(", ")}\nFiz a listinha só para você, hein?! Não se acostume!`);
}
};