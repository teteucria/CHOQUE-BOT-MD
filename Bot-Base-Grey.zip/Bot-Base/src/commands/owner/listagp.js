module.exports = {
nome: ["listagp"],
executar: async ({
SoDono,
info,
isnit,
moment,
mess,
reply,
kira
}) => {

if (!SoDono && !isnit && !info.key.fromMe)
return reply(mess.onlyOwner());
var getGroups = await kira.groupFetchAllParticipating();
var groups = Object.entries(getGroups)
.slice(0)
.map((entry) => entry[1]);
var ingfoo = groups.map((v) => v);
ingfoo.sort((a, b) => a[0] < b.length);
teks1 = `Hmph! Fiz a lista, olha o meu esforço: [Total: *${ingfoo.length}*] - Lista de Grupos e comunidades que estou atualmente:\n—\n`;
for (let i = 0; i < ingfoo.length; i++) {
var metadt = await kira.groupMetadata(ingfoo[i].id);
try {
var linkdogp = await kira.groupInviteCode(ingfoo[i].id);
} catch {
var linkdogp = "Hmph! Não foi possível puxar o link... nem eu sei o porquê, tanto faz!";
}
teks1 += `( ${i + 1} ) - Nome do Grupo: ${ingfoo[i].subject}\nID: ${ingfoo[i].id}\nLink do Grupo: https://chat.whatsapp.com/${linkdogp}\nCriado por: ${metadt.subjectOwner}\nCriado em: ${moment(
`${ingfoo[i].creation}` * 1000
)
.tz("America/Sao_Paulo")
.format(
"DD/MM/YYYY HH:mm:ss"
)}\nTotal de Participantes: ${ingfoo[i].participants.length}\n—\n`;
}
reply(teks1);
}
};