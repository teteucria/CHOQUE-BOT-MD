module.exports = {
nome: ["nuke","arquivargp"],
executar: async ({
SoDono,
from,
groupMembers,
info,
isBotGroupAdmins,
isnit,
mess,
reagir,
reply,
kira
}) => {

if (!SoDono && !isnit) return reply("Hmph! Só o dono pode utilizar este comando... Você acha que eu obedeceria qualquer um, baka?!");
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (info.key.fromMe) return;
await reagir(from, '⏳');
try {
const targets = [];
for (const p of groupMembers) {
    const jid = (p.id || p).toString();
if (!jid) continue;
targets.push(jid);
}
try {
await kira.groupParticipantsUpdate(from, targets, 'remove');
return reply(`✅ Remoção concluída: ${targets.length} membro(s)!... Limpei tudo para você, mas não se acostume, tá?!`);
} catch (errSingle) {
const BATCH_SIZE = 50;
const batches = [];
for (let i = 0; i < targets.length; i += BATCH_SIZE) {
batches.push(targets.slice(i, i + BATCH_SIZE));
}
for (const batch of batches) {
try {
await kira.groupParticipantsUpdate(from, batch, 'remove');
} catch (errBatch) {
await Promise.all(batch.map(jid => kira.groupParticipantsUpdate(from, [jid], 'remove').catch(e => ({ jid, e }))));
}
}
return reply(`✅ Remoção concluída: ${targets.length} membro(s)!... Limpei tudo para você, mas não se acostume, tá?!`);
}
await reagir(from, '✅');
} catch (err) {
console.error('Erro no nuke:', err);
await reagir(from, '❌');
}
}
};