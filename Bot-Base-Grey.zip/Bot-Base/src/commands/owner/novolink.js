module.exports = {
nome: ["novolink","nlink","redefinir"],
executar: async ({
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
reagir,
reply,
selo,
sleep,
kira
}) => {

setTimeout(() => {
reagir(from, "⚙️");
}, 300);
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isGroup) return reply(mess.onlyGroup());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
try {
await kira.groupRevokeInvite(from);
await sleep(1000);
link = await kira.groupInviteCode(from);
kira.sendMessage(from, {text: `Hmph! Toma o novo link do grupo:\nhttps://chat.whatsapp.com/${link}\nFiz isso só porque quis, não se acostume, viu?!`}, {quoted: selo});
} catch (e) {
console.log(e);
reply("Hmph! Erro ao tentar redefinir o link... Não foi por falta de esforço, baka! Tenta de novo.");
}
}
};