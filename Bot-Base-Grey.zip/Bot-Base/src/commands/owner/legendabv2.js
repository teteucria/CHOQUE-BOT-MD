module.exports = {
nome: ["legendabv2"],
executar: async ({
args,
body,
dataGp,
isGroup,
isGroupAdmins,
isWelkom,
mess,
reply,
  prefix,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (args.length < 1)
return reply("*Hmph! Escreva a mensagem de boas-vindas*... Você quer que eu adivinhe, baka?!");
teks = body.slice(12);
if (isWelkom) {
dataGp[0].wellcome[0].legendabv = teks;
setGp(dataGp);
reply("*Hmph! Mensagem de boas-vindas 2 definida com sucesso!*... Caprichadinho, eu que fiz! Mas não se acostume, tá?!");
} else {
reply(`Hmph! Ative o ${prefix}bemvindo2 1 primeiro... Não adianta correr, bobinho(a)!`);
}
}
};