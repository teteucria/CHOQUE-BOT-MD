module.exports = {
nome: ["configurar-bot"],
executar: async ({
from,
getInfo,
prefix,
quoted,
selo,
text,
kira
}) => {

await kira.sendMessage(from, {text: getInfo.configbot(prefix)}, {quoted: selo});
}
};