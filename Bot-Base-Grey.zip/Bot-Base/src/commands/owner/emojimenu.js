module.exports = {
nome: ["emojimenu"],
executar: async ({
SoDono,
mess,
nescessario,
q,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
nescessario.emojimenu = q;
setNes(nescessario);
reply(`Hmph! Emoji do menu alterado: "${q}"... Ficou até bonitinho, mas não é como se eu tivesse escolhido por você, tá?!`);
}
};