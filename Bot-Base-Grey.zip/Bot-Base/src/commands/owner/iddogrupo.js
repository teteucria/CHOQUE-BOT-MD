module.exports = {
nome: ["iddogrupo"],
executar: async ({
SoDono,
from,
mess,
reply
}) => {

if (!SoDono) return reply(mess.onlyOwner());
reply(`Hmph! Aqui está o ID desse grupo, bobinho(a): ${from}`);
}
};