module.exports = {
nome: ["recusar"],
executar: async ({
kira,
from,
SoDono,
selo,
mess,
reply,
reagir,
q}) => {

if (!SoDono) return reply(mess.onlyOwner());
reagir(from, "✅");
await kira.sendMessage(`${q}@s.whatsapp.net`, {text: `Hmph! Olá amigo(a)... Sinto muito dizer, mas seu convite foi recusado. Não foi nada pessoal, tá?! Apenas regras são regras, tanto faz!`}, {quoted: selo});
}
};