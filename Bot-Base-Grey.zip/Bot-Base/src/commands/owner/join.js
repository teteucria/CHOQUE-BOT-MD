module.exports = {
nome: ["join", "entrar"],
executar: async ({
kira,
from,
SoDono,
args,
mess,
reply,
reagir
}) => {

if (!SoDono) return reply(mess.onlyOwner);
reagir(from, "✅");
string = args.join(" ");
if (!string)
return reply("Hmph! Insira um link de convite ao lado do comando... Não é assim tão difícil, baka!");
if (
string.includes("chat.whatsapp.com/") ||
reply("Hmph! Ops... verifique o link que você inseriu, tá?! Não é o tipo de coisa que eu deixaria passar batido!")
) {
link = string.split("app.com/")[1];
try {
kira.groupAcceptInvite(`${link}`);
} catch (erro) {
reagir(from, "❌");
if (String(erro).includes("resource-limit")) {
reply("Hmph! O grupo já está com o alcance de 257 membros... Cheio demais, até eu me sinto apertada aqui. Tanto faz!");
}
if (String(erro).includes("not-authorized")) {
reply("Hmph! Não foi possível entrar no grupo.\nMotivo: Banimento... Nem eu tenho culpa disso, viu?! Não fica me olhando, baka!");
}
}
}
}
};