module.exports = {
nome: ["grupoinfo","infogrupo","infogp","gpinfo","regras"],
executar: async ({
from,
infoGroup,
isGroup,
isGroupAdmins,
groupAdmins,
somembros,
mentions,
mess,
moment,
quoted,
reply,
selo,
  prefix,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
try {
var ppUrl = await kira.profilePictureUrl(from, "image");
} catch {
var ppUrl = `https://telegra.ph/file/6ca032835ed7a16748b6f.jpg`;
}
var puxarInfo = await kira.groupMetadata(from);
var ANC_INFO = puxarInfo.announce;
var returnAnnounce = ANC_INFO === false ? "Não." : ANC_INFO === true ? "Sim." : undefined;
var RST_INFO = puxarInfo.restrict;
var returnRestrict = RST_INFO === false ? "Sim." : RST_INFO === true ? "Não." : undefined;
var infoCreator = puxarInfo.subjectOwner || "Não Encontrado";
infoGroup = `Hmph! Toma, eu reuni toda a ficha do grupo para você, baka... Olha o capricho:\n• Nome do Grupo: *${puxarInfo.subject}*\n• ID: *${puxarInfo.id}*\n-\n• Este grupo foi criado por: *@${infoCreator.replace("@lid", "")}*\n• Data/hora de criação do grupo: *${moment(`${puxarInfo.creation}` * 1000).tz("America/Sao_Paulo").format("DD/MM/YYYY HH:mm:ss")}*\n• Horário e data da última alteração no grupo: *${moment(`${puxarInfo.subjectTime}` * 1000).format("DD/MM/YYYY HH:mm:ss")}*\n-\n• Quantidade de adminstradores: *${groupAdmins.length}*\n• Quantidade de membros: *${somembros.length}*\n• Soma total de membros e admins do grupo: *${puxarInfo.participants.length} participantes*\n-\n• Este grupo está fechado no momento? *${returnAnnounce}*\n• As informações do grupo podem ser alteradas por membros? *${returnRestrict}*\n-\n• Para ver as atividades dos participantes, use: *${prefix}atividade*\n• Para ver os membros inativos no grupo, use: *${prefix}inativos [quantidade de mensagens]*, ex: ${prefix}inativos 10\nNão fica dizendo que eu não te ajudo, viu?!`;
await kira.sendMessage(
from,
{
image: { url: ppUrl },
caption: infoGroup,
mentions: [infoCreator],
},
{ quoted: selo }
);
}
};