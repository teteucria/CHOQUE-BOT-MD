module.exports = {
nome: ["listalinks"],
executar: async ({
SoDono,
from,
mess,
pathAntiLink,
readJSON,
reagir,
reply
}) => {

if (!SoDono) return reply(mess.onlyOwner());
reagir(from, "✅");
const data = readJSON(pathAntiLink, { links: [] });
if (data.links.length === 0)
return reply("Hmph! Nenhum link proibido cadastrado... Está tudo limpo, nem sei por que a cara de decepção, baka!");
reply(`Hmph! 🚫 *Links Proibidos:*\n\n${data.links.map((l,i)=>`${i+1}. ${l}`).join("\n")}\n\nFiz a lista completa, eu que organizei, viu?! Não me agradeça.`);
}
};