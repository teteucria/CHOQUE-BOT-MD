const { isUrl } = require("../../utils/helpers");

module.exports = {
nome: ["fotomenu"],
executar: async ({
SoDono,
downloadMediaMessage,
from,
info,
isnit,
logos,
mess,
q,
reagir,
reply,
saveJSON,
upload
}) => {

{
if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner());
try {
await reagir(from, "✅️");

// Caso 1: link direto passado como argumento (ex: .fotomenu https://...)
if (q && isUrl(q)) {
const url = q.trim();
logos.img = url;
saveJSON('./settings/logos.json', logos);
return reply(`Hmph! - Imagem configurada para:\n${url}\nFicou ótima, eu mesma que fiz... Mas não se acostume comigo, viu?!`);
}

// Caso 2: imagem respondida (comportamento original)
const quotedData = JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message?.extendedTextMessage?.contextInfo?.message;
let midiaObj = quotedData?.imageMessage;
if (!midiaObj) return reply("Hmph! Não consegui coletar a imagem... Manda um link direto ou responde uma imagem, baka?!");
const buffer = await downloadMediaMessage({message: { [Object.keys(quotedData)[0]]: midiaObj }}, "buffer");
const extension = midiaObj.mimetype?.split('/')[1] || 'bin';
const nomeSimulado = `${Date.now()}.${extension}`;
const url = await upload({ buffer, originalname: nomeSimulado });
logos.img = url;
saveJSON('./settings/logos.json', logos);
reply(`Hmph! - Imagem configurada para:\n${url}\nFicou ótima, eu mesma que fiz... Mas não se acostume comigo, viu?!`);
} catch (e) {
console.log(e);
await reagir(from, '❌');
reply("Hmph! Erro ao tentar atualizar a nova logo icon... Nem eu aguento mais, tenta de novo, bobinho(a)!");
}
}
}
};