module.exports = {
nome: ["convite"],
executar: async ({
kira,
from,
sender,
prefix,
reply,
selo,
reagir,
args,
budy,
mess}) => {

if (!budy.includes("chat.whatsapp.com"))
return reply("Hmph! Cadê o link do grupo que você quer que eu entre, baka?! Não sou adivinha, viu?!");
reagir(from, "✅");
cnvt = args.join(" ");
reply(`O convite para eu entrar no seu grupo foi enviado... Agora é só esperar o dono aceitar. N-não fica ansioso, tá?! Não é como se eu estivesse animada com isso também...`);
await kira.sendMessage(SoDono, {text: mess.groupInvitation(sender, cnvt, prefix)}, {quoted: selo});
}
};