module.exports = {
  nome: ["nome-bot"],
  category: "owner",
  ownerOnly: true,
  description: "Altera o nome do bot.",
  usage: "<novo nome>",
  executar: async ({
    SoDono,
    info,
    isnit,
    mess,
    q,
    reply,
    setting
  }) => {
    if (!SoDono && !isnit && !info.key.fromMe)
      return reply(mess.onlyOwner());

    const novoNome = setting.setBotName(q.trim());
    reply(`Hmph! O nome do bot foi alterado com sucesso para: ${novoNome}... Eu até gostei do resultado, mas não é porque você pediu ou algo assim, viu?!`);
  }
};
