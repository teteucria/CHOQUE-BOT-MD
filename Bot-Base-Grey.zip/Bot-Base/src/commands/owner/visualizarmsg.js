module.exports = {
nome: ["visualizarmsg"],
executar: async ({
SoDono,
isVisualizar,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isVisualizar) {
nescessario.visualizarmsg = true;
setNes(nescessario);
reply("Hmph! Ativei com sucesso o recurso de ver mensagens neste grupo e privados... Agora posso enxergar tudo, então se comportem, baka! 🙇🏻‍♂️💖️");
} else if (isVisualizar) {
nescessario.visualizarmsg = false;
setNes(nescessario);
reply("Hmph! Desativei com sucesso o recurso de ver mensagens neste grupo e privados... Devo admitir que sinto um pouco de falta, mas tanto faz! 🙇🏻‍♂️💖");
}
}
};