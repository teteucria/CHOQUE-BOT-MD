module.exports = {
nome: ["atualizar"],
executar: async ({
SoDono,
from,
fs,
getFileBuffer,
global,
info,
logos,
menu,
mess,
path,
quoted,
reply,
selo,
  prefix,
kira
}) => {

{
if (!SoDono) return reply(mess.onlyOwner());
const mDoc = info.message.documentMessage || info.message.extendedTextMessage?.contextInfo?.quotedMessage?.documentMessage;
if (mDoc) {
try {
const nomeArquivo = mDoc.fileName;
if (nomeArquivo.includes('node_modules')) return reply('Hmph! ❌ Operação negada para diretórios do sistema... Como assim tentando mexer nisso?! N-nem eu mexeria nesse lugar, baka!');

const procurarArquivo = (dir, target) => {
const files = fs.readdirSync(dir);
for (const file of files) {
const res = path.resolve(dir, file);
if (fs.statSync(res).isDirectory()) {
if (file !== 'node_modules' && file !== '.git' && file !== '.next') {
const found = procurarArquivo(res, target);
if (found) return found;
}
} else if (file === target) {
return res;
}
}
return null;
};

const caminhoExistente = procurarArquivo('./', nomeArquivo);
global.tempBuffer = await getFileBuffer(mDoc, 'document');

if (caminhoExistente) {
const corpoUpdate = [
`Hmph! 📂 *ARQUIVO ENCONTRADO:* \`${nomeArquivo}\``,
` `,
`Este arquivo já existe no sistema... O que deseja fazer, baka? Não é como se eu tivesse o dia todo para esperar!`,
` `,
`⚙️ *OPÇÕES:*`,
`1. Substituir a versão antiga.`,
`2. Receber a versão atual no privado.`
].join('\n');

await kira.sendMessage(from, {
interactiveMessage: {
title: `${corpoUpdate}`,
footer: `*kira SYSTEM*`,
buttons: [{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "📋 ESCOLHER AÇÃO",
sections: [{
title: "OPÇÕES DISPONÍVEIS",
rows: [
{ title: "Substituir Arquivo", description: "Hmph! Sobrescrever a versão antiga.", id: `${prefix}confirmar_up substituir|${nomeArquivo}` },
{ title: "Receber Atual (PV)", description: "Hmph! Envia o arquivo do bot para você... não é porque eu quero, tá?!", id: `${prefix}confirmar_up enviar|${nomeArquivo}` }
]
}]
})
}],
image: { url: logos.img }
}
}, { quoted: selo });

} else {
fs.writeFileSync(`./${nomeArquivo}`, global.tempBuffer);
delete global.tempBuffer;
return reply(`✅ Arquivo novo \`${nomeArquivo}\` adicionado à raiz do bot... Fiz certinho, então não fica me olhando assim, tá?! Não é como se eu fizesse isso por qualquer um!`);
}
} catch (err) {
console.log(err);
return reply("Hmph! ❌ Erro interno ao processar... Nem eu consigo consertar isso assim, tanto faz! Tenta de novo, baka!");
}
} else {
reply('Hmph! ❓ Marque o arquivo que deseja enviar, bobinho(a)... Não me faça adivinhar, tá?!');
}
}
}
};