module.exports = {
nome: ["infoaluguel","inforent","info_aluguel"],
executar: async ({
from,
getInfo,
prefix,
selo,
kira
}) => {

await kira.sendMessage(from, {text: getInfo.infoRent(prefix)}, {quoted: selo});
}
};