module.exports = {
nome: ["status"],
executar: async ({
Antidoc,
Antiloc,
SoDono,
from,
info,
isAntiAudio,
isAntiCtt,
isAntiFlood,
isAntiImg,
isAntiNotas,
isAntiPv,
isAntiStatus,
isAntiSticker,
isAntiVid,
isAnticall,
isAnticatalogo,
isAntifake,
isAntilinkgp,
isAutodown,
isAutofigu,
isAutorepo,
isGroup,
isGroupAdmins,
isModobn,
isPalavrao,
isPayment,
isSimi,
isWelkom,
ischyt,
isnit,
issupre,
mess,
reagir,
reply
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins && !SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe)
return reply(mess.onlyAdmins());
reagir(from, '🟢');
reply(mess.statusBot(isAnticall, isAntiPv, isAntilinkgp, isAntifake, isAntiFlood, isPalavrao, isAntiStatus, isPayment,
 isAntiImg, isAntiVid, isAntiAudio, isAntiSticker, Antidoc, isAntiCtt, Antiloc, isAntiNotas, isAnticatalogo, isWelkom,
 isSimi, isAutofigu, isAutorepo, isAutodown, isModobn));
}
};