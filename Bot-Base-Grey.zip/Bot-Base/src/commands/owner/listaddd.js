module.exports = {
nome: ["listaddd","dddlist"],
executar: async ({
from,
groupMembers,
isGroup,
isGroupAdmins,
mentions,
mess,
q,
reply,
selo,
  prefix,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (q.length < 1)
return reply(`Hmph! Fale o código do estado, por exemplo: *${prefix}listaddd 82*... Não é tão difícil, baka!`);
if (isNaN(q)) return reply(`Hmph! Fale o código de um estado (DDD), por exemplo: *${prefix}listaddd 82*... Eu até repeti para você, que gentil da minha parte, hein?!`);
teks = `Hmph! • Lista de números brasileiros com o DDD *${q}* presentes neste grupo:\n–\n`;
men = [];
    for (let mem of groupMembers) {
        if (mem.id.startsWith(55 + q)) {
            teks += `⇒ @${mem.id.split("@")[0]}\n`;
            men.push(mem.id);
        }
    }
if (teks.indexOf("⇒") < 0)
return reply(
"Hmph! Nenhum *número brasileiro* com esse DDD foi encontrado no grupo... Você deve ter errado o número, baka!"
);
await kira
.sendMessage(
from,
{ text: teks, mentions: men },
{ quoted: selo }
)
.catch(async (error) => {
reply(mess.error());
});
}
};