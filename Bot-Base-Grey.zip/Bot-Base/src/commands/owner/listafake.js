module.exports = {
nome: ["listafake","listafakes"],
executar: async ({
from,
groupMembers,
isGroup,
isGroupAdmins,
mess,
reagir,
reply
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
reagir(from, "🇺🇸");
let txt;
txt = `Hmph! 🇺🇸 *Lista de números fake presentes neste grupo:*\n`;
let totalfake = 0;
    for (i = 0; i < groupMembers.length; i++) {
        if (!groupMembers[i].id.startsWith("55")) {
            txt += `⇒ ${isGroupAdmins ? "@" : "wa.me/"}${groupMembers[i].id.split("@")[0]}\n`;
            totalfake += 1;
        }
    };
txt += `\n🇺🇸 Total: ${totalfake} - contei direitinho, viu?!`;
if (totalfake > 0) {
reply(txt);
} else {
reply("Hmph! Não há números fake neste grupo... Que bom, né?! Não precisa ficar desapontado, baka!");
}
}
}
};