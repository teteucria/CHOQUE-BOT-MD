module.exports = {
  nome: ["nick-dono"],
  category: "owner",
  ownerOnly: true,
  description: "Altera o nick (nome exibido) do dono do bot.",
  usage: "<novo nick>",
  executar: async ({
    SoDono,
    info,
    isnit,
    mess,
    q,
    reply,
    setting
  }) => {
    if (!SoDono && !isnit && !info.key.fromMe)
      return reply(mess.onlyOwner());

    const novoNick = setting.setOwnerName(q.trim());
    reply(`Hmph! O nick do dono foi configurado para: ${novoNick}... Fiz rapidinho, mas não se acostume com o meu trabalho, tá?!`);
  }
};
