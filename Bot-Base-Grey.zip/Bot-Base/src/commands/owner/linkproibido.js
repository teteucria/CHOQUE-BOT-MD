module.exports = {
nome: ["linkproibido","addlink"],
executar: async ({
SoDono,
from,
mess,
pathAntiLink,
q,
readJSON,
reagir,
reply,
saveJSON
}) => {

{
if (!SoDono) return reply(mess.onlyOwner());
if (!q) return reply("Hmph! Digite o domínio, bobinho(a)... Não sou adivinha, tá?!");
reagir(from, "✅");
const data = readJSON(pathAntiLink, { links: [] });
if (data.links.includes(q)) return reply("Hmph! Esse link já está adicionado na lista... Presta atenção, não é como se eu não lesse o que você manda!");
data.links.push(q);
saveJSON(pathAntiLink, data);
reply(`✅ Link *${q}* adicionado à lista proibida... Fiz porque quis, mas não acostume, viu?!`);
}
}
};