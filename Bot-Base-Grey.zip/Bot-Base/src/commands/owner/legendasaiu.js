module.exports = {
nome: ["legendasaiu"],
executar: async ({
args,
body,
dataGp,
isGroup,
isGroupAdmins,
isWelkom,
mess,
reply,
  prefix,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (args.length < 1)
return reply("Hmph! Escreva a mensagem de saída ou, para desativar, use: 0... Presta atenção, baka!");
teks = body.slice(13);
if (isWelkom) {
dataGp[0].wellcome[0].legendasaiu = Number(teks) === 0 ? 0 : teks;
setGp(dataGp);
reply("Hmph! Mensagem de saída do bemvindo definida com sucesso!... Arrumadinho, não é como se eu tivesse caprichado ou algo assim, tá?!");
} else {
reply(
`Hmph! Ative o ${prefix}bemvindo para o recurso de edição de mensagem... Sem isso nem eu consigo fazer nada, bobinho(a)!`
);
}
}
};