module.exports = {
nome: ["logoicon"],
executar: async ({
SoDono,
downloadMediaMessage,
from,
info,
isnit,
logos,
mess,
reagir,
reply,
saveJSON,
upload
}) => {

if (!SoDono && !isnit && !info.key.fromMe) return reply(mess.onlyOwner());
try {
await reagir(from, "✅️");
const quotedData = JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message?.extendedTextMessage?.contextInfo?.message;
let midiaObj = quotedData?.imageMessage;
if (!midiaObj) return reply("Hmph! Não consegui coletar a imagem... Como quer que eu trabalhe assim, baka?!");
const buffer = await downloadMediaMessage({message: { [Object.keys(quotedData)[0]]: midiaObj }}, "buffer");
const extension = midiaObj.mimetype?.split('/')[1] || 'bin';
const nomeSimulado = `${Date.now()}.${extension}`;
const url = await upload({ buffer, originalname: nomeSimulado });
logos.icon = url;
saveJSON('./settings/logos.json', logos);
reply(`Hmph! - Logo icon configurada para:\n${url}\nFicou perfeita, eu mesma que escolhi... mas não se acostume, tá?!`);
} catch (e) {
console.log(e);
await reagir(from, '❌');
reply("Hmph! Erro ao tentar atualizar a nova logo icon... Nem eu, a melhor da academia, consigo consertar isso agora. Tenta de novo, bobinho(a)!");
}
}
};