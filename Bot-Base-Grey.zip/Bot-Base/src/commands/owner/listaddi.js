module.exports = {
nome: ["listaddi","ddilist"],
executar: async ({
from,
groupMembers,
isGroup,
isGroupAdmins,
mentions,
mess,
q,
reply,
selo,
  prefix,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (q.length < 1)
return reply(`Hmph! Fale o código de um país, por exemplo: *${prefix}listaddi 55*... Não é tão difícil, baka!`);
if (isNaN(q))
return reply(`Hmph! Fale o código de um país, por exemplo: *${prefix}listaddi 55*... Eu até repeti para você, que gentil da minha parte, hein?!`);
teks = `Hmph! • Número com código de país +${args[0]} registrados no grupo:\n–\n`;
men = [];
    for (let mem of groupMembers) {
        if (mem.id.startsWith(q)) {
            teks += `⇒ @${mem.id.split("@")[0]}\n`;
            men.push(mem.id);
        }
    }
if (teks.indexOf("⇒") < 0)
return reply(`Hmph! Nenhum número com o DDI *+${args[0]}* foi encontrado... Você deve ter errado o número, baka!`);
await kira.sendMessage(from, {text: teks, mentions: men}, {quoted: selo}).catch(async (error) => {
reply(mess.error());
});
}
};