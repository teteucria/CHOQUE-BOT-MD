module.exports = {
nome: ["verificado-global"],
executar: async ({
SoDono,
isVerificado,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isVerificado) {
nescessario.verificado = true;
setNes(nescessario);
reply("Hmph! O verificado foi desativado... Ou seja, o selo foi retirado de todos os meus comandos! *Para reativar, é só digitar o comando novamente.* Não é como se eu sentisse falta dele, tanto faz!");
} else if (isVerificado) {
nescessario.verificado = false;
setNes(nescessario);
reply(`Hmph! O verificado foi ativado... Ou seja, o selo foi colocado em todos os meus comandos! *Para remover, use o comando novamente.* Ficou até mais chique agora, mas não me agradeça, tá?!`);
}
}
};