module.exports = {
nome: ["deltake","remtake"],
executar: async ({
JSON,
fs,
reply,
rgtake,
sender
}) => {

var i8 = rgtake.map(i => i.usuario).indexOf(sender);
if (i8 < 0) {
return reply(`❌ Hmph! Você não tem uma marca d'água registrada para remover... Que desperdício, tanto faz! Não fica inventando, baka!`);
}
rgtake.splice(i8, 1);
reply(`✅ Sua marca d'água foi removida... Ficou tudo limpinho, eu que fiz! Mas não me agradeça muito, não é porque eu queria fazer isso por você ou algo assim, tá?!`);
}
};