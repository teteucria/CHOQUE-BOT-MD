module.exports = {
nome: ["owner","odono","dono","dona","criador","criadora","infodono"],
executar: async ({
NomeDoBot,
from,
getInfo,
mentions,
ownerName,
ownerNumber,
prefix,
reagir,
selo,
sender,
kira
}) => {

await reagir(from, "💖");
await kira.sendMessage(from, {text: getInfo.infoOwner(prefix, ownerName, ownerNumber, NomeDoBot, sender), mentions: [sender]}, {quoted: selo});
}
};