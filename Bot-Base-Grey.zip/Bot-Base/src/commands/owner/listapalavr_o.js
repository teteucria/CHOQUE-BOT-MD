module.exports = {
nome: ["listapalavrão","listapalavra","listpalavra"],
executar: async ({
isPalavrao,
isPalavras,
reply
}) => {

if (!isPalavrao) return reply("Hmph! Anti palavrão desativado!... Não adianta perguntar, baka!");
if (isPalavras.length < 0) return reply(`Hmph! Não existe nenhuma palavra proibida na lista... Que grupo certinho, nem parece que você administra, hein?!`);
reply(`Hmph! • [Total: *${isPalavras.length}*] - Lista de palavrões adicionados no grupo:\n–\n${isPalavras.map((v, index) => `*${index + 1}.* ➸${v}`).join("\n")}\nFiz a listinha completa, hein? Pode me agradecer... ou não, tanto faz!`);
}
};