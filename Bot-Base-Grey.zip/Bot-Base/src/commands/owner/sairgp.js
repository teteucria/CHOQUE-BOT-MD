module.exports = {
nome: ["sairgp"],
executar: async ({
SoDono,
from,
info,
isGroup,
reply,
kira
}) => {

if (isGroup && !SoDono && !info.key.fromMe)
return reply("Hmph! Este comando só o bot ou o dono pode executar.. Você acha que qualquer um pode me mandar embora, baka?!");
try {
await kira.groupLeave(from);
} catch (erro) {
reply(String(erro));
}
}
};