module.exports = {
nome: ["promover"],
executar: async ({
from,
groupMembers,
isBotGroupAdmins,
isGroupAdmins,
menc_os2,
mentions,
mess,
reply,
kira
}) => {

if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!menc_os2) return reply("Hmph! Marque a mensagem do usuário ou o @ dele... E lembre-se de marcar só um usuário, baka! Não sou adivinha!");
if (!JSON.stringify(groupMembers).includes(menc_os2)) return reply("Hmph! Este usuário foi removido do grupo ou saiu... Não será possível promover, tanto faz! Procure outra pessoa, bobinho(a)!");
kira.sendMessage(from, {text: `@${menc_os2.split("@")[0]} foi promovido(a) a administrador(a) com sucesso... Fiz o que mandou, não é porque eu queria ajudar, tá?!`, mentions: [menc_os2]});
kira.groupParticipantsUpdate(from, [menc_os2], "promote");
}
};