module.exports = {
  nome: ["numero-dono"],
  category: "owner",
  ownerOnly: true,
  description: "Altera o número do dono do bot.",
  usage: "<número>",
  executar: async ({
    SoDono,
    info,
    isnit,
    mess,
    q,
    reply,
    setting
  }) => {
    if (!SoDono && !isnit && !info.key.fromMe)
      return reply(mess.onlyOwner());
    if (q.match(/[a-z]/i)) return reply("Hmph! É apenas números.. Presta atenção no que você digita, baka! Eu não vou ficar repetindo!");

    const numero = q.trim().replace(new RegExp("[()+-/ +/]", "gi"), "");
    setting.setOwnerNumber(numero);
    reply(`Hmph! O número do dono foi configurado com sucesso para: ${numero}... Eu conferi tudo, sou boa nisso, mas não me enche, tá?!`);
  }
};
