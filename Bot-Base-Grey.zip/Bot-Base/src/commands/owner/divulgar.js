module.exports = {
  nome: ["divulgar"],
  executar: async ({
    SoDono, info, isImage, isVideo, downloadMediaMessage,
    from, mess, reply, kira, q, quoted
  }) => {
    if (!SoDono && !info.key.fromMe) return reply(mess.onlyOwner());

    let grupos = await kira.groupFetchAllParticipating();
    let ids = Object.keys(grupos);
    if (!ids.length) return reply("Hmph! Não estou em nenhum grupo... Então não tem como divulgar, tanto faz! Não me culpe, baka!");

    reply(`📢 Hmph! Divulgando para ${ids.length} grupos... Fico até com preguiça, mas já que é você pedindo...`);

    let texto = q || "";

    try {
      if (quoted) {
        let quotedType = Object.keys(quoted)[0];
        if (quotedType === "conversation") {
          for (let id of ids) await kira.sendMessage(id, { text: quoted.conversation }).catch(() => {});
        } else if (quotedType === "extendedTextMessage") {
          for (let id of ids) await kira.sendMessage(id, { text: quoted.extendedTextMessage.text }).catch(() => {});
        } else if (quotedType === "imageMessage") {
          let buffer = await downloadMediaMessage({ message: quoted }, "buffer");
          let caption = texto || quoted.imageMessage.caption || "";
          for (let id of ids) await kira.sendMessage(id, { image: buffer, caption }).catch(() => {});
        } else if (quotedType === "videoMessage") {
          let buffer = await downloadMediaMessage({ message: quoted }, "buffer");
          let caption = texto || quoted.videoMessage.caption || "";
          for (let id of ids) await kira.sendMessage(id, { video: buffer, caption }).catch(() => {});
        } else {
          return reply("Hmph! Tipo de mídia não suportado... Use imagem, vídeo ou texto, bobinho(a). Nem eu consigo divulgar isso, tanto faz!");
        }
      } else if (isImage) {
        let buffer = await downloadMediaMessage({ message: info.message }, "buffer");
        for (let id of ids) await kira.sendMessage(id, { image: buffer, caption: texto }).catch(() => {});
      } else if (isVideo) {
        let buffer = await downloadMediaMessage({ message: info.message }, "buffer");
        for (let id of ids) await kira.sendMessage(id, { video: buffer, caption: texto }).catch(() => {});
      } else if (texto) {
        for (let id of ids) await kira.sendMessage(id, { text: texto }).catch(() => {});
      } else {
        return reply("Hmph! Envie texto, mídia, ou responda a uma mensagem para divulgar... Presta atenção, não sou eu que tenho que adivinhar o que você quer, tá?!");
      }

      reply(`✅ Divulgação concluída em ${ids.length} grupos... Fiz tudo direitinho, mas não se acostume, hein?! Não é como se eu fizesse isso por qualquer um, viu?`);
    } catch (e) {
      reply(`Hmph! Erro na divulgação: ${e.message}... Até eu me cansei, tenta de novo depois, baka!`);
    }
  }
};