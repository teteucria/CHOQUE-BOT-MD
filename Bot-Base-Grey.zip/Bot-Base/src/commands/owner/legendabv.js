module.exports = {
nome: ["legendabv"],
executar: async ({
args,
body,
dataGp,
isGroup,
isGroupAdmins,
isWelkom,
mess,
reply,
  prefix,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (args.length < 1)
return reply("*Hmph! Escreva a mensagem de boas-vindas*... Você quer que eu adivinhe, baka?!");
teks = body.slice(11);
if (isWelkom) {
dataGp[0].wellcome[0].legendabv = teks;
setGp(dataGp);
reply("*Hmph! Mensagem de boas-vindas definida com sucesso!*... Ficou linda, eu que fiz! Mas não se acostume com isso, tá?!");
} else {
reply(`Hmph! Ative o ${prefix}bemvindo 1 primeiro... Não adianta correr, bobinho(a)!`);
}
}
};