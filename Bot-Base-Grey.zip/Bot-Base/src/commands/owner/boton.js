module.exports = {
nome: ["boton","botoff"],
executar: async ({
SoDono,
isBotoff,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isBotoff) {
nescessario.botoff = true;
setNes(nescessario);
reply("Hmph! Desativando todas as funções e parando a execução de comandos por membros... Não é como se eu quisesse ficar parada, mas já que você pediu, tanto faz! 🙇🏻‍♂️💖️");
} else if (isBotoff) {
nescessario.botoff = false;
setNes(nescessario);
reply(`Ativando todos os funcionamentos... Agora sim, todo mundo pode me usar de novo. N-não se acostume com isso, viu?! 🙇🏻‍♂️💖️`);
}
}
};