module.exports = {
nome: ["nomegp"],
executar: async ({
body,
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mess,
reply,
selo,
text,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
await kira.groupUpdateSubject(from, `${body.slice(9)}`);
await kira.sendMessage(from, {text: "Hmph! Sucesso, o nome do grupo foi alterado... Fiz exatamente como mandou, mas não me agradeça muito, tá?!"}, {quoted: selo});
}
};