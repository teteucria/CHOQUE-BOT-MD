module.exports = {
nome: ["infobv","infowelcome","infobemvindo"],
executar: async ({
from,
getInfo,
prefix,
selo,
kira
}) => {

await kira.sendMessage(from, {text: getInfo.bemvindo(prefix)}, {quoted: selo});
}
};