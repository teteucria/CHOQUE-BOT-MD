module.exports = {
nome: ["seradm"],
executar: async ({
SoDono,
from,
isBotGroupAdmins,
mentions,
mess,
reply,
sender,
kira
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
await mentions(`@${sender.split("@")[0]} Pronto... Agora você é um administrador. Espero que saiba a responsabilidade que eu te dei, viu?! Não me faça me arrepender, baka!`, [sender], true);
await kira.groupParticipantsUpdate(from, [sender], "promote");
}
};