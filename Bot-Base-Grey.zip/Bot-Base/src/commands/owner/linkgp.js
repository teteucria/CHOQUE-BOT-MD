module.exports = {
nome: ["linkgp","linkgroup"],
executar: async ({
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
reply,
kira
}) => {

if (!isGroup)
return reply("Hmph! Este comando só pode ser usado em grupos!... Não sabe a diferença de grupo e privado, baka?!");
if (!isGroupAdmins)
return reply("Hmph! Apenas administradores podem usar este comando!... Você acha que qualquer um pode mandar em mim? Tanto faz!");
if (!isBotGroupAdmins)
return reply("Hmph! Eu preciso ser administradora para executar este comando!... Até eu, a melhor da academia, preciso de permissão, viu?!");
const linkgc = await kira.groupInviteCode(from);
await reply(`Hmph! Toma, o link do grupo:\nhttps://chat.whatsapp.com/${linkgc}\nFiz rápido, né?! Não se acostume com isso!`);
}
};