module.exports = {
  nome: ["setprefix", "prefixo-bot"],
  category: "owner",
  ownerOnly: true,
  description: "Altera o prefixo de comandos do bot.",
  usage: "<novo prefixo>",
  executar: async ({
    SoDono,
    args,
    info,
    ischyt,
    isnit,
    issupre,
    mess,
    q,
    reply,
    setting
  }) => {
    if (args.length < 1) return;
    if (!SoDono && !isnit && !issupre && !ischyt && !info.key.fromMe)
      return reply(mess.onlyOwner());

    const novoPrefixo = q.trim();
    setting.setPrefix(novoPrefixo);
    reply(`Hmph! O prefixo foi alterado com sucesso para: ${novoPrefixo}... Agora use direito, hein?! Não me faça repetir, baka!`);
  }
};
