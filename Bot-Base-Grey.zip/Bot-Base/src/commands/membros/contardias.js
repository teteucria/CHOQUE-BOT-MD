module.exports = {
nome: ["contardias","countdays"],
executar: async ({
command,
countDays,
mess,
prefix,
q,
reply,
timeDate
}) => {

if (!q.includes("/")) return reply(`Hmph! Você esqueceu da */* para separar os campos.. Até eu sei fazer isso direito! Exemplo: *31/03/2024*, baka!`);
if (q.length < 10) return reply(`Hmph! Deve conter a data completa *(dia/mês/ano)* após o comando.. Toma o exemplo, bobinho(a): *${prefix + command} 31/03/2024*`);
try {
var tomp = await timeDate("DD/MM/YYYY");
countDay = await countDays(q.split("/"), tomp.split("/"));
reply(`Hmph! Eu calculei tudinho, viu?! Faltam exatos: *${countDay}* dia(s).. S-só desta vez, tá?`);
} catch (error) {
return reply(mess.error());
}
}
};