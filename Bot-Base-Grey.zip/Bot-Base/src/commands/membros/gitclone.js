module.exports = {
nome: ["gitclone"],
executar: async ({
args,
fetch,
from,
mess,
prefix,
q,
reagir,
reply,
selo,
kira
}) => {
{
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;
if (!q) return reply(`Hmph! Exemplo: ${prefix}gitclone https://github.com/whiskeysockets/baileys.. Não sabe nem clonar repositório? Baka!`);
await reagir(from, '✅');
let [user, repo] = args[0].match(regex1) || [];
repo = repo.replace(/.git$/, "");
let filename = (await fetch(q, { method: "HEAD" })).headers
.get("content-disposition")
.match(/attachment; filename=(.*)/)[1];
await kira.sendMessage(from, {document: {url: `https://api.github.com/repos/${user}/${repo}/zipball`},
fileName: filename + ".zip",
mimetype: "application/zip"}, {quoted: selo}).catch(async (error) => {
return reply(mess.error());
});
}
}
};