module.exports = {
nome: ["calculadora","calcular","calc"],
executar: async ({
abcdefghijklmnopqrstwuvxyz,
gi,
q,
reply,
rsp,
t
}) => {

rsp = q
.replace("x", "*")
.replace('"', ":")
.replace(new RegExp("[()abcdefghijklmnopqrstwuvxyz]", "gi"), "")
.replace("÷", "/");
return reply("Hmph! Eu que calculei pra você, então agradece.. Resultado: " + JSON.stringify(eval(rsp, null, "\t")) + " ...não se acostume com isso, tá?!");
}
};