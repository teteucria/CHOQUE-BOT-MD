const fs = require('fs');
const path = require('path');
const { tmpdir } = require('os');
const Crypto = require('crypto');
const webp = require('node-webpmux');

async function writeExifDireto(media, metadata) {
  const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
  const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`);
  fs.writeFileSync(tmpFileIn, media);

  const img = new webp.Image();
  const json = {
    'sticker-pack-id': 'kira MD',
    'sticker-pack-name': metadata.packname,
    'sticker-pack-publisher': metadata.author,
    'emojis': metadata.categories || ['']
  };
  const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
  const jsonBuff = Buffer.from(JSON.stringify(json), 'utf-8');
  const exif = Buffer.concat([exifAttr, jsonBuff]);
  exif.writeUIntLE(jsonBuff.length, 14, 4);

  await img.load(tmpFileIn);
  fs.unlinkSync(tmpFileIn);
  img.exif = exif;
  await img.save(tmpFileOut);

  const out = fs.readFileSync(tmpFileOut);
  fs.unlinkSync(tmpFileOut);
  return out;
}

async function renameContextStickerFix(pack, author, info, kira, from, selo) {
  const stickerMsg = info.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage;
  if (!stickerMsg) throw new Error('Marque uma figurinha.');
  const mediaObj = { message: { stickerMessage: stickerMsg } };
  const buff = await kira.downloadMediaMessage(mediaObj, 'buffer');

  const out = await writeExifDireto(buff, { packname: pack, author });
  await kira.sendMessage(from, { sticker: out }, { quoted: selo });
  return out;
}

module.exports = {
  nome: ['take', 'roubar', 'rename'],
  executar: async ({
    command,
    from,
    info,
    prefix,
    isQuotedSticker,
    q,
    reagir,
    reply,
    rgtake,
    selo,
    sender,
    kira
  }) => {
    if (!isQuotedSticker) return reply('🧩 Hmph! Marque uma figurinha primeiro, bobinho(a)!');
    await reagir(from, '⏳');
    try {
      let pack, author;
      if (command === 'take' || command === 'roubar') {
        const i8 = rgtake.map(i => i.usuario).indexOf(sender);
        if (i8 < 0)
          return reply(`Hmph! Você ainda não registrou sua marca d’água com *${prefix}rgtake kira|bot*.. Como eu vou usar o take assim? Baka!`);
        pack = rgtake[i8].mcdagua1;
        author = rgtake[i8].mcdagua2;
      } else {
        if (!q.includes('|')) return reply(`Hmph! Uso correto: ${prefix}rename nome|autor.. Presta atenção, tá?!`);
        [pack, author] = q.split('|');
      }
      await renameContextStickerFix(pack, author, info, kira, from, selo);
      await reagir(from, '✅');
    } catch (err) {
      console.error('Erro no take/rename:', err);
      await reagir(from, '❌');
      reply('❌ Hmph! Erro ao processar a figurinha.. Tanto faz, mas eu tentei, viu?!');
    }
  }
};