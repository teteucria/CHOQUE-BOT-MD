module.exports = {
nome: ["rntake"],
executar: async ({
command,
fs,
prefix,
q,
reply,
rgtake,
sender
}) => {

i8 = rgtake.map((i) => i.usuario).indexOf(sender);
if (i8 < 0) return reply(`Hmph! Como você quer renomear algo que você nem tem registro? Baka! Use *${prefix}rgtake* primeiro, viu?!`);
if (!q.includes("|")) return reply(`Hmph! Você usou de forma errada, siga o exemplo: *${prefix + command} wa|bot*.. Até eu faço melhor que isso!`);
var [MARCAD1, MARCAD2] = q.split("|");
if (!MARCAD1) return reply(`Hmph! Você esqueceu de preencher o primeiro campo... Ex: *${prefix + command} wa|bot*, bobinho(a)!`);
if (!MARCAD2) return reply(`Hmph! Você esqueceu de preencher o segundo campo... Ex: *${prefix + command} wa|bot*, tá?!`);
rgtake[i8].mcdagua1 = MARCAD1;
rgtake[i8].mcdagua2 = MARCAD2;
reply(`Hmph! Sua marca ďágua foi alterada para *"${MARCAD1}|${MARCAD2}"* com sucesso.. N-não é porque eu me importo, tá? Só fiz porque quis!`);
}
};