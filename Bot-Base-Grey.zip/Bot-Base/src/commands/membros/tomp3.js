module.exports = {
nome: ["tomp3"],
executar: async ({
DLT_FL,
from,
fs,
getExtension,
getFileBuffer,
getRandom,
info,
isMedia,
isQuotedImage,
isQuotedVideo,
quoted,
reagir,
reply,
selo,
kira
}) => {

if ((isMedia && !info.message.imageMessage) || isQuotedVideo) {
post = isQuotedImage
? JSON.parse(JSON.stringify(info).replace("quotedM", "m"))
.message.extendedTextMessage.contextInfo.message
.imageMessage
: info.message.videoMessage;
await reagir(from, '✅');
encmedia = isQuotedVideo
? info.message.extendedTextMessage.contextInfo.quotedMessage
.videoMessage
: info.message.videoMessage;
rane = getRandom("." + (await getExtension(encmedia.mimetype)));
buffimg = await getFileBuffer(encmedia, "video");
fs.writeFileSync(rane, buffimg);
media = rane;
ran = getRandom(".mp4");
exec(`ffmpeg -i ${media} ${ran}`, async (err) => {
await DLT_FL(media);
if (err) return reply("Hmph! Ocorreu uma falha ao fazer a conversão do vídeo para mp3.. Que droga, tenta de novo, baka!");
buffer = fs.readFileSync(ran);
await kira.sendMessage(from, {audio: buffer, mimetype: "audio/mpeg" }, {quoted: selo});
await DLT_FL(ran);
});
} else {
reply("Hmph! Marque o vídeo para transformar em áudio, por favor... Presta atenção, bobinho(a)!");
}
}
};