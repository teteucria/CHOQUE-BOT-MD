module.exports = {
nome: ["calendario","dados"],
executar: async ({
SoDono,
groupName,
isGroup,
pushname,
tempo,
NomeDoBot,
ownerName,
day,
hora,
date,
from,
reagir,
reply,
sender,
kira
}) => {

setTimeout(() => {
reagir(from, "📅");
}, 300);
var getGroups = await kira.groupFetchAllParticipating();
var groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
var ingfoo = groups.map((v) => v);
ingfoo.sort((a, b) => a[0] < b.length);
day = `Hmph! ${tempo}, ${pushname}! Só porque você pediu, viu?! N-não se acostume!\n• Grupo: *${isGroup ? groupName : "Privado"}*\n• Data & Hora: *${date()} ${hora()}*\n• Nome do Bot: *${NomeDoBot}*\n• Proprietário: *${ownerName}*\n• Estou operando em *${ingfoo.length}* grupos.`;
reply(`${day}`);
}
};