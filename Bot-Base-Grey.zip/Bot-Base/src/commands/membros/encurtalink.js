module.exports = {
nome: ["encurtalink","tinyurl"],
executar: async ({
args,
axios,
command,
mess,
prefix,
q,
reply
}) => {

if (args.length < 1)
return reply(`❌️ *Hmph! Forma incorreta, bobinho(a)! Use está como exemplo:* ${prefix + command} https://instagram.com/embrynp`);
anu = await axios.get(`https://tinyurl.com/api-create.php?url=${q}`);
reply(`Hmph! *Link encurtado com sucesso*.. Toma aqui ó: ${anu.data}... S-só fiz porque eu quis, viu?!`).catch(
async (error) => {
reply(mess.error());
}
);
}
};