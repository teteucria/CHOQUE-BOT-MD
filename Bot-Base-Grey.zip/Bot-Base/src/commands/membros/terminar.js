const { Casal } = require("../../database");

module.exports = {
nome: ["terminar"],
executar: async ({
from,
reagir,
reply,
sender
}) => {

const casal = await Casal.findOne({
$or: [
{ p1: sender },
{ p2: sender }
]
});
if (!casal) {
return reply("Hmph! Você não está em um relacionamento.. Tanto faz pra mim, mas não inventa, tá?!");
}
await reagir(from, "💔");
await Casal.deleteOne({
_id: casal._id
});
reply("💔 Hmph! O relacionamento chegou ao fim.. Os dados foram apagados, viu?! N-não fica chorando por isso.");
}
};