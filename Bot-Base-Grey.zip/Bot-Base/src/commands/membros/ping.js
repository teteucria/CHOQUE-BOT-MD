const os = require('os');

module.exports = {
nome: ["ping"],
executar: async ({
from,
info,
totalcmds,
reagir,
selo,
TimeCount,
baileysVersion,
kira
}) => {
reagir(from, `🫦`);
const latency = Date.now() - (info.messageTimestamp * 1000);
const speed = Math.round(latency);
ds = `┏━━ׁ۫━፝֟━̷━𑁁━🔥━𑁁━፝֟━̷━ׁ۫━━╮
• *Atraso:* ${speed} 𝐦𝐢𝐥𝐢𝐬𝐬𝐞𝐠𝐮𝐧𝐝𝐨𝐬.
• *Ligado faz:* ${TimeCount(process.uptime())}
• *Onde estou:* ${os.type()}
• *Cmds:* ${totalcmds}
• *RAM Usada:* ${(os.freemem() / Math.pow(1024, 3)).toFixed(2)} / ${(os.totalmem() / Math.pow(1024, 3)).toFixed(2)} GB
• *CPU:* ${os.loadavg()[0].toFixed(2)}%
• *Node:* ${process.version}
• *Biblioteca Api:* ${baileysVersion}
࣪╰ׅ━━ׁ۫━፝֟━̷━𑁁━🔥━𑁁━፝֟━̷━ׁ۫━━╯`;
await kira.sendMessage(from, {text: ds}, {quoted: selo});
}
};