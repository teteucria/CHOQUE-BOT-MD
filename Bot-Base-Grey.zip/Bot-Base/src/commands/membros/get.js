module.exports = {
nome: ["get"],
executar: async ({
info,
reply
}) => {

reply(JSON.stringify(info, null, 3));
}
};