module.exports = {
nome: ["pergunta","openai","gpt","chatgpt","gpt-3.5","chatgpt-3.5"],
executar: async ({
GPT,
from,
mess,
q,
reagir,
reply
}) => {

try {
reagir(from, '✅');
const userId = "12345";
ABC = await GPT.handler(userId, q);
reply(`Hmph! Eu até perdi meu tempo pensando nisso pra você... toma: ${ABC.payload.response}`);
} catch {
return reply(mess.error());
}
}
};