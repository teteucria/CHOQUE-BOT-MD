module.exports = {
nome: ["aesthetic", "anjing", "blackpink", "boneka", "cecan", "cosplay", "dadu", "hekel", "justina", "kayes", "kpop", "kucing", "mobil", "montor", "notnot", "profil", "pubg", "rose", "ryujin", "wallhp", "wallml"],
executar: async ({
from,
info,
command,
reagir,
reply,
kira,
API_kira,
KEY_kira
}) => {
reagir(from, "🖼️");
try {
await kira.sendMessage(from, { image: { url: `${API_kira}/${command}?apitoken=${KEY_kira}` } }, { quoted: info });
reagir(from, "✅");
} catch (e) {
console.log(e);
reagir(from, "❌");
reply("Hmph! Não achei essa imagem... tenta de novo!");
}
}
};