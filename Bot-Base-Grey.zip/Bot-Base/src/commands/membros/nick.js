module.exports = {
nome: ["nick","gerarnick","fazernick","estilizar"],
executar: async ({
command,
fetchJson,
mess,
prefix,
q,
reply,
API_kira,
KEY_kira
}) => {

if (!q) return reply(`Hmph! Escreve um texto pra eu transformar com letras modificadas.. Eu sou boa nisso, mas preciso de um texto!\n• *Exemplo:* ${prefix + command} kira`);
try {
var ABCX = await fetchJson(`${API_kira}/gerarnick?nome=${encodeURI(q)}&apitoken=${KEY_kira}`);
let AB = `Hmph! Toma, eu caprichei! • [ Quantia: *${ABCX.dados.length}* ] - Estilos aplicados:\n–\n`;
for (i of ABCX.dados) {
AB += `${i}\n–\n`;
}
reply(AB);
} catch (error) {
console.log(error);
reply(mess.error());
}
}
};