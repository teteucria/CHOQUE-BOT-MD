module.exports = {
nome: ["toimg"],
executar: async ({
from,
getFileBuffer,
info,
isQuotedSticker,
reply,
selo,
kira
}) => {

if (!isQuotedSticker)
return reply("Hmph! Por favor, *mencione um sticker* para executar o comando.. N-não é pedir demais, tá?!");
try {
buff = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, "sticker");
await kira.sendMessage(from, {image: buff}, {quoted: selo}).catch(async (error) => {
reply("Hmph! Ocorreu um erro ao converter o sticker para imagem.. D-dessa vez não foi minha culpa, viu?!");
});
} catch (error) {
console.log(error);
}
}
};