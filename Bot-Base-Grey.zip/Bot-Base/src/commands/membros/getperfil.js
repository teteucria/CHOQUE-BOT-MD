module.exports = {
  nome: ["getperfil"],
  executar: async ({
    from,
    getBuffer,
    menc_os2,
    menc_jid2,
    quoted,
    reagir,
    reply,
    selo,
    kira
  }) => {
    try {
      reagir(from, "✅");
      const alvo = menc_os2 || menc_jid2 || "";
      if (!alvo) return reply("⚠️ Hmph! Cadê o número ou @marcação? Até eu não consigo adivinhar assim, baka!");

      let ppimgx;
      try {
        ppimgx = await kira.profilePictureUrl(alvo, "image");
      } catch (e) {
        ppimgx = null;
      };

      if (!ppimgx) return reply("⚠️ Hmph! Não consegui baixar a foto de perfil.. P-por que a foto dele tá escondida, hein?!");
      await kira.sendMessage(from, { image: { url: ppimgx }}, { quoted: selo });
    } catch (e) {
      reagir(from, "❌");
      reply("⚠️ Hmph! Erro ao coletar informações.. Não me culpa, eu tentei, viu?!");
    }
  }
};
