module.exports = {
nome: ["figuemoji"],
executar: async ({
args,
isGroup,
q,
reply,
sender,
sleep,
kira
}) => {

if(!q) return reply("Hmph! Esqueceu de colocar a quantidade de stickers, né? Tanto faz pra mim... mas tem que colocar, bobinho(a)!");
if (!Number(args[0]) || Number(q.trim()) > 10) return reply("❌️ Hmph! A quantidade acima de 10 não é permitida.. Eu sou boa nisso, sei bem o limite, baka!");
if (!isGroup) return reply("🤖♥️ Hmph! Vou enviar no pv pra não floodar o grupo.. Não é porque eu me importo com a sua figurinha, tá?!");
async function FigurinhaEmoji() {
figa = `${Math.floor(Math.random() * 99)}`;
await kira.sendMessage(sender, {sticker: {url: `https://raw.githubusercontent.com/badDevelopper/figus2/main/figemoji/${figa}.webp`}});
}
for (i = 0; i < q; i++) {
await sleep(500);
await FigurinhaEmoji();
}
}
};