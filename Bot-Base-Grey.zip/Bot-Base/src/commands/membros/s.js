module.exports = {
nome: ["s","st","stk","fstiker","fsticker","f"],
executar: async ({
DLT_FL,
author,
command,
from,
NomeDoBot,
getFileBuffer,
groupMetadata,
info,
isGroup,
packname,
prefix,
pushname,
reagir,
reply,
rgtake,
selo,
sendImageAsSticker2,
sendVideoAsSticker2,
sender,
kira
}) => {
setTimeout(() => {
reagir(from, "✨");
}, 300);
var RSM = info.message?.extendedTextMessage?.contextInfo?.quotedMessage;
var boij2 = RSM?.imageMessage || info.message?.imageMessage ||
RSM?.viewOnceMessageV2?.message?.imageMessage ||
info.message?.viewOnceMessageV2?.message?.imageMessage ||
info.message?.viewOnceMessage?.message?.imageMessage ||
RSM?.viewOnceMessage?.message?.imageMessage;
var boij = RSM?.videoMessage || info.message?.videoMessage ||
RSM?.viewOnceMessageV2?.message?.videoMessage ||
info.message?.viewOnceMessageV2?.message?.videoMessage ||
info.message?.viewOnceMessage?.message?.videoMessage ||
RSM?.viewOnceMessage?.message?.videoMessage;
const indexTake = rgtake.findIndex(i => i.usuario === sender);
let packSticker, authorSticker;
if (indexTake !== -1) {
packSticker = `${rgtake[indexTake].mcdagua1}`;
authorSticker = `${rgtake[indexTake].mcdagua2}`;
} else {
const nomeGrupo = isGroup ? groupMetadata.subject : "Conversa Privada";
packSticker = `🤖 Nome Bot: ${NomeDoBot}\n🌟 Criador: ${pushname}\n`;
authorSticker = `\n🏢 Grupo: ${nomeGrupo}\n🔗 Site: waguapis.online\nNão se acostume, viu?!`;
}
try {
if (boij2) {
owgi = await getFileBuffer(boij2, "image");
let encmediaa = await sendImageAsSticker2(kira, from, owgi, selo, {
packname: packSticker, 
author: authorSticker
});
await DLT_FL(encmediaa);
reagir(from, "✅");
} else if (boij && boij.seconds < 11) {
owgi = await getFileBuffer(boij, "video");
let encmedia = await sendVideoAsSticker2(kira, from, owgi, selo, {
packname: packSticker, 
author: authorSticker
});
await DLT_FL(encmedia);
reagir(from, "✅");
} else {
return reply(`❌ *Hmph! Erro de formato!*\n\nMarque uma imagem ou vídeo curto (máx 10s) usando o comando *${prefix + command}*.. Presta atenção no que você manda, baka!`);
}
} catch (err) {
console.log(err);
reply("⚠️ Hmph! Ocorreu um erro ao gerar sua figurinha.. Tanto faz, mas eu tentei, viu?!");
}
}
};