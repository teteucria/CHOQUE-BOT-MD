module.exports = {
nome: ["akira", "akiyama", "ana", "asuna", "ayuzawa", "boruto", "chiho", "chitoge", "cogan", "cogan2", "deidara", "doraemon", "eba", "elaina", "emilia", "erza", "gremory", "hestia", "hinata", "inori", "islamic", "isuzu", "itachi", "itori", "kaga", "kagura", "kakasih", "kaori", "kartun", "katakata", "keneki", "kotori", "kurumi", "madara", "megumin", "mikasa", "miku", "minato", "mountain", "naruto", "nekonime", "nezuko", "onepiece", "pokemon", "programming", "rize", "sagiri", "sakura", "sasuke", "shina", "shinka", "shinomiya", "shizuka", "tejina", "toukachan", "tsunade", "waifu", "wallhp2", "yotsuba", "yuki", "yumeko"],
executar: async ({
from,
info,
command,
reagir,
reply,
kira,
API_kira,
KEY_kira
}) => {
reagir(from, "🖼️");
try {
await kira.sendMessage(from, { image: { url: `${API_kira}/anime/${command}?apitoken=${KEY_kira}` } }, { quoted: info });
reagir(from, "✅");
} catch (e) {
console.log(e);
reagir(from, "❌");
reply("Hmph! Essa imagem não veio... tenta de novo, bobinho(a)!");
}
}
};