module.exports = {
nome: ["gerarlink","imgpralink","upload"],
executar: async ({
downloadMediaMessage,
from,
info,
reagir,
reply,
upload}) => {
try {
await reagir(from, "✅️");
const quotedData = JSON.parse(JSON.stringify(info).replace("quotedM", "m")).message?.extendedTextMessage?.contextInfo?.message;
let midiaObj = quotedData?.imageMessage || quotedData?.videoMessage || quotedData?.audioMessage || quotedData?.documentMessage || quotedData?.stickerMessage;
if (!midiaObj) return reply("Hmph! Não consegui identificar a mídia.. Marca direito a imagem, vídeo ou sticker, baka!");
const buffer = await downloadMediaMessage({message: { [Object.keys(quotedData)[0]]: midiaObj }}, "buffer");
const extension = midiaObj.mimetype?.split('/')[1] || 'bin';
const nomeSimulado = `file_${Date.now()}.${extension}`;
const url = await upload({ buffer, originalname: nomeSimulado });
reply(`Hmph! ᥉ᥱᥙ ᥣιᥒk ᥴ᥆ᥒ᥎ᥱrtιd᥆:\n${url}\n...n-não se acostume com isso, viu?!`);
} catch (e) {
console.log(e);
await reagir(from, '❌');
reply("Hmph! Erro ao tentar converter a mídia para link.. D-dessa vez eu te ajudo, mas não fica me enchendo, tá?!");
}
}
};