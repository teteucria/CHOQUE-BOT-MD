module.exports = {
nome: ["rename","roubar"],
executar: async ({
Buffer,
author2,
bas64,
command,
convertSticker,
encmediats,
from,
getFileBuffer,
info,
isQuotedSticker,
mess,
pack,
prefix,
q,
quoted,
reagir,
reply,
selo,
sticker,
kira
}) => {

if (!isQuotedSticker) return reply("Hmph! Marque uma figurinha primeiro.. Presta atenção, bobinho(a)!");
encmediats = await getFileBuffer(info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage, "sticker");
[pack, author2] = q.split("|");
if (!q) return reply("Hmph! Como você vai renomear a figurinha sem colocar o novo pacote e autor do sticker? Esses humanos... Só eu tenho paciência pra isso, viu?!");
if (!pack) return reply(`Hmph! Faça o certo, invés do errado, senhor(a)! Aqui está a fórmula correta de uso: *${prefix + command} pacote|autor* (e não se esqueça de responder o sticker que quer renomear, certo?).. Eu não vou repetir, viu?!`);
if (!author2) return reply(`Hmph! Faça o certo, invés do errado, senhor(a)! Aqui está a fórmula correta de uso: *${prefix + command} pacote|autor* (e não se esqueça de responder o sticker que quer renomear, certo?).. Eu não vou repetir, viu?!`);
await reagir(from, '✅');
bas64 = `data:image/jpeg;base64,${encmediats.toString("base64")}`;
var mantap = await convertSticker(bas64, pack, author2);
var sti = new Buffer.from(mantap, "base64");
await kira.sendMessage(from, {sticker: sti}, {quoted: selo}).catch(async (error) => {
reply(mess.error());
});
}
};