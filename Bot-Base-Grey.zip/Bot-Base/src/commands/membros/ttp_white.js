module.exports = {
nome: ["ttp_white","ttp_brat"],
executar: async ({
command,
from,
prefix,
q,
reagir,
reply,
selo,
kira,
API_kira,
KEY_kira
}) => {

try {
if(!q.trim()) return reply(`🎨 Hmph! Exemplo: ${prefix+command} seu texto aqui.. Coloca o texto do jeito certo, bobinho(a)!`);
reagir(from, "✅️");
const url = `${API_kira}/brat-estatico?texto=${encodeURIComponent(q)}&apitoken=${KEY_kira}`;
kira.sendMessage(from, {sticker: {url: url}}, {quoted: selo}).catch(() => reply("❌ Hmph! Erro ao gerar figurinha.. Eu tentei, viu?! Não se acostume com isso!"));
} catch (e) {
return reply("❌ Hmph! Erro ao processar a busca ou a API offline.. N-não é culpa minha, tá?!");
}
}
};