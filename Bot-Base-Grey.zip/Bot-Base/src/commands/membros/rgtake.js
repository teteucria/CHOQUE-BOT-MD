module.exports = {
nome: ["rgtake"],
executar: async ({
fs,
q,
prefix,
command,
reply,
rgtake,
rgtakergtake,
sender
}) => {

var [TP, TP2] = q.split("|");
rgtakergtake = [];
for (i of rgtake) {
rgtakergtake.push(i.usuario);
}
if (rgtakergtake.indexOf(sender) >= 0)
return reply("Hmph! Você já registrou sua marca ďagua, não é possível usar esse comando novamente.. Tanto faz, baka!");
if (!q.includes("|")) return reply(`Hmph! Você usou de forma errada, siga o exemplo: *${prefix + command} wa|bot*.. N-não é difícil, presta atenção!`);
if (!TP) return reply(`Hmph! Você esqueceu de preencher o primeiro campo... Ex: *${prefix + command} wa|bot*, baka!`);
if (!TP2) return reply(`Hmph! Você esqueceu de preencher o segundo campo... Ex: *${prefix + command} wa|bot*, bobinho(a)!`);
rgtake.push({ usuario: sender, mcdagua1: TP, mcdagua2: TP2 });
reply(`Hmph! Sucesso ao concluir o registro... Agora você pode usar o comando: *${prefix}take*.. Não se acostume, viu?!`);
}
};