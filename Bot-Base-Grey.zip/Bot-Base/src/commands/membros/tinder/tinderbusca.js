module.exports = {
nome: ["tinderbusca","tinderbuscar"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`💘 *TINDER BUSCA* 💘\n\nHmph! Buscar quem, baka?! Manda um nome...\n\n✏️ Exemplo: *${prefix + command} lucas*`);
reagir(from, "💘");
try {
const res = await fetchJson(`${API_kira}/tinder/buscar?nome=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const lista = (res.resultados || []).slice(0, 8)
.map((p, i) => `┌ *${i + 1}. ${p.nome || "Anônimo"}* 🎀 ${p.idade || "?"} anos\n├ 👤 ${p.genero || "—"}\n├ 💗 ${p.likes || 0} likes  •  💍 ${p.matches || 0} matches\n└ 🆔 ${p.id || "—"}`)
.join("\n\n");
reply(`╭─「 💘 *TINDER BUSCA* 💘 」\nHmph! Tava procurando alguém, hein?! 👀\n\n🔍 *Busca:* ${q}\n📊 *Achados:* ${res.total || "0"}\n╰────────────────\n\n${lista || "😔 Ninguém encontrado, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("💔 Hmph! A busca no Tinder falhou..."); }
}
};
