const { tinderUrl } = require("./_tinderHelpers");

module.exports = {
nome: ["consentimento"],
executar: async ({
q, axios, reply, prefix, command, sender, API_kira, KEY_kira
}) => {
const valor = (q || "").trim().toLowerCase();
if (!["sim", "s", "true", "1", "não", "nao", "n", "false", "0"].includes(valor)) return reply(`🔐 Use *${prefix + command} sim* para liberar o WhatsApp após match ou *${prefix + command} não* para remover o consentimento.`);
const ativo = ["sim", "s", "true", "1"].includes(valor);
try {
const { data } = await axios.get(tinderUrl(API_kira, KEY_kira, "/tinder/consentimento", { sender, compartilharContato: String(ativo) }), { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível atualizar o consentimento.");
reply(`${ativo ? "✅ *Consentimento ativado!* Seu contato pode ser liberado em matches futuros. 💌" : "🔒 *Consentimento removido.* Seu contato não será compartilhado. 🙅‍♀️"}\n\nO contato só é liberado se a outra pessoa também autorizar! 🤝`);
} catch (e) { console.log(e); reply(`💔 Não consegui atualizar o consentimento: ${e.message || "erro na API"}`); }
}
};
