const { tinderUrl, parseTinderRegister } = require("./_tinderHelpers");

module.exports = {
nome: ["tinderrg"],
executar: async ({
q, from, axios, reagir, reply, kira, prefix, command, sender, API_kira, KEY_kira
}) => {
if (!q || !q.includes("|")) return reply(`╭─「 💘 *CRIAR PERFIL TINDER* 」\nUse: *${prefix + command} Nome|Idade|Gênero|Preferências|Bio|sim|https://foto-opcional*\n\n✏️ *Exemplo:*\n*${prefix + command} Ana|25|mulher|todos|Música e cinema|sim*\n\n📸 _Se você não colocar o link da foto, eu tento usar sua foto de perfil do WhatsApp automaticamente. Se não conseguir, eu vou te pedir o link._\n╰────────────────`);
const registro = parseTinderRegister(q);
if (!registro.nome || !registro.bio || !registro.genero) return reply("⚠️ Informe nome, gênero e bio no formato indicado.");
if (registro.nome.length > 80 || registro.bio.length > 500) return reply("⚠️ Nome ou bio excedeu o limite permitido.");
reagir(from, "💘");

let foto = registro.foto;
if (!foto) {
try { foto = await kira.profilePictureUrl(sender, "image"); }
catch (e) { foto = "https://i.ibb.co/rR0wWMSm/942088bc-e739-4447-ac70-e1721fd2ebfa.jpg"; }
}
if (!foto) {
return reply(`📸 Hmph! Não consegui pegar sua foto de perfil do WhatsApp automaticamente (ela pode estar privada).\n\nManda de novo o comando incluindo o link da foto no final, assim:\n*${prefix + command} ${q}|https://link-da-sua-foto*`);
}

try {
const url = tinderUrl(API_kira, KEY_kira, "/tinder/registrar", {
sender, nome: registro.nome, idade: registro.idade, bio: registro.bio, genero: registro.genero,
preferences: registro.preferences, compartilharContato: registro.compartilharContato ? "true" : "false", foto
});
const { data } = await axios.get(url, { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível registrar.");
await reply(`╭─「 💘 *PERFIL ${data.criado ? "CRIADO" : "ATUALIZADO"}!* 」\n\n✨ *Nome:* ${data.perfil?.nome || registro.nome}\n🆔 *ID público:* ${data.perfil?.id || "—"}\n🔐 *Contato em match:* ${data.perfil?.contatoCompartilhado ? "✅ ativo" : "🔒 inativo"}\n╰────────────────\n\n🕵️ Seu número não aparece no perfil. Ele só é liberado depois de um match com consentimento dos dois! 💕\n\nManda *${prefix}tinderperfil* pra ver seu card bonitão 😎`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply(`💔 Não consegui registrar seu Tinder: ${e.message || "erro na API"}`); }
}
};
