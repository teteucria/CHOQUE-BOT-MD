module.exports = {
nome: ["tinderranking"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "🏆");
try {
const res = await fetchJson(`${API_kira}/tinder/ranking?apitoken=${KEY_kira}`);
const medalhas = ["🥇", "🥈", "🥉"];
const lista = (res.ranking || []).slice(0, 10)
.map((p) => `${medalhas[p.posicao - 1] || `▫️ *${p.posicao}º*`} — *${p.nome || "Anônimo"}* (${p.idade || "?"} anos)\n     💗 ${p.likes || 0} likes  •  💍 ${p.matches || 0} matches  •  🎯 ${p.score || 0} pts`)
.join("\n\n");
reply(`╭─「 🏆 *TINDER RANKING* 👑 」\nOs mais cobiçados do app! 💘\n╰────────────────\n\n${lista || "😔 Ninguém encontrado, baka!"}\n\nHmph! Você tá no ranking? Se não tá, vai lá se registrar e parar de reclamar! 😜`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("💔 Hmph! O ranking falhou..."); }
}
};
