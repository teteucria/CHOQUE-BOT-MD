const { tinderUrl, formatarTinderContatos } = require("./_tinderHelpers");

module.exports = {
nome: ["tindermeet","tindermatches","tindermeets"],
executar: async ({
axios, reply, sender, API_kira, KEY_kira
}) => {
try {
const { data } = await axios.get(tinderUrl(API_kira, KEY_kira, "/tinder/meet", { sender }), { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível consultar os matches.");
const lista = (data.matches || []).map((item, index) => {
const perfil = item.perfil || {};
return `┌ *${index + 1}. ${perfil.nome || "Anônimo"}* 💘\n├ 🆔 ${perfil.id || "—"}\n├ 📝 ${perfil.bio || "—"}\n└ 🔐 ${item.consentimentoDosDois ? "✅ contato liberado pra vocês dois" : "⏳ aguardando consentimento bilateral"}${formatarTinderContatos(item.contatos)}`;
}).join("\n\n");
reply(`╭─「 💘 *TINDER MEET* 💘 」\nSeus matches confirmados! 🎉\n╰────────────────\n\n${lista || "😔 Nenhum match encontrado ainda. Vai lá curtir alguém! 💗"}`);
} catch (e) { console.log(e); reply(`💔 Não consegui consultar seus meets: ${e.message || "erro na API"}`); }
}
};
