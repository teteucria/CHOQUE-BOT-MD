const { tinderUrl } = require("./_tinderHelpers");

module.exports = {
nome: ["tinderperfil","meutinder"],
executar: async ({
from, info, axios, reply, kira, sender, API_kira, KEY_kira
}) => {
try {
const { data } = await axios.get(tinderUrl(API_kira, KEY_kira, "/tinder/perfil", { sender }), { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Perfil não encontrado.");
const p = data.perfil || {};
const texto = `╭─「 💘 *MEU TINDER* 💘 」\n\n✨ *Nome:* ${p.nome || "—"}\n🆔 *ID:* ${p.id || "—"}\n🎂 *Idade:* ${p.idade || "—"}\n👤 *Gênero:* ${p.genero || "—"}\n❤️ *Preferências:* ${p.preferences || "—"}\n📝 *Bio:* ${p.bio || "—"}\n🔐 *Contato em match:* ${p.contatoCompartilhado ? "✅ autorizado" : "🔒 não autorizado"}\n╰────────────────`;
if (p.foto) {
const cardUrl = tinderUrl(API_kira, KEY_kira, "/canvas/tinderperfil", {
foto: p.foto, nome: p.nome || "Anônimo",
...(p.idade ? { idade: p.idade } : {}),
...(p.bio ? { bio: p.bio } : {}),
...(p.genero ? { genero: p.genero } : {}),
...(p.id ? { id: p.id } : {})
});
await kira.sendMessage(from, { image: { url: cardUrl }, caption: texto }, { quoted: info });
} else {
reply(texto);
}
} catch (e) { console.log(e); reply(`💔 Não consegui carregar seu perfil: ${e.message || "erro na API"}`); }
}
};
