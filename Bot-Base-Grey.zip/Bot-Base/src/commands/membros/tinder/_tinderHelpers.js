// Funções auxiliares compartilhadas pelos comandos de Tinder.
// Este arquivo NÃO é um comando (não possui "nome"), então o registry o ignora ao carregar.

function tinderUrl(API_kira, KEY_kira, route, params = {}) {
const query = new URLSearchParams({ ...params, apitoken: KEY_kira });
return `${API_kira}${route}?${query.toString()}`;
}

function parseTinderRegister(text = "") {
const parts = text.split("|").map((item) => item.trim());
const last = parts.at(-1) || "";
const hasPhoto = /^https:\/\//i.test(last);
const consent = hasPhoto ? parts[5] : parts.at(-1);
return {
nome: parts[0] || "",
idade: parts[1] || "",
genero: parts[2] || "",
preferences: parts[3] || "todos",
bio: parts[4] || "",
compartilharContato: /^(sim|s|true|1|yes)$/i.test(consent || ""),
foto: hasPhoto ? last : ""
};
}

function formatarTinderContatos(contatos = []) {
if (!Array.isArray(contatos) || contatos.length !== 2) return "";
return "\n\n*📱 CONTATOS LIBERADOS PELO MATCH:*\n" + contatos.map((contato) => `• ${contato.nome || "Pessoa"}: ${contato.whatsapp}\n${contato.link || ""}`).join("\n");
}

module.exports = { tinderUrl, parseTinderRegister, formatarTinderContatos };