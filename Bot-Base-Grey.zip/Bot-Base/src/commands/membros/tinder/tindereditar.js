const { tinderUrl, parseTinderRegister } = require("./_tinderHelpers");

module.exports = {
nome: ["tindereditar","editartinder","editarperfil"],
executar: async ({
q, from, axios, reagir, reply, prefix, command, sender, API_kira, KEY_kira
}) => {
if (!q || !q.includes("|")) return reply(`╭─「 ✏️ *EDITAR PERFIL TINDER* 」\nUse: *${prefix + command} Nome|Idade|Gênero|Preferências|Bio|sim|https://foto-opcional*\n\n📝 Só preencha os campos que quer alterar, deixando os outros em branco entre os \`|\`.\n✏️ *Exemplo (mudando só a bio):* *${prefix + command} |||||Nova bio aqui*\n╰────────────────`);
const editado = parseTinderRegister(q);
try {
const partes = q.trim().split("|");
const ultimaParte = partes.at(-1);
const params = {
sender,
...(editado.nome ? { nome: editado.nome } : {}),
...(editado.idade ? { idade: editado.idade } : {}),
...(editado.bio ? { bio: editado.bio } : {}),
...(editado.genero ? { genero: editado.genero } : {}),
...(editado.preferences ? { preferences: editado.preferences } : {}),
...(editado.foto ? { foto: editado.foto } : {}),
...(ultimaParte && /^(sim|s|true|1|yes|não|nao|n|false|0)$/i.test(ultimaParte) ? { compartilharContato: editado.compartilharContato ? "true" : "false" } : {})
};
const url = tinderUrl(API_kira, KEY_kira, "/tinder/editar", params);
const { data } = await axios.get(url, { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível editar o perfil.");
await reply(`╭─「 ✏️ *PERFIL ATUALIZADO!* 」\n\n✨ *Nome:* ${data.perfil?.nome || "—"}\n🆔 *ID público:* ${data.perfil?.id || "—"}\n🔐 *Contato em match:* ${data.perfil?.contatoCompartilhado ? "✅ ativo" : "🔒 inativo"}\n╰────────────────\n\nManda *${prefix}tinderperfil* pra conferir como ficou seu card! 💅`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply(`💔 Não consegui editar seu Tinder: ${e.message || "erro na API"}`); }
}
};
