const { tinderUrl, formatarTinderContatos } = require("./_tinderHelpers");

module.exports = {
nome: ["tindermatches"],
executar: async ({
axios, reply, sender, API_kira, KEY_kira
}) => {
try {
const { data } = await axios.get(tinderUrl(API_kira, KEY_kira, "/tinder/matches", { sender }), { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível consultar os matches.");
const lista = (data.matches || []).map((item) => `💘 *${item.perfil?.nome || "Anônimo"}* — ${item.consentimentoDosDois ? "✅ contato liberado" : "⏳ consentimento pendente"}${formatarTinderContatos(item.contatos)}`).join("\n\n");
reply(`╭─「 💘 *MEUS MATCHES* 💘 」\n╰────────────────\n\n${lista || "😔 Nenhum match encontrado ainda."}`);
} catch (e) { console.log(e); reply(`💔 Não consegui consultar os matches: ${e.message || "erro na API"}`); }
}
};
