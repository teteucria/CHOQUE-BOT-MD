const { tinderUrl, formatarTinderContatos } = require("./_tinderHelpers");

module.exports = {
nome: ["tinderlike","tindermeetlike"],
executar: async ({
q, from, info, axios, reagir, reply, kira, prefix, command, sender, API_kira, KEY_kira
}) => {
const idDestino = (q || "").trim();
if (!/^13-\d{4}$/.test(idDestino)) return reply(`💗 Informe o ID público do perfil. Exemplo: *${prefix + command} 13-0002*`);
reagir(from, "💗");
try {
const { data } = await axios.get(tinderUrl(API_kira, KEY_kira, "/tinder/like", { sender, idDestino }), { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível enviar o like.");

const p = data.perfil || {};
const texto = `╭─「 ${data.match ? "💘 *MATCH! DEU CERTO!*" : "💗 *LIKE ENVIADO!*"} 」\n\n✨ *Nome:* ${p.nome || "Anônimo"}\n🆔 *ID:* ${p.id || "—"}\n🎂 *Idade:* ${p.idade || "—"}\n👤 *Gênero:* ${p.genero || "—"}\n📝 *Bio:* ${p.bio || "—"}\n\n💗 *Likes:* ${p.likes ?? 0}\n💔 *Deslikes:* ${p.deslikes ?? 0}\n💍 *Matches:* ${p.matches ?? 0}\n╰────────────────\n${data.mensagem ? `\n${data.mensagem}` : ""}${formatarTinderContatos(data.contatos)}`;

if (p.foto) {
const cardUrl = tinderUrl(API_kira, KEY_kira, "/canvas/tinderperfil", {
foto: p.foto, nome: p.nome || "Anônimo",
...(p.idade ? { idade: p.idade } : {}),
...(p.bio ? { bio: p.bio } : {}),
...(p.genero ? { genero: p.genero } : {}),
...(p.id ? { id: p.id } : {})
});
await kira.sendMessage(from, { image: { url: cardUrl }, caption: texto }, { quoted: info });
} else {
reply(texto);
}
reagir(from, data.match ? "💘" : "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply(`💔 Não consegui enviar o like: ${e.message || "erro na API"}`); }
}
};
