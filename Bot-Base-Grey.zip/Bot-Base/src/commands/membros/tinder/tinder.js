const { tinderUrl } = require("./_tinderHelpers");

module.exports = {
nome: ["tinder"],
executar: async ({
from, info, axios, reagir, reply, kira, prefix, API_kira, KEY_kira, sender
}) => {
reagir(from, "🎲");
try {
const { data } = await axios.get(tinderUrl(API_kira, KEY_kira, "/tinder/aleatorio", { sender }), { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível buscar um parceiro aleatório.");

const eu = data.eu || {};
const parceiro = data.parceiro || {};
const pct = parceiro.compatibilidade ?? Math.floor(Math.random() * 26) + 70;

const texto = `╭─「 😈 *TINDER — kira* 😈 」\nHmph! Olha quem o destino escolheu pra você... 😳\n╰────────────────\n\n*👤 VOCÊ*\n✨ ${eu.nome || "Anônimo"}  •  🆔 ${eu.id || "—"}\n🎂 ${eu.idade || "—"} anos  •  ${eu.genero || "—"}\n📝 ${eu.bio || "—"}\n\n*💘 PARCEIRO(A)*\n✨ ${parceiro.nome || "Anônimo"}  •  🆔 ${parceiro.id || "—"}\n🎂 ${parceiro.idade || "—"} anos  •  ${parceiro.genero || "—"}\n📝 ${parceiro.bio || "—"}\n💗 ${parceiro.likes ?? 0} likes  •  💍 ${parceiro.matches ?? 0} matches\n\n🎯 *Compatibilidade:* ${pct}%\n\n💌 Curtiu? Manda *${prefix}tinderlike ${parceiro.id || ""}* pra dar o like nele(a)!`;

if (eu.foto && parceiro.foto) {
const cardUrl = tinderUrl(API_kira, KEY_kira, "/canvas/tindermatch", {
foto1: eu.foto, nome1: eu.nome || "Você", foto2: parceiro.foto, nome2: parceiro.nome || "Anônimo",
porcentagem: pct, titulo: "🎲 SORTEIO TINDER"
});
await kira.sendMessage(from, { image: { url: cardUrl }, caption: texto }, { quoted: info });
} else {
reply(texto);
}
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply(`💔 Não consegui sortear um parceiro: ${e.message || "erro na API"}`); }
}
};
