const { tinderUrl } = require("./_tinderHelpers");

module.exports = {
nome: ["tinderdeslike","tinderpassar"],
executar: async ({
q, axios, reply, prefix, command, sender, API_kira, KEY_kira
}) => {
const idDestino = (q || "").trim();
if (!/^13-\d{4}$/.test(idDestino)) return reply(`👋 Informe o ID público do perfil. Exemplo: *${prefix + command} 13-0002*`);
try {
const { data } = await axios.get(tinderUrl(API_kira, KEY_kira, "/tinder/deslike", { sender, idDestino }), { timeout: 30000 });
if (data.erro) throw new Error(data.mensagem || "Não foi possível recusar o perfil.");
reply(`👋 *PERFIL RECUSADO*\n\n${data.mensagem || "Perfil recusado."} 🙅‍♀️`);
} catch (e) { console.log(e); reply(`💔 Não consegui recusar o perfil: ${e.message || "erro na API"}`); }
}
};
