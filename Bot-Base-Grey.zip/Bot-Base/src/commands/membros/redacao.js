module.exports = {
nome: ["redacao"],
executar: async ({
fetchJson,
from,
mess,
q,
reply,
selo,
kira
}) => {

if (!q) return reply(`Hmph! Você esqueceu de colocar o tema da sua redação ao lado do comando.. Como eu vou escrever pra você assim? Baka!`);
try {
let { key } = await kira.sendMessage(from, {text: `Hmph! Aguarda aí que eu estou processando sua solicitação.. Isso pode levar alguns segundos.. N-não fica impaciente, viu?!`}, {quoted: selo});
promptUser = `Crie um texto dissertativo-argumentativo com o tema: ${q}`;
anu1 = await fetchJson(`https://aemt.me/gpt4?text=${promptUser}`);
await kira.sendMessage(from, {text: mess.respostaRedacao(anu1), edit: key});
} catch (error) {
return reply(mess.error());
}
}
};