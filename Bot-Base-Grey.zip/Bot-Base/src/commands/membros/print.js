module.exports = {
nome: ["print","printsite"],
executar: async ({
command,
from,
prefix,
q,
quoted,
reagir,
reply,
selo,
kira,
API_kira,
KEY_kira
}) => {

if(!q.trim()) return reply(`Hmph! Faltou a url do site que você quer tirar print.. Exemplo: ${prefix+command} https://google.com\n\nNão esqueça do https se o site tiver, ou http se não for um site com ssl.. Presta atenção, bobinho(a)!`)
reagir(from, "✅️");
try {
kira.sendMessage(from, {image: {url: `${API_kira}/screenshot?url=${q.trim()}&apitoken=${KEY_kira}`}}, {quoted: selo});
} catch {
reagir(from, "❌️");
}
}
};