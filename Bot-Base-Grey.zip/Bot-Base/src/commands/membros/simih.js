module.exports = {
nome: ["simih"],
executar: async ({
args,
command,
dataGp,
isGroupAdmins,
isSimi,
mess,
prefix,
reply,
setGp
}) => {

if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (args.length < 1) return reply(`Hmph! Use 1 pra ativar ou 0 pra desativar.. Caso deseje ativar, use essa forma: ${prefix + command} 1, caso seja desativar é só trocar o 1 pelo 0. Até eu sei, baka!`);
if (Number(args[0]) === 1) {
if (isSimi) return reply("Hmph! O modo simih já se encontra ativo neste grupo.. Tanto faz, mas presta atenção, bobinho(a)!");
dataGp[0].simi1 = true;
setGp(dataGp);
reply("Hmph! Ativado com sucesso o modo simi neste grupo.. Eu que fiz, então agradece, viu?!");
} else if (Number(args[0]) === 0) {
if (!isSimi) return reply("Hmph! O modo simih já se encontra desativado neste grupo.. Já estava assim, baka!");
dataGp[0].simi1 = false;
setGp(dataGp);
reply("Hmph! Desativando o modo simi com sucesso neste grupo..️ Não se acostume com isso, tá?!");
} else {
reply("Hmph! 1 ᴘᴀʀᴀ ᴀᴛɪᴠᴀʀ, 0 ᴘᴀʀᴀ ᴅᴇsᴀᴛɪᴠᴀʀ.. Dá pra entender, né? Baka!");
}
}
};