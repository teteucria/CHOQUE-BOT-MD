const FILMES = [
  { nome: "Matrix", ano: 1999, genero: "Ficção científica", sinopse: "Um programador descobre que a realidade em que vive é uma simulação e passa a lutar contra as máquinas que controlam a humanidade." },
  { nome: "O Poderoso Chefão", ano: 1972, genero: "Drama/Crime", sinopse: "A história de uma família de máfia ítalo-americana e a disputa pelo controle do seu império criminoso." },
  { nome: "Interestelar", ano: 2014, genero: "Ficção científica", sinopse: "Um grupo de astronautas viaja através de um buraco de minhoca em busca de um novo planeta habitável para salvar a humanidade." },
  { nome: "Coringa", ano: 2019, genero: "Drama", sinopse: "Um comediante fracassado de Gotham mergulha na loucura e no caos, dando origem a um dos vilões mais icônicos dos quadrinhos." },
  { nome: "Vingadores: Ultimato", ano: 2019, genero: "Ação/Super-herói", sinopse: "Os heróis remanescentes se unem numa última tentativa de reverter a destruição causada por Thanos." },
  { nome: "Cidade de Deus", ano: 2002, genero: "Drama/Crime", sinopse: "Retrata o crescimento da violência numa favela carioca através dos olhos de um jovem que sonha em ser fotógrafo." },
  { nome: "A Origem", ano: 2010, genero: "Ficção científica", sinopse: "Um ladrão especializado em roubar segredos dentro dos sonhos das pessoas recebe a missão inversa: plantar uma ideia." },
  { nome: "Parasita", ano: 2019, genero: "Drama/Suspense", sinopse: "Uma família pobre se infiltra na vida de uma família rica, revelando as tensões e desigualdades entre as classes sociais." },
  { nome: "O Silêncio dos Inocentes", ano: 1991, genero: "Suspense/Terror", sinopse: "Uma agente do FBI busca a ajuda de um brilhante assassino canibal para capturar outro serial killer em atividade." },
  { nome: "Titanic", ano: 1997, genero: "Romance/Drama", sinopse: "Um romance proibido nasce entre passageiros de classes sociais diferentes durante a trágica viagem do Titanic." },
  { nome: "Whiplash", ano: 2014, genero: "Drama", sinopse: "Um jovem baterista busca a perfeição sob a orientação implacável de um professor obcecado por excelência." },
  { nome: "Duna", ano: 2021, genero: "Ficção científica", sinopse: "O herdeiro de uma casa nobre precisa sobreviver às intrigas políticas e aos perigos de um planeta desértico riquíssimo em recursos." },
  { nome: "Se Beber, Não Case!", ano: 2009, genero: "Comédia", sinopse: "Três amigos acordam sem memória após uma despedida de solteiro em Las Vegas e precisam encontrar o noivo desaparecido." },
  { nome: "Divertida Mente", ano: 2015, genero: "Animação", sinopse: "As emoções dentro da mente de uma garota precisam se reorganizar quando sua família muda de cidade." },
  { nome: "John Wick", ano: 2014, genero: "Ação", sinopse: "Um ex-assassino de aluguel sai da aposentadoria para se vingar dos criminosos que mexeram com o que ele mais amava." },
  { nome: "Clube da Luta", ano: 1999, genero: "Drama", sinopse: "Um homem insone forma um clube de lutas clandestino que rapidamente se transforma em algo muito maior e mais perigoso." },
  { nome: "Náufrago", ano: 2000, genero: "Drama/Aventura", sinopse: "Um executivo sobrevive a uma queda de avião e precisa aprender a sobreviver sozinho em uma ilha deserta por anos." },
  { nome: "Get Out: Fuja!", ano: 2017, genero: "Terror/Suspense", sinopse: "Um rapaz visita a família da namorada pela primeira vez e descobre segredos perturbadores escondidos por trás da hospitalidade." },
  { nome: "Toy Story", ano: 1995, genero: "Animação", sinopse: "Os brinquedos de um garoto ganham vida quando ninguém está olhando, e um novo brinquedo ameaça a amizade entre eles." },
  { nome: "Que Horas Ela Volta?", ano: 2015, genero: "Drama", sinopse: "Uma empregada doméstica vê sua relação com a família patroa mudar quando a filha vai morar com ela na cidade grande." },
  { nome: "Homem-Aranha: Através do Aranhaverso", ano: 2023, genero: "Animação/Ação", sinopse: "Miles Morales viaja entre universos paralelos e encontra outros Homens-Aranha, enquanto enfrenta decisões que podem mudar seu destino." },
  { nome: "A Forma da Água", ano: 2017, genero: "Drama/Fantasia", sinopse: "Uma faxineira muda desenvolve uma conexão profunda com uma misteriosa criatura aquática mantida presa em um laboratório secreto." },
  { nome: "Cisne Negro", ano: 2010, genero: "Drama/Suspense", sinopse: "Uma bailarina obcecada pela perfeição começa a perder o controle sobre a realidade enquanto se prepara para o papel principal." },
  { nome: "Os Incríveis", ano: 2004, genero: "Animação/Ação", sinopse: "Uma família de super-heróis aposentados precisa voltar à ativa para enfrentar uma nova ameaça." },
  { nome: "Karatê Kid", ano: 1984, genero: "Drama/Ação", sinopse: "Um adolescente aprende artes marciais e lições de vida com um mestre para enfrentar seus valentões." }
];

module.exports = {
  nome: ["filme", "filmealeatorio", "sugerirfilme"],
  executar: async ({ kira, from, prefix, selo }) => {
    const filme = FILMES[Math.floor(Math.random() * FILMES.length)];

    const texto =
      `🎬 *${filme.nome}* (${filme.ano})\n` +
      `🎭 Gênero: ${filme.genero}\n\n` +
      `📖 Sinopse: ${filme.sinopse}`;

    await kira.sendMessage(from, {
      interactiveMessage: {
        title: texto,
        footer: "kira SYSTEM • filmes aleatórios",
        buttons: [{
          name: "quick_reply",
          buttonParamsJson: JSON.stringify({
            display_text: "🎲 Próximo filme",
            id: `${prefix}filme`
          })
        }]
      }
    }, { quoted: selo });
  }
};
