// Jogo da velha (tic-tac-toe) - você (❌) contra a kira (⭕)
const jogos = new Map(); // key: from+"_"+sender -> { board: [...], acabou: bool }

const LINHAS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6]
];

function checarVencedor(board) {
  for (const [a, b, c] of LINHAS) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  if (board.every((c) => c !== null)) return "empate";
  return null;
}

function jogadaBot(board) {
  // 1) tenta vencer
  for (let i = 0; i < 9; i++) {
    if (board[i] === null) {
      board[i] = "O";
      if (checarVencedor(board) === "O") { board[i] = null; return i; }
      board[i] = null;
    }
  }
  // 2) tenta bloquear o jogador
  for (let i = 0; i < 9; i++) {
    if (board[i] === null) {
      board[i] = "X";
      if (checarVencedor(board) === "X") { board[i] = null; return i; }
      board[i] = null;
    }
  }
  // 3) centro, depois cantos, depois qualquer
  if (board[4] === null) return 4;
  const cantos = [0, 2, 6, 8].filter((i) => board[i] === null);
  if (cantos.length) return cantos[Math.floor(Math.random() * cantos.length)];
  const livres = board.map((v, i) => (v === null ? i : null)).filter((v) => v !== null);
  return livres[Math.floor(Math.random() * livres.length)];
}

function desenharBoard(board) {
  const simbolo = (v, i) => (v === "X" ? "❌" : v === "O" ? "⭕" : `${i + 1}️⃣`);
  let s = "";
  for (let i = 0; i < 9; i += 3) {
    s += `${simbolo(board[i], i)} ${simbolo(board[i + 1], i + 1)} ${simbolo(board[i + 2], i + 2)}\n`;
  }
  return s;
}

function montarBotoes(board, prefix) {
  const livres = board.map((v, i) => (v === null ? i : null)).filter((v) => v !== null);
  return {
    name: "single_select",
    buttonParamsJson: JSON.stringify({
      title: "🎮 ESCOLHER POSIÇÃO",
      sections: [{
        title: "Casas livres",
        rows: livres.map((i) => ({
          title: `Posição ${i + 1}`,
          description: "jogar aqui",
          id: `${prefix}velha ${i + 1}`,
          disabled: false
        }))
      }]
    })
  };
}

module.exports = {
  nome: ["velha", "jogodavelha", "tictactoe"],
  executar: async ({ kira, from, sender, args, prefix, reply, selo }) => {
    const key = `${from}_${sender}`;

    if (args[0]?.toLowerCase() === "sair") {
      jogos.delete(key);
      return reply("Hmph! Encerrei o jogo... Foge assim que tá perdendo, bobinho(a)?!");
    }

    let jogo = jogos.get(key);

    // sem jogo ativo e sem número -> começa um novo
    if (!jogo && !args[0]) {
      jogo = { board: Array(9).fill(null) };
      jogos.set(key, jogo);
      return kira.sendMessage(from, {
        interactiveMessage: {
          title: `🎮 *JOGO DA VELHA*\nVocê é ❌, eu sou ⭕. Escolha uma posição!\n\n${desenharBoard(jogo.board)}`,
          footer: "kira SYSTEM",
          buttons: [montarBotoes(jogo.board, prefix)]
        }
      }, { quoted: selo });
    }

    if (!jogo) {
      return reply(`Hmph! Não tem jogo rolando... Manda ${prefix}velha pra começar um, baka!`);
    }

    const pos = parseInt(args[0], 10) - 1;
    if (isNaN(pos) || pos < 0 || pos > 8 || jogo.board[pos] !== null) {
      return reply("Hmph! Posição inválida ou já ocupada... Presta atenção, bobinho(a)!");
    }

    jogo.board[pos] = "X";
    let resultado = checarVencedor(jogo.board);

    if (!resultado) {
      const posBot = jogadaBot(jogo.board);
      jogo.board[posBot] = "O";
      resultado = checarVencedor(jogo.board);
    }

    if (resultado) {
      jogos.delete(key);
      const textoFinal =
        resultado === "X" ? "Hmph! V-você ganhou dessa vez... Não pense que vou facilitar de novo!" :
        resultado === "O" ? "Hmph! ⭕ Eu venci! Eu sou imbatível, viu bem?!" :
        "Hmph! Empatou... Nem eu, nem você. Que sem graça!";
      return reply(`${desenharBoard(jogo.board)}\n${textoFinal}`);
    }

    return kira.sendMessage(from, {
      interactiveMessage: {
        title: `🎮 *JOGO DA VELHA*\n\n${desenharBoard(jogo.board)}`,
        footer: "kira SYSTEM",
        buttons: [montarBotoes(jogo.board, prefix)]
      }
    }, { quoted: selo });
  }
};
