module.exports = {
nome: ["mediafire"],
executar: async ({
fetchJson,
from,
mess,
q,
reply,
kira,
API_kira,
KEY_kira
}) => {

try {
if (!q.includes("mediafire.com")) return reply("Hmph! E o link do Mediafire, cade? Sem ele eu não baixo nada... P-por favor, não me obrigue a pedir, bobinho(a)!");
let nex = await fetchJson(`${API_kira}/mediadl?url=${q}&apitoken=${KEY_kira}`);
reply(`Hmph! Pode esperar aí... tô enviando, mas é porque eu sou boa nisso, tá?\n\n*Arquivo:* ${nex.dados.filename}\n*Peso:* ${nex.dados.size}`);
await kira.sendMessage(from, {document: {url: nex.dados.url},
mimetype: "application/" + nex.dados.filetype,
fileName: nex.dados.filename});
} catch (error) {
console.log(error);
return reply(mess.error());
}
}
};