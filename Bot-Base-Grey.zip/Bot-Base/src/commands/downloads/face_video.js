module.exports = {
nome: ["face_video"],
executar: async ({
from,
mess,
q,
reagir,
reply,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

try {
if (!q.includes("facebook") && !q.includes("fb.watch")) return reply(`Hmph! Você esqueceu o link do Facebook de novo, né? Exemplo: *${prefix + command} o link do Facebook*. Não me faça repetir, baka!`);
reagir(from, '✅');
kira.sendMessage(from, {video: {url: `${API_kira}/face-video?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"});
} catch (e) {
return reply(mess.error());
}
}
};