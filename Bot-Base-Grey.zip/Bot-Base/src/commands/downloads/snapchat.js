module.exports = {
nome: ["sndl","snapchat"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q || !q.includes("snapchat.com")) return reply(`Hmph! Manda o LINK do Snapchat... Exemplo: *${prefix + command} https://www.snapchat.com/p/xxxx*`);
reagir(from, "👻");
try {
const res = await fetchJson(`${API_kira}/dl/snapchat?url=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const r = res.resultado?.result || res.resultado || [];
const m = Array.isArray(r) ? r[0] : r;
if (m?.url || m?.download || m?.video) {
await kira.sendMessage(from, { video: { url: m.url || m.download || m.video }, mimetype: "video/mp4", caption: "Hmph! Seu snap em vídeo, tá aí... 👻" }, { quoted: info });
} else {
reply("Hmph! Não consegui baixar esse snap... o link tá certo?");
}
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! O download do snap falhou..."); }
}
};
