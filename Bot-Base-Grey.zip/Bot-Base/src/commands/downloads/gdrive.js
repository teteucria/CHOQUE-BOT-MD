module.exports = {
nome: ["gdrive"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q || !q.includes("http")) return reply(`Hmph! Link do Google Drive, por favor... Exemplo: *${prefix + command} https://drive.google.com/file/d/xxxx*`);
reagir(from, "📁");
try {
const res = await fetchJson(`${API_kira}/gdrive?url=${q}&apitoken=${KEY_kira}`);
const r = res.resultado || res;
await kira.sendMessage(from, { document: { url: r.url || r.link }, mimetype: r.mimetype || "application/octet-stream", fileName: r.nome || r.filename || "arquivo" }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! O Drive não colaborou... o arquivo tá público?"); }
}
};
