module.exports = {
nome: ["facebook","fb"],
executar: async ({
q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q || !q.includes("http")) return reply(`Hmph! Manda o link do Facebook... Exemplo: *${prefix + command} https://fb.watch/xxxx*`);
reagir(from, "📘");
try {
await kira.sendMessage(from, { video: { url: `${API_kira}/face-video?url=${q}&apitoken=${KEY_kira}` }, mimetype: "video/mp4", caption: "Hmph! Vídeo do Face baixado... eu sou eficiente demais mesmo." }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não consegui baixar esse aí..."); }
}
};
