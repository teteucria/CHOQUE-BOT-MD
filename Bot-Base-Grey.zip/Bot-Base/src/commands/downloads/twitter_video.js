module.exports = {
nome: ["twitter_video","twtdl","twitter"],
executar: async ({
from,
mess,
q,
reagir,
reply,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

try {
if (!q.includes("twitter"))
return reply(`Hmph! Exemplo: *${prefix + command} o link do Twitter*. Até eu, que sou boa nisso, preciso do link direito, viu?!`);
reagir(from, '✅');
kira.sendMessage(from, {video: {url: `${API_kira}/twt-video?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"});
} catch (e) {
return reply(mess.error());
}
}
};