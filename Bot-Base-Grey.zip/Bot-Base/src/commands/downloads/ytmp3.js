module.exports = {
nome: ["ytmp3", "baixar_audio"],
executar: async ({
kira,
from,
reagir,
reply,
API_kira,
KEY_kira,
selo,
  prefix,
  command,
q}) => {

if (!q) return reply(`❌ Hmph! Você não digitou nada.. Exemplo: *${prefix + command} link da música*. N-não me faça ter que repetir, baka!`);
reagir(from, '💽');
try {
await kira.sendMessage(from, {audio: {url: `${API_kira}/youtube-audio?url=${q}&apitoken=${KEY_kira}`}, mimetype: "audio/mpeg"}, {quoted: selo}).catch(async (error) => {
await kira.sendMessage(from, {audio: {url: `${API_kira}/youtube-audio2?url=${q}&apitoken=${KEY_kira}`}, mimetype: "audio/mpeg"}, {quoted: selo});
});
} catch (error) {
reagir(from, '❌');
return reply(mess.error());
}
}
};