module.exports = {
nome: ["pinvideo", "pinmp4"],
executar: async ({
q, from, info, reagir, reply, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q || !q.includes("http")) return reply(`Hmph! Manda o link do Pinterest... Exemplo: *${prefix + command} https://pin.it/xxxx*`);
reagir(from, "📌");
try {
await kira.sendMessage(from, { video: { url: `${API_kira}/pin-video?url=${q}&apitoken=${KEY_kira}` }, mimetype: "video/mp4", caption: "Hmph! Seu pin em vídeo, tá aí." }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Esse pin não quis vir..."); }
}
};
