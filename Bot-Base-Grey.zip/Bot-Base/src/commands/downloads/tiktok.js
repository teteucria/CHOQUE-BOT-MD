module.exports = {
nome: ["tiktok","tiktok_video"],
executar: async ({
from,
mess,
q,
reagir,
reply,
selo,
kira,
API_kira,
KEY_kira
}) => {

try {
if (!q) return reply(`Hmph! Informa o link do TikTok, bobinho(a)... N-não é como se eu fosse adivinhar, viu?!`);
reagir(from, '✅');
await kira.sendMessage(from, {video: {url: `${API_kira}/tiktok-video?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"}, {quoted: selo});
} catch (error) {
console.log(error);
return reply(mess.error());
}
}
};