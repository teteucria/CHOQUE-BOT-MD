module.exports = {
nome: ["ytmp4", "baixar_video"],
executar: async ({
kira,
from,
reagir,
reply,
API_kira,
KEY_kira,
selo,
  prefix,
  command,
q}) => {

if (!q) return reply(`❌ Hmph! Você não digitou nada.. Exemplo: *${prefix + command} link da música*. N-não me faça ter que repetir, baka!`);
reagir(from, '💽');
try {
await kira.sendMessage(from, {video: {url: `${API_kira}/youtube-video?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"}, {quoted: selo}).catch(async (error) => {
await kira.sendMessage(from, {video: {url: `${API_kira}/youtube-video2?url=${q}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"}, {quoted: selo});
});
} catch (error) {
reagir(from, '❌');
return reply(mess.error());
}
}
};