module.exports = {
nome: ["play"],
executar: async ({
kira,
from,
reagir,
reply,
API_kira,
KEY_kira,
selo,
q,
CACHE_TTL,
fetchJson,
mess}) => {

if (!q) return reply("Hmph! Digite o nome da música.. N-não é porque eu me importo, é porque preciso saber o que baixar, baka!");
reagir(from, "✅");
try {
const resu = await fetchJson(`${API_kira}/yt-search?titulo=${q}&apitoken=${KEY_kira}`);
let TextoPlay = resu.resultado.title;
let PlayLimitado = TextoPlay.toLowerCase().slice(0, 20) + '..';
var bla = `\n> *lıl.ılı.lıl.ıl『 PLAY AUDIO 』lıl.ılı.lıl.ıl*
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> *Hmph! Eu sou a melhor, então achei isso pra você... só não se acostume com essa atenção, baka!*
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> *✞ Título:* ${PlayLimitado}
> *✞ Canal:* ${resu.resultado?.author.name}
> *✞ Postado:* ${resu.resultado.ago || "indisponivel"}
> *✞ Views:* ${resu.resultado?.views}
> *✞ Formato:* MP3
> *✞ Descrição:* ${resu.resultado?.description || "não encontrado."}
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> ▶︎ •၊၊||၊|။||||။။||။။|||။• ${resu.resultado?.duration?.timestamp || "indisponivel."}`;
kira.sendMessage(from, {image: {url: `${API_kira}/canvas/musicard4?logo=${resu.resultado.thumbnail}&titulo=${PlayLimitado}&canal=${resu.resultado?.author?.name}&duracao=${resu.resultado?.duration?.timestamp}&apitoken=${KEY_kira}`}, caption: bla}, {quoted: selo});

const audioProviders = [
`${API_kira}/youtube-audio?url=${resu.resultado.url}&apitoken=${KEY_kira}`,
`${API_kira}/youtube-audio2?url=${resu.resultado.url}&apitoken=${KEY_kira}`,
`${API_kira}/youtube-audio3?url=${resu.resultado.url}&qualidade=92&apitoken=${KEY_kira}`,
];

let sent = false;
for (const providerUrl of audioProviders) {
try {
await kira.sendMessage(from, {audio: {url: providerUrl}, mimetype: "audio/mpeg"}, {quoted: selo});
sent = true;
break;
} catch (err) {
console.log(`Provedor de áudio falhou (${providerUrl.split("?")[0]}):`, err?.message || err);
}
}

if (!sent) {
reagir(from, "❌");
return reply("Hmph! Todos os provedores de áudio falharam agora... a API deve estar instável, tenta de novo daqui a pouco, baka!");
}
} catch (e) {
reagir(from, "❌");
console.log(e);
return reply(mess?.error?.() || "Hmph! Deu erro ao buscar essa música... tenta de novo, baka!");
}
}
};