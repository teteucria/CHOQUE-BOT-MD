module.exports = {
nome: ["playvid", "playvideo"],
executar: async ({
kira,
from,
reagir,
reply,
API_kira,
KEY_kira,
selo,
q,
CACHE_TTL,
fetchJson}) => {

if (!q) return reply("Hmph! Digite o nome da música.. N-não é porque eu me importo, é porque preciso saber o que baixar, baka!");
reagir(from, "✅");
try {
const resu = await fetchJson(`${API_kira}/yt-search?titulo=${q}&apitoken=${KEY_kira}`);
let TextoPlay = resu.resultado.title;
let PlayLimitado = TextoPlay.toLowerCase().slice(0, 20) + '..';
var bla = `\n> *lıl.ılı.lıl.ıl『 PLAY VIDEO 』lıl.ılı.lıl.ıl*
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> *Hmph! Eu sou a melhor, então achei isso pra você... só não se acostume com essa atenção, baka!*
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> *✞ Título:* ${PlayLimitado}
> *✞ Canal:* ${resu.resultado?.author.name}
> *✞ Postado:* ${resu.resultado.ago || "indisponivel"}
> *✞ Views:* ${resu.resultado?.views}
> *✞ Formato:* MP3
> *✞ Descrição:* ${resu.resultado?.description || "não encontrado."}
> ▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨▨
> ▶︎ •၊၊||၊|။||||။။||။။|||။• ${resu.resultado?.duration?.timestamp || "indisponivel."}`;
kira.sendMessage(from, {image: {url: `${API_kira}/canvas/musicard4?logo=${resu.resultado.thumbnail}&titulo=${PlayLimitado}&canal=${resu.resultado?.author?.name}&duracao=${resu.resultado?.duration?.timestamp}&apitoken=${KEY_kira}`}, caption: bla}, {quoted: selo});
await kira.sendMessage(from, {video: {url: `${API_kira}/youtube-video?url=${resu.resultado.url}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"}, {quoted: selo}).catch(async (error) => {
await kira.sendMessage(from, {video: {url: `${API_kira}/youtube-video2?url=${resu.resultado.url}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"}, {quoted: selo});
});
} catch (e) {
reagir(from, "❌");
console.log(e);
return reply(mess.error());
}
}
};