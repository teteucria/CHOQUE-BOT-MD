module.exports = {
nome: ["instagram"],
executar: async ({
from,
mimetype,
q,
reagir,
reply,
selo,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

if (q.length < 5) return reply(`Hmph! Que link curto é esse? Exemplo: *${prefix + command} o link*. Presta atenção, baka!`);
reagir(from, '✅');
kira.sendMessage(from, {video: {url: `${API_kira}/insta-video?url=${url}&apitoken=${KEY_kira}`}, mimetype: "video/mp4"}, {quoted: selo}).catch((e) => {
return reply("Hmph! Deu erro... tenta de novo, tá? N-não é como se eu fosse desistir de você tão fácil, baka!");
});
}
};