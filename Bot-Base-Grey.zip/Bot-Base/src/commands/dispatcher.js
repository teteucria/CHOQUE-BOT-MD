const registry = require("./registry");
const { similarityCmd } = require("../utils/helpers");

async function handleCommand(ctx) {
  if (!ctx.isCmd) return false;

  const cmd = registry.get(ctx.command);
  if (!cmd) return false;

  // Permission checks
  if (cmd.ownerOnly && !ctx.SoDono) {
    await ctx.reply(ctx.mess?.onlyOwner?.() || "Hmph! Só o meu dono pode usar este comando... N-não fica chateado, são as regras!");
    return true;
  }

  if (cmd.groupOnly && !ctx.isGroup) {
    await ctx.reply(ctx.mess?.onlyGroup?.() || "Hmph! Esse comando só funciona em grupos... N-não é porque eu quero sua companhia, tá?!");
    return true;
  }

  if (cmd.adminOnly && !ctx.isGroupAdmins && !ctx.SoDono) {
    await ctx.reply(ctx.mess?.onlyAdmins?.() || "Hmph! Só administradores podem usar este comando... Você ainda não tem esse poder, bobinho(a)!");
    return true;
  }

  if (cmd.botAdminOnly && !ctx.isBotGroupAdmins) {
    await ctx.reply(ctx.mess?.onlyBotAdmin?.() || "Hmph! Preciso ser administradora pra executar este comando... Me promove logo, idiota!");
    return true;
  }

  try {
    if (typeof cmd.execute === "function") {
      await cmd.execute(ctx);
    } else if (typeof cmd.executar === "function") {
      await cmd.executar(ctx);
    }
    return true;
  } catch (err) {
    console.error(`[CommandDispatcher] Error executing ${cmd.name}:`, err);
    await ctx.reply(ctx.mess?.error?.() || "Hmph! Ocorreu um erro ao executar o comando... N-não fica bravo, tenta de novo, tá?!");
    return true;
  }
}

function suggestCommand(command, prefix, comandos, similarityCmd, reagir, from, kira, selo) {
  const result = similarityCmd(command);
  const suggestion = result[0];
  const msg = `┏━━ׁ۫━፝֟━̷━𑁁━🔥━𑁁━፝֟━̷━ׁ۫━━╮
   🫦 *Cmd Não existe* 🫦
 🖤 *Cmd:* ${prefix}${command}
 🤍 *Sugiro:* ${suggestion.comando}
 🖤 *Chances:* ${suggestion.porcentagem}%
࣪╰ׅ━━ׁ۫━፝֟━̷━𑁁━🔥━𑁁━፝֟━̷━ׁ۫━━╯`;

  reagir(from, "🫦");
  kira.sendMessage(from, { text: msg }, { quoted: selo });
}

module.exports = { handleCommand, suggestCommand };