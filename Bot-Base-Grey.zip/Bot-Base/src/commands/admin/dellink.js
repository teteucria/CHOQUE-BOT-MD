module.exports = {
nome: ["dellink"],
executar: async ({
SoDono,
from,
mess,
pathAntiLink,
q,
readJSON,
reagir,
reply,
saveJSON
}) => {

{
if (!SoDono) return reply(mess.onlyOwner());
if (!q) return reply("Hmph! Digite o domínio do link... Eu não adivinho, baka!");
reagir(from, "✅");
const data = readJSON(pathAntiLink, { links: [] });
data.links = data.links.filter(l => l !== q);
saveJSON(pathAntiLink, data);
reply(`🗑️ Hmph! Link *${q}* removido da lista... Prontinho, mas não se acostume com isso, viu?!`);
}
}
};