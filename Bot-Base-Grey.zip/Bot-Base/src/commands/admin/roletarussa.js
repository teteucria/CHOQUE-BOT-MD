module.exports = {
nome: ["roletarussa"],
executar: async ({
SoDono,
botNumber,
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mentions,
mess,
reply,
sender,
somembros,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
TAMBOR = [
"na perna.",
"na cabeça.",
"no pescoço.",
"no peito.",
"no olho.",
"no estômago.",
"na boca.",
"na perna.",
"na testa.",
"no braço.",
];
C2 = somembros[Math.floor(Math.random() * somembros.length)];
if (somembros.length == 0)
return reply(
"Hmph! Não existe *membros comuns* no grupo, somente admins... Tanto faz, bobinho(a)! Eu nem precisava avisar, mas avisei!"
);
if (C2 === sender || C2 === botNumber)
return mentions(
`Hmph! Escolhi *@${C2.split("@")[0]}*, mas conseguiu escapar... Sorte de bobinho, tá?!`,
[C2],
true
);
if (C2 === sender || C2 === SoDono)
return mentions(`Hmph! Escolhi *@${C2.split("@")[0]}*, mas conseguiu escapar... Sorte de bobinho(a), viu?!`, [C2], true);
reply(`Hmph! A escolha é minha! 1 membro irá morrer, que os jogos comecem... Não venha reclamar depois, baka!`);
setTimeout(async () => {
await mentions(`Hmph! Que pena... você não sobreviveu ao meu jogo *@${C2.split("@")[0]}*, hora de enterrar o cadáver, infelizmente morreu com tiro ${TAMBOR[Math.floor(Math.random() * TAMBOR.length)]}... Não era para ser assim, viu?! Eu não queria, tá?!`, [C2], true);
}, 5000);
setTimeout(async () => {
await kira.groupParticipantsUpdate(from, [C2], "remove");
}, 6000);
}
};