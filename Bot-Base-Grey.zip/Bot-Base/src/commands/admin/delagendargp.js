module.exports = {
nome: ["delagendargp","cancelaragendargp","apagaragendamento"],
executar: async ({
SoDono,
from,
g,
getFecharAbrir,
isGroup,
isGroupAdmins,
mess,
reagir,
reply,
saveFecharAbrir
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
reagir(from, "✅️");
let agendados = getFecharAbrir();
const antes = agendados.length;
agendados = agendados.filter(g => g.grupo !== from);
if (antes === agendados.length) {
return reply("❌ Hmph! Nenhum agendamento encontrado neste grupo... Você nem agendou nada, bobinho(a)! Tanto faz!");
}
saveFecharAbrir(agendados);
reply("✅ Hmph! Agendamento cancelado com sucesso... Prontinho, fiz o que você pediu. Mas não se acostume, viu?!");
}
}
};