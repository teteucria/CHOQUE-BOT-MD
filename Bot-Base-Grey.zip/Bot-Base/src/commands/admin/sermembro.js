module.exports = {
nome: ["sermembro"],
executar: async ({
SoDono,
from,
isBotGroupAdmins,
mentions,
mess,
reply,
sender,
kira
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
await mentions(
`@${sender.split("@")[0]} Hmph! Pronto - Agora você é um membro comum novamente.. Não fica achando que eu fiz isso por você, tá?! Só fiz porque quis!`,
[sender],
true
);
await kira.groupParticipantsUpdate(from, [sender], "demote");
}
};