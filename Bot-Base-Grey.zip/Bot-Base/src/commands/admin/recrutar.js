module.exports = {
nome: ["recrutar"],
executar: async ({
from,
getBuffer,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mess,
q,
reply,
thumbnail,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!q) return reply("Hmph! Cadê o número do usuário que você deseja convidar... Eu não adivinho, bobinho(a)!");
try {
photoG = await kira.profilePictureUrl(from, "image");
} catch {
photoG = thumbnail;
}
rcrt = q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`;
linkgc = await kira.groupInviteCode(from);
await kira.sendMessage(rcrt, {
text: "*Hmph! Olá, tudo bem?* Você foi convidado(a) pelo(a) adminstrador(a) do grupo... Para entrar no grupo, clique acima! Eu só estou repassando, tá?!",
contextInfo: {
externalAdReply: {
title: "Hmph! Clique aqui para participar do grupo.",
thumbnail: await getBuffer(photoG),
mediaType: 1,
sourceUrl: "https://chat.whatsapp.com/" + linkgc,
},
},
});
reply(
"Hmph! Convite de recrutamento do usuário, foi enviado para o privado dele com sucesso... Prontinho, mas não se acostume com isso, viu?! Só fiz porque quis!"
);
}
};