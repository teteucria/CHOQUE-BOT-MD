module.exports = {
nome: ["mute"],
executar: async ({
botNumber,
from,
fs,
groupAdmins,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
menc_os2,
mentions,
mess,
muted,
nmrdn,
q,
reply,
selo,
sender,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
let alvo = menc_os2;
if (!alvo) return reply(`*🎯 Hmph! Mencione quem quer punir... Eu não adivinho, bobinho(a)!*`);
if (alvo == botNumber || alvo == nmrdn) return reply(`*Hmph! Esse usuário não pode ser punido!* Nem pensar, baka!`);
if (groupAdmins.includes(alvo)) return reply(`*Hmph! Não pode mutar um admin... Não sou tão ousada assim, viu?!*`);
let indexG = muted.findIndex(i => i.grupo === from);
if (indexG === -1) {
muted.push({ grupo: from, mutados: [], silenciados: [] });
indexG = muted.length - 1;
}
const tipo = q.toLowerCase().includes("silenciar") ? "silenciar" : "mutar";
const alvoNumero = alvo.split('@')[0];
if (tipo === "silenciar") {
if (muted[indexG].silenciados.includes(alvo)) return reply(`*Hmph! O @${alvoNumero} já está silenciado... Não percebeu, baka?!*`, { mentions: [alvo] });
muted[indexG].silenciados.push(alvo);
await kira.sendMessage(from, { text: `*Hmph! O @${alvoNumero} silenciado por @${sender.split('@')[0]} 🔇... Eu que cuidei disso, viu?! Não agradeça!*`, mentions: [alvo, sender] }, { quoted: selo });
} else {
if (muted[indexG].mutados.includes(alvo)) return reply(`*Hmph! O @${alvoNumero} já está mutado... Presta atenção, bobinho(a)!*`, { mentions: [alvo] });
muted[indexG].mutados.push(alvo);
await kira.sendMessage(from, { text: `*Hmph! O @${alvoNumero} mutado por @${sender.split('@')[0]} 🚫... Eu que fiz o serviço, tá?! Não se acostume!*`, mentions: [alvo, sender] }, { quoted: selo });
}
}
};