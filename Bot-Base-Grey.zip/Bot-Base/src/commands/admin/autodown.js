module.exports = {
nome: ["autodown"],
executar: async ({
  args,
  command,
  dataGp,
  isAutodown,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1)
return reply(`Hmph! Use 1 pra ativar ou 0 pra desativar, bobinho(a)... Caso deseje ativar, use: ${prefix + command} 1, e pra desativar é só trocar o 1 pelo 0. Não é difícil, viu?!`);
if (Number(args[0]) === 1) {
if (isAutodown) return reply("Hmph! O recurso de autodown já está ativado... Não percebeu, baka?! Tanto faz!");
dataGp[0].autodown = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o autodown neste grupo... 🙇🏻‍♂️💖️ Eu que fiz todo o trabalho, tá?! Não se acostume, viu?");
} else if (Number(args[0]) === 0) {
if (!isAutodown)
return reply("Hmph! O recurso autodown já está desativado... Não percebeu, bobinho(a)?!");
dataGp[0].autodown = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o autodown neste grupo... 🙇🏻‍♂️💖️ Só fiz porque quis, viu?!");
} else {
reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};