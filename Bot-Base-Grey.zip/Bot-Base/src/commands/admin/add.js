module.exports = {
nome: ["add","unkick"],
executar: async ({
SoDono,
from,
info,
isBotGroupAdmins,
isGroupAdmins,
mentions,
mess,
q,
quoted,
reply,
result,
selo,
sender,
text,
useradd,
kira
}) => {

if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!q && info.message.extendedTextMessage === null)
return reply("Hmph! Marque a mensagem ou digite o número de quem você quer adicionar no grupo... Eu não leio mentes, tá?! Baka.");
try {
useradd = `${args.join(" ").replace(/\D/g, "")}` ? `${args.join(" ").replace(/\D/g, "")}` : info.message.extendedTextMessage.contextInfo.participant;
let id = `${useradd.replace(/\D/g, "")}`;
if (!id) return reply(`Hmph! Número inválido... Presta atenção no que você digitou, baka! Eu sou boa nisso, viu?!`);
let [result] = await kira.onWhatsApp(id);
if (!result)
return reply(`Hmph! Esse número não está registrado no WhatsApp... Eu verifiquei duas vezes, viu?! Não existe, tanto faz!`);
let response = await kira.groupParticipantsUpdate(from, [result.jid], "add");
if (response[0].status == "409") {
await kira.sendMessage(from, {text: `Hmph! Ele já está no grupo... Como é que eu vou adicionar quem já está aqui, bobinho? Presta atenção, tá?!`, mentions: [result.jid, sender]}, {quoted: selo});
} else if (response[0].status == "403") {
await kira.sendMessage(from, {text: `Hmph! Não consegui adicionar o @${result.jid.split("@")[0]} porque ele privou a conta... Eu tentei, tá?! Não é culpa minha, baka!`, mentions: [result.jid, sender]}, {quoted: selo});
} else if (response[0].status == "408") {
await kira.sendMessage(from, {text: `Hmph! Não consegui adicionar o @${result.jid.split("@")[0]} porque ele saiu recentemente do grupo... Não é como se eu não tivesse tentado, baka!`, mentions: [result.jid, sender]}, {quoted: selo});
} else if (response[0].status == "401") {
await kira.sendMessage(from, {text: `Hmph! Não consegui adicionar o @${result.jid.split("@")[0]} porque ele bloqueou o bot... Nem eu consigo resolver isso, viu?! Tanto faz!`, mentions: [result.jid, sender]}, {quoted: selo});
} else if (response[0].status == "200") {
await kira.sendMessage(from, {text: `Prontinho, fiz o que você pediu... N-não fica achando que eu faço isso por qualquer um, tá?! Só fiz porque quis!`, mentions: [result.jid, sender]}, {quoted: selo});
} else {
await kira.sendMessage(from, {text: `Hmph! Ocorreu um erro ao adicionar o(a) *@${result.jid.split("@")[0]}* no grupo... Nem eu sou perfeita o tempo todo, baka! Vou consertar isso, pode deixar!`, mentions: [result.jid, sender]}, {quoted: selo});
}
} catch (error) {
reply(mess.error());
}
}
};