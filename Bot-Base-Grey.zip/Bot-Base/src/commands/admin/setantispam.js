module.exports = {
nome: ["setantispam"],
executar: async ({
  kira,
  from,
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess,
  prefix,
  q}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!q) return reply(`Hmph! Exemplo:\n${prefix}setantispam 5... Não é difícil, bobinho(a)!`);
const tempoSpam = Number(q);
if (isNaN(tempoSpam) || tempoSpam < 1) {
return reply("Hmph! Digite um número válido... Presta atenção, baka!");
}
if (!dataGp[0].antispam) dataGp[0].antispam = {};
dataGp[0].antispam.tempo = tempoSpam;
setGp(dataGp);
reply(`✅ Hmph! Tempo definido para ${tempoSpam} segundos... Prontinho, mas não se acostume com isso, viu?!`);
}
};