module.exports = {
nome: ["antiddd","anti_ddd","anti-ddd"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiDDD,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return await reply(mess.onlyGroup());
if (!isGroupAdmins) return await reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return await reply(mess.onlyBotAdmin());
if (args.length < 1)
return await reply(
`Hmph! Use 1 pra ativar ou 0 pra desativar, bobinho(a)... Caso deseje ativar, use: ${prefix + command} 1, e pra desativar é só trocar o 1 pelo 0. Não é difícil, viu?!`
);
if (Number(args[0]) === 1) {
if (isAntiDDD)
return await reply(
"Hmph! Este recurso já está ativado atualmente senhor(a)! Não percebeu, bobinho(a)?!"
);
dataGp[0].ANTI_DDD.active = true;
setGp(dataGp);
await reply(
"(♥️) Hmph! O recurso de remoção de números com DDD adicionado à lista, foi ativado com sucesso... Eu que fiz todo o trabalho, viu?! Não se acostume!"
);
} else if (Number(args[0]) === 0) {
if (!isAntiDDD)
return await reply(
"Hmph! Este recurso já está desativado atualmente senhor(a)! Tanto faz, baka!"
);
dataGp[0].ANTI_DDD.active = false;
setGp(dataGp);
await reply(
"(♥️) Hmph! O recurso de remoção de números com DDD adicionado à lista, foi desativado com sucesso... Só fiz porque quis, tá?!"
);
} else {
await reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};