module.exports = {
nome: ["admins","listadmins","listaadmins"],
executar: async ({
groupAdmins,
groupMetadata,
isGroup,
mentions,
mess,
reply
}) => {

if (!isGroup) return reply(mess.onlyGroup());
ytb = `Hmph! Aqui está a lista de admins do grupo *${groupMetadata.subject}*\n*Total de Adminstradores:* ${groupAdmins.length}\n-\n`;
no = 0;
for (let admon of groupAdmins) {
no += 1;
ytb += `( ${no.toString()} ) - @${admon.split("@")[0]}\n`;
}
await mentions(ytb, groupAdmins, true);
}
};