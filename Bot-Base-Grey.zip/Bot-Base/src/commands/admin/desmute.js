module.exports = {
nome: ["desmute"],
executar: async ({
fs,
grupoMute,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
menc_os2,
mentions,
mess,
muted,
quoted,
reply,
selo,
sender,
kira
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
let alvo = menc_os2;
if (!alvo) return reply(`*🎯 Hmph! Mencione quem quer desmutar... Eu não adivinho, bobinho(a)!*`);
if (!grupoMute.silenciados.includes(alvo) && !grupoMute.mutados.includes(alvo))
return reply(`*Hmph! O @${alvo.split('@')[0]} não está punido... Presta atenção, baka!*`, { mentions: [alvo] });
grupoMute.silenciados = grupoMute.silenciados.filter(id => id !== alvo);
grupoMute.mutados = grupoMute.mutados.filter(id => id !== alvo);
await kira.sendMessage(from, {text: `*Hmph! O @${alvo.split('@')[0]} foi liberado por @${sender.split('@')[0]} 🙆‍♂️... Prontinho, mas não se acostume com isso, viu?!*`, mentions: [alvo, sender]}, {quoted: selo});
}
}
};