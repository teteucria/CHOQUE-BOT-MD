module.exports = {
nome: ["antipalavrão","antipalavrao","antipalavra"],
executar: async ({
args,
command,
dataGp,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
isPalavrao,
mess,
prefix,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1) return reply(`Hmph! Use 1 pra ativar ou 0 pra desativar, bobinho(a)... Caso deseje ativar, use: ${prefix + command} 1, e pra desativar é só trocar o 1 pelo 0. Não é difícil, viu?!`);
if (Number(args[0]) === 1) {
if (isPalavrao) return reply("Hmph! O recurso de anti palavrões hardcore já se encontra ativo no grupo senhor(a)! Não percebeu, baka?!");
dataGp[0].antipalavrao.active = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o recurso de anti palavras hardcore neste grupo... Eu que fiz todo o trabalho, viu?! Não se acostume!");
} else if (Number(args[0]) === 0) {
if (!isPalavrao)
return reply("Hmph! O recurso de anti palavrões hardcore já se encontra desativado no grupo senhor(a)! Tanto faz, idiota!");
dataGp[0].antipalavrao.active = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o recurso de anti palavra hardcore neste grupo... Só fiz porque quis, tá?!");
} else {
reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};