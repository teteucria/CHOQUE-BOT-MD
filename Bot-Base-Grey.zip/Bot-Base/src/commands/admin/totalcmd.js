module.exports = {
nome: ["totalcmd","totalcomando"],
executar: async ({
pushname,
totalcmds,
reply
}) => {

reply(`Hmph! *b᥆꧑ dιᥲ ${pushname}!*

ᥴ᥆ᥒtᥱᥒh᥆: ${totalcmds} ᥴ᥆꧑ᥲᥒd᥆᥉ 🩵

...Tome, tá?! Eu contei direitinho, viu?! Não se acostume!`);
}
};