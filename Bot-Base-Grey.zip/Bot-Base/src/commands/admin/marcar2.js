module.exports = {
nome: ["marcar2"],
executar: async ({
args,
body,
groupMembers,
isGroup,
isGroupAdmins,
mess,
q,
  prefix,
reply
}) => {

try {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (q.includes(`${prefix}`)) return reply("Hmph! Não pode utilizar comandos nesse comando... Presta atenção, bobinho(a)!");
    members_id = [];
    teks = args.length > 1 ? body.slice(8).trim() : "";
    teks += `Hmph! ╭─ *Lista de Membros do Grupo* ─╮\n`;
    teks += `│\n`;
    for (let mem of groupMembers) {
        teks += `╠➥ @${mem.id.split("@")[0]}\n`;
        members_id.push(mem.id);
    }
teks += `╰───────────────────────╯\n...Tome, tá?! Só fiz porque quis!`;
reply(teks);
} catch {
reply("Hmph! Erro ao mencionar... Nem eu sou perfeita o tempo todo, baka! Mas deixa que eu conserto!");
}
}
};