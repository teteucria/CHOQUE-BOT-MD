module.exports = {
nome: ["antiedit", "antieditgrupo"],
executar: async ({
  isGroup,
  isGroupAdmins,
  dataGp,
  setGp,
  reply,
  mess,
  prefix,
  q
}) => {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (q === "1") {
dataGp[0].anti_edit_grupo = true;
setGp(dataGp);
reply("✅ Hmph! Proteção do grupo ativada... Quem não for admin e conseguir mudar nome, foto, descrição ou configurações do grupo vai ser banido na hora, viu?!");
} else if (q === "0") {
dataGp[0].anti_edit_grupo = false;
setGp(dataGp);
reply("❌ Hmph! Proteção do grupo desativada... Tanto faz, baka!");
} else {
reply(`Hmph! Use assim, bobinho(a):\n` +
`${prefix}antiedit 1 = ativar\n` +
`${prefix}antiedit 0 = desativar`);
}
}
};