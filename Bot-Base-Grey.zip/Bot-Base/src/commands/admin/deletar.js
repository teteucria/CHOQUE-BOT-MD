module.exports = {
nome: ["deletar","delete","del","d"],
executar: async ({
SoDono,
from,
fromMe,
info,
isBotGroupAdmins,
isGroupAdmins,
menc_os2,
mess,
reply,
kira
}) => {

{
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!menc_os2) return reply("Hmph! Marque a mensagem do usuário que deseja apagar, do bot ou de alguém.. Eu não adivinho qual é, baka!");
const msg = info.message.extendedTextMessage.contextInfo;
await kira.sendMessage(from, {delete: {remoteJid: from, fromMe: false, id: msg.stanzaId, participant: msg.participant}});
}
}
};