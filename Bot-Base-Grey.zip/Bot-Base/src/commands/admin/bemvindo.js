module.exports = {
nome: ["bemvindo","welcome"],
executar: async ({
  SoDono,
  args,
  command,
  dataGp,
  isGroup,
  isGroupAdmins,
  isWelkom,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (args.length < 1) return reply(`Hmph! Digite da forma correta, bobinho(a):\nComando: ${prefix + command} 1 para ativar`);
if (Number(args[0]) === 1) {
if (isWelkom) return reply("Hmph! O recurso de bem-vindo já está ativado... Não percebeu, baka?!");
if (!dataGp[0].wellcome) dataGp[0].wellcome = [{}];
if (!dataGp[0].wellcome[0]) dataGp[0].wellcome[0] = {};
dataGp[0].wellcome[0].bemvindo1 = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o recurso bem-vindo neste grupo... 🙇🏻‍♂️💖️ Eu que fiz todo o trabalho, tá?! Não se acostume, viu?");
} else if (Number(args[0]) === 0) {
if (!isWelkom) return reply("Hmph! O recurso de bem-vindo já está desativado... Tanto faz, bobinho(a)?!");
if (!dataGp[0].wellcome) dataGp[0].wellcome = [{}];
if (!dataGp[0].wellcome[0]) dataGp[0].wellcome[0] = {};
dataGp[0].wellcome[0].bemvindo1 = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o recurso bem-vindo neste grupo... 🙇🏻‍♂️💖 Só fiz porque quis, viu?!");
} else {
reply(`Hmph! Digite da forma correta, ${prefix + command} 1, para ativar e 0 para desativar... Não é tão difícil, baka!`);
}
}
};