module.exports = {
nome: ["alugar","lojinha","loja"],
executar: async ({
JSON,
Padr,
URL,
buttonParamsJson,
buttons,
console,
description,
direto,
display_text,
e,
footer,
from,
fs,
id,
image,
interactiveMessage,
logos,
menu,
mess,
name,
o,
p,
por,
quoted,
reagir,
reply,
sections,
selo,
title,
url,
  prefix,
kira
}) => {

try {
await reagir(from, "🛒");

const planos = JSON.parse(fs.readFileSync('./settings/planos.json'));

const rows = planos.map(p => ({
title: p.nome,
description: `Hmph! Valor: R$ ${p.preco.toFixed(2)} | Duração: ${p.dias} Dias`,
id: `${prefix}pix ${p.preco}`
}));

const corpoLoja = [
`🏪 *${NomeDoBot} STORE*`,
` `,
`Hmph! Olá ${pushname}, aqui estão nossos planos disponíveis para aluguel...`,
`Selecione o plano desejado no botão abaixo para gerar o seu PIX de pagamento, tá?! Não é como se eu quisesse seu dinheiro... bom, tanto faz!`,
` `,
`🚀 *Ativação instantânea após o pagamento!*`,
` `,
`〔 🛒 NOSSA LOJA 〕`
].join('\n');

await kira.sendMessage(from, {
interactiveMessage: {
title: `${corpoLoja}`,
footer: `*kira SYSTEM*`,
buttons: [
{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "📋 VER PLANOS",
sections: [{
title: "PLANOS DISPONÍVEIS",
rows: rows
}]
})
},
{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: "📞 SUPORTE",
url: "https://wa.me/556681147547"
})
}
],
image: { url: logos.img } // Padrão case menu: direto por URL
}
}, { quoted: selo });

} catch (e) {
console.log(e);
reply(mess.error());
}
}
};