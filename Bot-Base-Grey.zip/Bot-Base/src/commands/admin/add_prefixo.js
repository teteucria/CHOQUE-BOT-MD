module.exports = {
nome: ["add_prefixo"],
executar: async ({
  command,
  dataGp,
  isGroup,
  isGroupAdmins,
  isMultiP,
  mess,
  prefix,
  q,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isMultiP) return reply(`Hmph! Para usar este comando, você deve ativar o comando, multiprefix\nExemplo: ${prefix}multiprefixo... Não é óbvio, baka?!`);
if (!q.trim()) return reply("Hmph! Determine o novo prefixo, bobinho(a)... Nada de espaço vazio, tá?!");
if (q.trim() > 1) return reply(`Hmph! Calma, o prefixo só pode ser um, idiota\nExemplo: ${prefix + command} _\nAe o bot vai passar á responder _ como prefixo do bot.. Entendeu agora, viu?!`);
if (dataGp[0].prefixos.indexOf(q.trim()) >= 0) return reply(`Hmph! Esse prefixo já está na lista, bobinho(a)... Confere aí na lista dos prefixos\nExemplo: ${prefix}prefixos`);
dataGp[0].prefixos.push(q.trim());
setGp(dataGp);
reply(`Hmph! Prefixo ${q.trim()} foi adicionado com sucesso na lista de prefixos para uso do bot, neste grupo... Não se acostume com isso, viu?! Só fiz porque quis!`);
}
};