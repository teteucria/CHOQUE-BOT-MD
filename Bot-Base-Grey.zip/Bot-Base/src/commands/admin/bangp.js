module.exports = {
nome: ["bangp","unbangp"],
executar: async ({
SoDono,
command,
dataGp,
isBanchat,
isGroup,
mess,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!SoDono) return reply(mess.onlyOwner());
if (command == "bangp") {
if (isBanchat) return reply(`Hmph! Este grupo já está banido... Não percebeu, baka?! Tanto faz!`);
dataGp[0].bangp = true;
setGp(dataGp);
reply(`Hmph! Grupo banido com sucesso... Eu que cuidei disso, viu?! Não se acostume!`);
} else {
if (!isBanchat) return reply(`Hmph! Este grupo não está banido... Presta atenção, bobinho(a)!`);
dataGp[0].bangp = false;
setGp(dataGp);
reply(`Hmph! Grupo desbanido... Só fiz porque quis, tá?!`);
}
}
};