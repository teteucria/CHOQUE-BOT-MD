module.exports = {
nome: ["tirar_prefixo"],
executar: async ({
  command,
  dataGp,
  isGroup,
  isGroupAdmins,
  isMultiP,
  mess,
  prefix,
  q,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isMultiP) return reply(`Hmph! Para usar este comando, você deve ativar o comando, multiprefix\nExemplo: ${prefix}multiprefixo... Não é óbvio, baka?!`);
if (!q.trim()) return reply("Hmph! Determine o prefixo que deseja tirar, bobinho(a)... Nada de espaço vazio, viu?!");
if (q.trim() > 1) return reply(`Hmph! Calma, o prefixo só pode ser tirado um por vez..\nExemplo: ${prefix + command} _\nAe o bot não vai responder mais com _... Entendeu agora, tá?!`);
if (dataGp[0].prefixos.indexOf(q.trim()) < 0) return reply(`Hmph! Esse prefixo não está incluso, confere na lista dos prefixos. Veja: ${prefix}prefixos`);
if (dataGp[0].prefixos.length == 1) return reply("Hmph! Adicione um prefixo para pode tirar este, tem que ter pelo menos 1 prefixo já incluso dentro do sistema para tirar outro... Presta atenção, idiota!");
dataGp[0].prefixos.splice(dataGp[0].prefixos.indexOf(q.trim()), 1);
setGp(dataGp);
reply(`Hmph! Prefixo ${q.trim()} tirado com sucesso da lista de prefixos de uso deste grupo.. Só fiz porque quis, tá?! Não se acostume!`);
}
};