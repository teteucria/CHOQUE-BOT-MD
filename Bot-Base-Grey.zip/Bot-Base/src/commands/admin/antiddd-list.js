module.exports = {
nome: ["antiddd-list"],
executar: async ({
dataGp,
isAntiDDD,
isGroup,
mess,
  prefix,
reply
}) => {

if (!isGroup) return await reply(mess.onlyGroup());
if (!isAntiDDD)
return await reply(
`Hmph! Para usar este comando, você deve ativar o comando: antiddd\nExemplo: ${prefix}antiddd 1... Não é óbvio, bobinho(a)?!`
);
if (dataGp[0].ANTI_DDD.listaProibidos.length < 1)
return await reply(
`Hmph! [!] Não existe nenhum ddd proibido neste grupo... Pra adicionar, use: ${prefix}add_ddd 21, por exemplo. Não me obrigue a explicar duas vezes, viu?!`
);
await reply(
`Hmph! Aqui está a lista de DDD proibidos no grupo: '${groupName}':\n• *[Total: ${dataGp[0].ANTI_DDD.listaProibidos.length}]* - ${dataGp[0].ANTI_DDD.listaProibidos.map((v, index) => v).join(", ")}\n\n...Agora vai lá, e não diga que não avisei, tá?!`
);
}
};