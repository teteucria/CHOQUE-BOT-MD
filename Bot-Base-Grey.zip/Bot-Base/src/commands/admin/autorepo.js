module.exports = {
nome: ["autorepo"],
executar: async ({
  args,
  command,
  dataGp,
  isAutorepo,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1)
return reply(`Hmph! Use 1 pra ativar ou 0 pra desativar, bobinho(a)... Caso deseje ativar, use: ${prefix + command} 1, e pra desativar é só trocar o 1 pelo 0. Não é difícil, viu?!`);
if (Number(args[0]) === 1) {
if (isAutorepo)
return reply("Hmph! O modo auto resposta já se encontra ativo no grupo... Não percebeu, baka?!");
dataGp[0].autoresposta = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o recurso de auto resposta neste grupo... Eu que fiz todo o trabalho, viu?! Não se acostume!");
} else if (Number(args[0]) === 0) {
if (!isAutorepo) return reply("Hmph! O modo auto resposta já está desativado no grupo... Tanto faz, idiota!");
dataGp[0].autoresposta = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o recurso de auto resposta neste grupo... Só fiz porque quis, tá?!");
} else {
reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};