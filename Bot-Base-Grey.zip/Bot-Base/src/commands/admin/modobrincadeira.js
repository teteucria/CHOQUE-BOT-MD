module.exports = {
nome: ["modobrincadeira","modobrincadeiras"],
executar: async ({
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  isModobn,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1)
return reply(`Hmph! Use 1 pra ativar ou 0 pra desativar, bobinho(a)... Caso deseje ativar, use: ${prefix + command} 1, e pra desativar é só trocar o 1 pelo 0. Não é difícil, viu?!`);
if (Number(args[0]) === 1) {
if (isModobn) return reply("Hmph! O modo brincadeira já está ativo... Não percebeu, baka?!");
dataGp[0].jogos = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o recurso de Modo brincadeira neste grupo... Eu que fiz todo o trabalho, viu?! Não se acostume!");
} else if (Number(args[0]) === 0) {
if (!isModobn)
return reply("Hmph! O modo brincadeira já está desativado... Tanto faz, bobinho(a)?!");
dataGp[0].jogos = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o recurso de Modo brincadeira neste grupo... Só fiz porque quis, tá?!");
} else {
reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};