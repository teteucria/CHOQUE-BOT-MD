module.exports = {
nome: ["descgp","descriçãogp"],
executar: async ({
args,
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mess,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyAdmins());
blabla = args.join(" ");
await kira.groupUpdateDescription(from, `${blabla}`);
await kira.sendMessage(
from,
{ text: "Hmph! Sucesso, alterou a descrição do grupo... Prontinho, fiz o que você pediu. Não se acostume com isso, viu?!" },
{ quoted: selo }
);
}
};