module.exports = {
nome: ["marcarwa"],
executar: async ({
args,
body,
from,
groupMembers,
isGroup,
isGroupAdmins,
mess,
q,
reply,
selo,
  prefix,
kira
}) => {

try {
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (q.includes(`${prefix}`))
return reply("Hmph! Não pode utilizar comandos nesse comando... Presta atenção, bobinho(a)!");
members_id = [];
teks = args.length > 1 ? body.slice(10).trim() : "";
teks += `Hmph! ╭─ *Lista de Membros do Grupo* ─╮\n`;
teks += `│\n`;
    for (let mem of groupMembers) {
        teks += `│╠➥ https://wa.me/${mem.id.split("@")[0]}\n`;
        members_id.push(mem.id);
    }
teks += `╰────────────────────────╯\n...Prontinho, mas não se acostume, viu?!`;
await kira.sendMessage(from, { text: teks }, { quoted: selo });
} catch {
reply("Hmph! Erro ao mencionar... Deixa que eu resolvo, baka!");
}
}
};