module.exports = {
nome: ["multiprefixo","multiprefix"],
executar: async ({
SoDono,
dataGp,
isGroup,
isGroupAdmins,
isMultiP,
mess,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!isMultiP) {
dataGp[0].multiprefix = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o multiprefixo neste grupo. 🙇🏻‍♂️💖️ Eu que fiz todo o trabalho, tá?! Não se acostume, viu?");
}
if (isMultiP) {
dataGp[0].multiprefix = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o multiprefixo neste grupo. 🙇🏻‍♂️💖 Só fiz porque quis, viu?!");
}
}
};