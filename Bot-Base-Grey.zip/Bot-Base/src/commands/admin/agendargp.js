module.exports = {
nome: ["agendargp","agendargrupo"],
executar: async ({
SoDono,
abrir,
abrirHora,
ativo,
d,
fechar,
fecharHora,
from,
g,
getFecharAbrir,
isGroup,
isGroupAdmins,
mess,
q,
reagir,
reply,
  prefix,
saveFecharAbrir
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!q.includes("/")) return reply(`📌 Hmph! Use assim, bobinho(a):\n\n${prefix}agendargp 23:00/06:00`);
reagir(from, "✅️");
let [fecharHora, abrirHora] = q.split("/");
if (!fecharHora || !abrirHora) {
return reply("❌ Hmph! Horários inválidos... Presta atenção no que você digitou, baka!");
}
const regexHora = /^([01]\d|2[0-3]):([0-5]\d)$/;
if (!regexHora.test(fecharHora) || !regexHora.test(abrirHora)) {
return reply("❌ Hmph! Formato inválido... Use exemplo: 23:00/06:00, viu?! Não é tão difícil!");
}
let agendados = getFecharAbrir();
const existe = agendados.findIndex(g => g.grupo === from);
const novo = {
grupo: from,
fechar: fecharHora,
abrir: abrirHora,
ativo: true
};
if (existe >= 0) {
agendados[existe] = novo;
} else {
agendados.push(novo);
}
saveFecharAbrir(agendados);
reply(`✅ Hmph! AGENDAMENTO SALVO COM SUCESSO.\n🔐 VAI FECHAR AS: ${fecharHora}\n🔓 ABRIRÁ AS: ${abrirHora}\n\n...Prontinho, fiz o que você pediu. Mas não se acostume com isso, viu?!`);
}
}
};