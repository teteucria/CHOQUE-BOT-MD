module.exports = {
nome: ["totag","cita","hidetag"],
executar: async ({
command,
from,
groupMembers,
info,
isGroup,
isGroupAdmins,
isQuotedAudio,
isQuotedDocW,
isQuotedDocument,
isQuotedImage,
isQuotedMsg,
isQuotedSticker,
isQuotedVideo,
mess,
prefix,
pushname,
q,
reply,
string,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
var DFC = "";
var rsm = info.message?.extendedTextMessage?.contextInfo?.quotedMessage;
var pink = isQuotedImage ? rsm?.imageMessage : info.message?.imageMessage;
var blue = isQuotedVideo ? rsm?.videoMessage : info.message?.videoMessage;
var purple = isQuotedDocument ? rsm?.documentMessage : info.message?.documentMessage;
var yellow = isQuotedDocW ? rsm?.documentWithCaptionMessage?.message?.documentMessage : info.message?.documentWithCaptionMessage?.message ?.documentMessage;
var aud_d = isQuotedAudio ? rsm.audioMessage : "";
var figu_d = isQuotedSticker ? rsm.stickerMessage : "";
var red = isQuotedMsg && !aud_d && !figu_d && !pink && !blue && !purple && !yellow ? rsm.conversation : info.message?.conversation;
var green = rsm?.extendedTextMessage?.text || info?.message?.extendedTextMessage?.text;
var MRC_TD = groupMembers.map((i) => i.id);

function escapeRegExp(string) {
return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const commandToReplace = escapeRegExp(prefix + command);
const regexPattern = new RegExp(commandToReplace, "gi");
const replacementText = `Hmph! ❪👑 *Marcação do(a) Adm:* ${pushname}\n\n`;

if (pink && !aud_d && !purple) {
var DFC = pink;
pink.caption =
q.length > 1
? "Hmph! ❪👑 *Marcação do(a) Adm:* " + q
: pink.caption
? pink.caption.replace(regexPattern, replacementText)
: replacementText;
pink.image = { url: pink.url };
pink.mentions = MRC_TD;
} else if (blue && !aud_d && !purple) {
var DFC = blue;
blue.caption =
q.length > 1
? "Hmph! ❪👑 *Marcação do(a) Adm:* " + q.trim()
: blue.caption
? blue.caption.replace(regexPattern, replacementText).trim()
: replacementText.trim();
blue.video = { url: blue.url };
blue.mentions = MRC_TD;
} else if (red && !aud_d && !purple) {
var black = {};
black.text = red
? red.replace(regexPattern, replacementText).trim()
: replacementText.trim();
black.mentions = MRC_TD;
var DFC = black;
} else if (!aud_d && !figu_d && green && !purple) {
var brown = {};
brown.text = green
? green.replace(regexPattern, replacementText).trim()
: replacementText.trim();
brown.mentions = MRC_TD;
var DFC = brown;
} else if (purple) {
var DFC = purple;
purple.document = { url: purple.url };
purple.mentions = MRC_TD;
} else if (yellow && !aud_d) {
var DFC = yellow;
yellow.caption =
q.length > 1
? "Hmph! ❪👑 *Marcação do(a) Adm:* " + q.trim()
: yellow.caption
? yellow.caption
.replace(regexPattern, replacementText)
.trim()
: replacementText.trim();
yellow.document = { url: yellow.url };
yellow.mentions = MRC_TD;
} else if (figu_d && !aud_d) {
var DFC = figu_d;
figu_d.sticker = { url: figu_d.url };
figu_d.mentions = MRC_TD;
} else if (aud_d) {
var DFC = aud_d;
aud_d.audio = { url: aud_d.url };
aud_d.mentions = MRC_TD;
aud_d.ptt = true;
} else {
var DFC = {
text:
q.length > 1
? "Hmph! ❪👑 *Marcação do(a) Adm:* " + q
: replacementText,
mentions: MRC_TD,
};
}

try {
await kira.sendMessage(from, DFC);
} catch (error) {
console.log("Erro ao enviar marcação:", error);
reply("Hmph! Erro ao marcar membros do grupo... Nem eu sou perfeita o tempo todo, baka! Mas deixa que eu conserto, viu?!");
}
}
};