module.exports = {
nome: ["autofigu","autosticker"],
executar: async ({
args,
dataGp,
isAutofigu,
IsAutofigu,
autofigu,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mess,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1) return reply("Hmph! 1 pra ligar / 0 pra desligar... É só isso, baka!");
if (Number(args[0]) === 1) {
if (IsAutofigu) return reply("Hmph! O recurso de auto figurinhas já está ativado... Não percebeu, bobinho(a)?!");
dataGp[0].autosticker.IsAutofigu = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o auto figurinhas neste grupo... 🙇🏻‍♂️💖️ Eu que fiz todo o trabalho, tá?! Não se acostume, viu?");
} else if (Number(args[0]) === 0) {
if (!isAutofigu && !IsAutofigu && !autofigu) return reply("Hmph! O recurso de auto figurinhas já está desativado... Tanto faz, baka!");
dataGp[0].autosticker.isAutofigu = false;
dataGp[0].autosticker.IsAutofigu = false;
dataGp[0].autosticker.autofigu = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o auto figurinhas neste grupo... 🙇🏻‍♂️💖 Só fiz porque quis, viu?!");
} else {
reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};
