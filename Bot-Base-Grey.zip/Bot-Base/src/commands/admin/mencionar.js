module.exports = {
nome: ["mencionar"],
executar: async ({
kira,
from,
reply,
prefix,
isGroup,
isModobn,
reagir,
mess,
groupMembers,
q}) => {

if (!q) return reply(`Hmph! Você usou o comando de forma incorreta, use a correta: ${prefix}mencionar corno... Presta atenção, baka!`);
if (!isGroup) return reply(`Hmph! Esta brincadeira só funciona em grupos... P-por que tentaria fora, bobinho(a)?!`);
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
reagir(from, "✅");
    await mention(`Hmph! Estou mencionando o *${q}* do grupo: *@${groupMembers[Math.floor(Math.random() * groupMembers.length)].id.split("@")[0]}*... Só fiz porque quis, tá?!`);
}
};