module.exports = {
nome: ["marcar"],
executar: async ({
args,
body,
from,
groupMembers,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mentions,
mess,
quoted,
reply,
selo,
kira
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
    let membros = groupMembers.map(m => m.id);
    texto = args.length > 1 ? body.slice(10).trim() : "";
    texto += `Hmph! ╭─ *Lista de Membros do Grupo* ─╮\n`;
    texto += `│\n`;
    for (let mem of groupMembers) {
        texto += `│» @${mem.id.split("@")[0]}\n`;
    }
texto += `╰────────────────────────╯\n...Aí está, tá?! Não se acostume com isso, viu!`;
await kira.sendMessage(from, {text: texto, mentions: membros}, {quoted: selo});
}
}
};