module.exports = {
nome: ["brlist","listabr"],
executar: async ({
botNumber,
enviar,
from,
groupMembers,
isGroup,
isGroupAdmins,
mention,
reagir,
reply
}) => {

if (!isGroup) return reply(enviar.msg.grupo);
reagir(from, "🇧🇷");
txt = `Hmph! 🇧🇷 *Lista de números brasileiros presentes neste grupo:*\n`;
let totalbr = 0;
    for (i = 0; i < groupMembers.length; i++) {
        if (groupMembers[i].id.split(groupMembers[i].id.slice(2))[0] === "55") {
            if (groupMembers[i].id.includes(botNumber)) {
            } else {
                txt += `⇒ ${isGroupAdmins ? "@" : "wa.me/"}${groupMembers[i].id.split("@")[0]}\n`;
                totalbr += 1;
            }
        }
    }
txt += `\nHmph! 🇧🇷 Total: ${totalbr}`;
if (totalbr > 0) {
var resp = isGroupAdmins ? mention : reply;
resp(txt);
} else {
reply("Hmph! Não há números brasileiros neste grupo... Tanto faz, baka!");
}
}
};