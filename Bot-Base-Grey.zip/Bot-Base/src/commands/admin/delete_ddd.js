module.exports = {
nome: ["delete_ddd","del_ddd","rm_ddd"],
executar: async ({
command,
dataGp,
isAntiDDD,
isGroup,
isGroupAdmins,
mess,
prefix,
q,
reply,
setGp
}) => {

if (!isGroup) return await reply(mess.onlyGroup());
if (!isGroupAdmins) return await reply(mess.onlyAdmins());
if (!isAntiDDD)
return await reply(
`Hmph! Para usar este comando, você deve ativar o comando: antiddd\nExemplo: ${prefix}antiddd 1... Não é óbvio, bobinho(a)?!`
);
if (!q.trim())
return await reply(
"Hmph! Determine o DDD que você deseja remover da lista... E nada de espaço vazio, viu?! Presta atenção!"
);
if (q.trim() === 2)
return await reply(
`Hmph! Calma, só pode ser removido um DDD por vez, idiota.\n• Exemplo: ${prefix + command} 84, aí o bot não vai mais remover os DDDs pertencentes à Rio Grande do Sul... Entendeu, viu?!`
);
if (dataGp[0].ANTI_DDD.listaProibidos.indexOf(q.trim()) < 0)
return await reply(
`Hmph! Este DDD não está na lista, bobinho(a)... Confira na lista dos DDDs excluídos deste grupo. Use: ${prefix}antiddd-list`
);
if (dataGp[0].ANTI_DDD.listaProibidos.length == 0)
return await reply(
"Hmph! A lista está vazia... Não tem como remover nada que não existe, baka! Adicione pelo menos um."
);
dataGp[0].ANTI_DDD.listaProibidos.splice(
dataGp[0].ANTI_DDD.listaProibidos.indexOf(q.trim()),
1
);
setGp(dataGp);
await reply(
`Hmph! O DDD '${q.trim()}' tirado com sucesso da lista de DDDs excluídos do grupo, agora o bot não irá mais impedir à entrada deles... Eu que fiz isso, viu?! Não se acostume!`
);
}
};