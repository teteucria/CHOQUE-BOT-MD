module.exports = {
nome: ["recusar","negar"],
executar: async ({
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mess,
reply,
kira
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
const pendentes = await kira.groupRequestParticipantsList(from);
const total = pendentes?.length || 0;
if (total === 0)
return reply('*Hmph! Não tem solicitações pendentes.* Tanto faz, bobinho(a)!');
for (const p of pendentes) {
await kira.groupRequestParticipantsUpdate(from, [p.jid], 'reject');
}
reply(`*Hmph! ${total} solicitações recusada(a)s!* Eu que cuidei disso, viu?! Não agradeça, tá?!`);
}
}
};