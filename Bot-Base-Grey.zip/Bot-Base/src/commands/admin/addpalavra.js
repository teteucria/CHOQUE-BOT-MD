module.exports = {
nome: ["addpalavra"],
executar: async ({
args,
command,
dataGp,
isGroup,
isGroupAdmins,
isPalavrao,
isPalavras,
mess,
prefix,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isPalavrao) return reply("Hmph! Anti palavrão desativado... Ative primeiro, bobinho(a), antes de querer adicionar palavra! Tanto faz!");
if (args.length < 1) return reply(`Hmph! Use assim: ${prefix + command} [palavrão]. Um exemplo demonstrativo de como usar: ${prefix + command} puta... Presta atenção, baka!`);
texto = args.join(" ").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
if (isPalavras.includes(texto)) return reply("Hmph! Essa palavra já está na lista de proibições do anti palavra... Verifica direito, viu?! Eu não repito!");
dataGp[0].antipalavrao.palavras.push(texto);
setGp(dataGp);
reply(`Hmph! Palavrão adicionado com sucesso... Consulte a lista, usando: ${prefix}listpalavra. E não me venha com obrigado, não foi por você, tá?!`);
}
};