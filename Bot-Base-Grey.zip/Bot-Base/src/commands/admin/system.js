module.exports = {
nome: ["system"],
executar: async ({
SoDono,
gerarCommandsJSON,
mess,
reply
}) => {

if (!SoDono) return reply(mess.onlyOwner());
const total = gerarCommandsJSON();
reply(`✅ Hmph! ${total} comandos sincronizados... Prontinho, eu que organizei tudo, viu?! Não se acostume!`);
}
};