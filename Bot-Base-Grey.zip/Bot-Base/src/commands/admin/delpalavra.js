module.exports = {
nome: ["delpalavra"],
executar: async ({
args,
command,
dataGp,
g,
isGroup,
isGroupAdmins,
isPalavrao,
isPalavras,
mess,
prefix,
reply,
setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isPalavrao) return reply("Hmph! Anti palavrão desativado! Ative primeiro, bobinho(a), antes de querer remover palavra!");
if (args.length < 1) return reply(`Hmph! Use assim: ${prefix + command} [palavrão]. Um exemplo demonstrativo de como usar: ${prefix + command} puta... Presta atenção, baka!`);
texto = args.join(" ").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
if (!isPalavras.includes(texto)) return reply("Hmph! Essa palavra já foi removida ou nunca esteve na lista de proibições... Verifica direito, viu?! Eu sou boa nisso!");
var i = dataGp[0].antipalavrao.palavras.indexOf(texto);
dataGp[0].antipalavrao.palavras.splice(i, 1);
setGp(dataGp);
reply(`Hmph! Palavrão removido com sucesso da lista... Para verificar se foi removido mesmo, use o comando: ${prefix}listpalavra. Não me agradeça, tá?!`);
}
};