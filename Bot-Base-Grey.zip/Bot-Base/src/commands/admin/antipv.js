module.exports = {
nome: ["antipv"],
executar: async ({
SoDono,
isAntiPv,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isAntiPv) {
nescessario.antipv = true;
setNes(nescessario);
reply(`Hmph! O antipv foi ativado com sucesso. senhor(a)! 🙇🏻‍♂️💖 Não se acostume com isso, viu?! Só fiz porque quis!`);
} else if (isAntiPv) {
nescessario.antipv = false;
setNes(nescessario);
reply("Hmph! O antipv foi desativado com sucesso. senhor(a)! 🙇🏻‍♂️💖 Tanto faz, baka!");
}
}
};