module.exports = {
nome: ["antiligar","antiligacao","antiligação"],
executar: async ({
SoDono,
isAnticall,
mess,
nescessario,
reply,
setNes
}) => {

if (!SoDono) return reply(mess.onlyOwner());
if (!isAnticall) {
nescessario.anticall = true;
setNes(nescessario);
reply(`Hmph! O anticall foi ativado com sucesso. senhor(a)! 🙇🏻‍♂️💖 Não se acostume com isso, viu?! Só fiz porque quis!`);
} else if (isAnticall) {
nescessario.anticall = false;
setNes(nescessario);
reply("Hmph! O anticall foi desativado com sucesso. senhor(a)! 🙇🏻‍♂️💖 Tanto faz, baka!");
}
}
};