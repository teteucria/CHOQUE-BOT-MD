module.exports = {
nome: ["add_ddd"],
executar: async ({
arrayDDDs,
dataGp,
extractStateFromDDD,
isAntiDDD,
isGroup,
isGroupAdmins,
mess,
prefix,
q,
reply,
setGp
}) => {

if (!isGroup) return await reply(mess.onlyGroup());
if (!isGroupAdmins) return await reply(mess.onlyAdmins());
if (!isAntiDDD)
return await reply(
`Hmph! Para usar este comando, você deve ativar o comando: antiddd\nExemplo: ${prefix}antiddd 1... Não é tão difícil assim, viu?!`
);
if (!q.trim())
return await reply(
"Hmph! Determine o DDD que você deseja adicionar na lista... E nada de espaço vazio, viu?! Presta atenção, bobinho(a)!"
);
if (q.trim() === 2)
return await reply(
`Hmph! Um DDD possuí 2 dígitos numéricos, baka! Por exemplo: 81 (Este DDD pertence à Pernambuco)... Eu sou boa nisso, tá?!`
);
if (dataGp[0].ANTI_DDD.listaProibidos.indexOf(q.trim()) >= 0)
return await reply(
`Hmph! Esse DDD já está na lista, bobinho(a)... Confere aí na lista dos DDDs banidos do grupo, use: '${prefix}antiddd-list'`
);
if (arrayDDDs.indexOf(q.trim()) >= 0)
return await reply(
"Hmph! O DDD preenchido é inválido... Não existe nenhum número com este DDD atualmente, baka! Eu conferi, viu?!"
);
dataGp[0].ANTI_DDD.listaProibidos.push(q.trim());
setGp(dataGp);
await reply(
`Prontinho... • O DDD '${q.trim()}' foi adicionado com sucesso à blacklist, agora os números que tiver o DDD de ${extractStateFromDDD(q.trim())} será imediatamente banido do grupo. Hmph! Não fica agradecendo, não é porque eu me importo, tá?!`
);
}
};