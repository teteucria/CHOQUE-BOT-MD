module.exports = {
nome: ["antistatus"],
executar: async ({
  args,
  command,
  dataGp,
  isAntiStatus,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1)
return reply(`Hmph! Use 1 pra ativar ou 0 pra desativar, bobinho(a)... Caso deseje ativar, use: ${prefix + command} 1, e pra desativar é só trocar o 1 pelo 0. Não é difícil, viu?!`);
if (Number(args[0]) === 1) {
if (isAntiStatus) return reply("Hmph! O recurso de anti status já está ativado... Não percebeu, baka?! Tanto faz!");
dataGp[0].antistatus = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o anti status neste grupo... 🙇🏻‍♂️💖️ Eu que fiz todo o trabalho, tá?! Não se acostume, viu?");
} else if (Number(args[0]) === 0) {
if (!isAntiStatus) return reply("Hmph! O recurso de anti status já está desativado... Não percebeu, bobinho(a)?!");
dataGp[0].antistatus = false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o anti status neste grupo... 🙇🏻‍♂️💖 Só fiz porque quis, viu?!");
} else {
reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};