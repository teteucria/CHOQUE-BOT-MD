module.exports = {
nome: ["modo18"],
executar: async ({
  args,
  command,
  dataGp,
  isBotGroupAdmins,
  isGroup,
  isGroupAdmins,
  isModo18,
  mess,
  prefix,
  reply,
  setGp
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (args.length < 1) return reply(`Hmph! Aviso: 1 para ativar, 0 para desativar este recurso de forma global... Não é difícil, bobinho(a)!`);
if (Number(args[0]) === 1) {
if (isModo18) return reply("Hmph! Atualmente este modo já está ativado de forma global... Não percebeu, baka?!");
dataGp[0].porno = true;
setGp(dataGp);
reply("Hmph! Ativou com sucesso o modo+18 neste grupo... Eu que fiz todo o trabalho, viu?! Não se acostume!");
} else if (Number(args[0]) === 0) {
if (!isModo18)
return reply("Hmph! O modo +18 já está desativado nesse grupo... Tanto faz, idiota!");
dataGp[0].porno= false;
setGp(dataGp);
reply("Hmph! Desativou com sucesso o recurso de modo+18 neste grupo... Só fiz porque quis, tá?!");
} else {
reply("Hmph! 1 para ativar, 0 para desativar... É só isso, baka!");
}
}
};