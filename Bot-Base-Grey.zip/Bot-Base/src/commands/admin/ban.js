module.exports = {
nome: ["ban","banir","kick"],
executar: async ({
SoDono,
botNumber,
from,
groupMembers,
isBotGroupAdmins,
isGroupAdmins,
menc_os2,
mentions,
mess,
reply,
text,
kira
}) => {

if (!isGroupAdmins && !SoDono) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
try {
if (!menc_os2) return reply("Hmph! Marque a mensagem do usuário ou marque o @ dele, lembre de só marcar um usuário.. Eu não adivinho, baka!");
if (!JSON.stringify(groupMembers).includes(menc_os2))
return reply("Hmph! Este usuário já foi removido do grupo ou saiu... Não percebeu, bobinho(a)?!");
if (botNumber.includes(menc_os2))
return reply("Hmph! Não sou besta de remover eu mesma... P-por que você me pediria isso, idiota?!");
if (JSON.stringify(SoDono).indexOf(menc_os2) >= 0)
return reply("Hmph! Não posso remover meu dono(a)! 🤧 Jamais, baka!");
await kira.sendMessage(from, {text: `Hmph! @${menc_os2.split("@")[0]} foi removido por motivos justos... Eu que cuidei disso, viu?! Não agradeça!`, mentions: [menc_os2]});
await kira.groupParticipantsUpdate(from, [menc_os2], "remove");
} catch (error) {
reply(mess.error());
}
}
};