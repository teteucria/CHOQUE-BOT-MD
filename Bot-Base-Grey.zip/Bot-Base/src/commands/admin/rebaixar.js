module.exports = {
nome: ["rebaixar"],
executar: async ({
from,
groupMembers,
isBotGroupAdmins,
isGroupAdmins,
menc_os2,
mentions,
mess,
reply,
kira
}) => {

if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
if (!menc_os2) return reply("Hmph! Marque a mensagem do usuário ou marque o @ dele.., lembre de só marcar um usuário... Eu não adivinho, baka!");
if (!JSON.stringify(groupMembers).includes(menc_os2))
return reply("Hmph! Este usuário foi removido do grupo ou saiu, não será possível rebaixar... Tanto faz, bobinho(a)!");
kira.sendMessage(from, {text: `Hmph! @${menc_os2.split("@")[0]} foi rebaixado para membro com sucesso... Eu que cuidei disso, viu?! Não se acostume!`, mentions: [menc_os2]});
kira.groupParticipantsUpdate(from, [menc_os2], "demote");
}
};