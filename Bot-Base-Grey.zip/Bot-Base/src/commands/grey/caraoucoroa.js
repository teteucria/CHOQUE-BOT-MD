module.exports={nome:["caracoroa","caraoucoroa"],categoria:"grey",executar:async({reply})=>{
reply("🪙 *CARÁ OU COROA*\n\nResultado: *"+(Math.random()<.5?"CARA":"COROA")+"*");
}};