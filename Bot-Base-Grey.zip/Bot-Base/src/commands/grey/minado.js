const {game}=require("../../utils/greyPack");
function novo(){const cells=["a1","a2","a3","a4","b1","b2","b3","b4","c1","c2","c3","c4","d1","d2","d3","d4"];const mines=[];while(mines.length<4){const x=cells[Math.floor(Math.random()*cells.length)];if(!mines.includes(x))mines.push(x)}return {mines,open:[],tries:3}}
module.exports={nome:["minado","mines"],categoria:"grey",executar:async({q,reply,sender})=>{
let g=game("minado");
if(!g){g=novo();g.player=sender;game("minado",g);return reply("💣 *MINADO*\n\nJogo iniciado! Use `minado a1` para abrir uma coordenada.\nVocê tem *3 tentativas*.");}
if(!q)return reply(`💣 Coordenadas abertas: ${g.open.join(", ")||"nenhuma"}\nTentativas: *${g.tries}*`);
const c=q.trim().toLowerCase().split(/\s+/)[0]; if(!/^[a-d][1-4]$/.test(c))return reply("❌ Coordenada inválida. Use a1 até d4.");
if(g.open.includes(c))return reply("⚠️ Essa coordenada já foi aberta.");
if(g.mines.includes(c)){g.tries--;if(g.tries<=0){game("minado",null);return reply("💥 *BOOM!* Você perdeu o jogo.");}game("minado",g);return reply(`💥 *MINA!*\nTentativas restantes: *${g.tries}*`);}
g.open.push(c);if(g.open.length>=12){game("minado",null);return reply("🏆 *VOCÊ VENCEU O MINADO!*");}game("minado",g);reply(`✅ ${c} está livre!\nAcertos: *${g.open.length}/12*`);}};
