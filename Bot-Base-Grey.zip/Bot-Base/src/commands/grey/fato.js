module.exports={nome:["fato","fatos"],categoria:"grey",executar:async({reply})=>{
const a=["A luz do Sol leva cerca de 8 minutos e 20 segundos para chegar à Terra.","Polvos possuem três corações.","A água pode existir naturalmente nos estados sólido, líquido e gasoso.","O Brasil é o maior país da América do Sul.","Um dia sideral dura aproximadamente 23 h 56 min."];
reply("🧠 *FATO ALEATÓRIO*\n\n"+a[Math.floor(Math.random()*a.length)]);
}};