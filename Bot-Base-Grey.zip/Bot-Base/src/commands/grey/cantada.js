module.exports={nome:["cantada","cantadas"],categoria:"grey",executar:async({reply})=>{
const a=["Você é Wi‑Fi? Porque senti uma conexão.","Se beleza fosse tempo, você seria eternidade.","Seu nome é Google? Porque você tem tudo o que eu procuro.","Você não é mapa, mas me deixou sem direção.","Se eu pudesse rearranjar o alfabeto, colocaria U e I juntos."];
reply("💘 *CANTADA GREY*\n\n"+a[Math.floor(Math.random()*a.length)]);
}};