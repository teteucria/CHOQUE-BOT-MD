const {user,saveUser,xp}=require("../../utils/greyPack");
module.exports={nome:["daily","diario"],categoria:"grey",executar:async({sender,pushname,reply})=>{
const u=user(sender,pushname), now=Date.now(), day=86400000;
if(now-u.lastDaily<day) return reply(`⏳ Você já pegou seu prêmio hoje. Volte em *${Math.ceil((day-(now-u.lastDaily))/3600000)}h*.`);
const premio=50+Math.floor(Math.random()*101); u.money+=premio; u.lastDaily=now; saveUser(u); xp(u,20);
reply(`🎁 *DAILY*\n\nVocê recebeu *${premio} coins* e *20 XP*!`);
}};