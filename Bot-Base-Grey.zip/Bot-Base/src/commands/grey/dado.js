module.exports={nome:["dado"],categoria:"grey",executar:async({args,reply})=>{
let lados=Math.max(2,Math.min(100,Number(args?.[0])||6)); let n=Math.floor(Math.random()*lados)+1;
reply(`🎲 *DADO*\n\nD${lados}: *${n}*`);
}};