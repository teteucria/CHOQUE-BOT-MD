const {user}=require("../../utils/greyPack");
module.exports={nome:["saldo","coins","dinheiro"],categoria:"grey",executar:async({sender,pushname,reply})=>{
const u=user(sender,pushname); reply(`💰 *CARTEIRA*\n\n👤 ${u.nome}\n💵 Coins: *${u.money}*\n⭐ Nível: *${u.level}*\n✨ XP: *${u.xp}/${u.level*100}*`);
}};