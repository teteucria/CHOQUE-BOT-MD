const {game}=require("../../utils/greyPack");
const palavras=[["PARADOXO","CANAL"],["ESCADA","OBJETO"],["BANANA","COMIDA"],["YOUTUBE","APLICATIVO"],["PORTUGAL","PAÍS"],["MACACO","ANIMAL"],["LASANHA","COMIDA"],["CAVALO","ANIMAL"],["SATURNO","PLANETA"],["INSTAGRAM","APLICATIVO"]];
function embaralhar(s){return s.split("").sort(()=>Math.random()-.5).join("")}
module.exports={nome:["anagrama"],categoria:"grey",executar:async({sender,reply,q})=>{
let g=game("anagrama");
if(g && q && q.toUpperCase().replace(/[ÁÀÃÂ]/g,"A")===g.answer)return game("anagrama",null),reply(`🎯 Acertou! Era *${g.answer}*.`); 
if(g && q)return reply("❌ Ainda não. Tente outra vez.");
const p=palavras[Math.floor(Math.random()*palavras.length)]; game("anagrama",{answer:p[0],dica:p[1],player:sender});
reply(`🔤 *ANAGRAMA*\n\nDescubra: *${embaralhar(p[0])}*\n💡 Dica: ${p[1]}\n\nResponda com a palavra.`);
}};