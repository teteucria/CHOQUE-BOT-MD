module.exports={nome:["8ball","bola8"],categoria:"grey",executar:async({q,reply})=>{
if(!q) return reply("🔮 Faça uma pergunta. Ex.: 8ball vou ganhar?");
const a=["Sim.","Não.","Provavelmente.","Com certeza.","Melhor não contar com isso.","As chances são boas.","Não dá para saber ainda.","Pergunte novamente depois."];
reply("🔮 *8BALL*\n\n"+a[Math.floor(Math.random()*a.length)]);
}};