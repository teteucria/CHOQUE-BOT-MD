module.exports={nome:["conselho","conselhos"],categoria:"grey",executar:async({reply})=>{
const a=["Não tome decisões importantes no calor da raiva.","Comece pequeno, mas comece.","Nem todo atraso é fracasso.","Se algo depende só de você, dê o primeiro passo.","Descansar também faz parte do progresso."];
reply("🧠 *CONSELHO*\n\n"+a[Math.floor(Math.random()*a.length)]);
}};