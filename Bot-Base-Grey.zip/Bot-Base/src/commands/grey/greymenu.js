module.exports={nome:["greymenu","menugrey"],categoria:"grey",executar:async({prefix,NomeDoBot,pushname,reply})=>{
reply(`╭━━━〔 🩶 *${NomeDoBot} GREY* 〕━━━╮
┃ 👤 Usuário: *${pushname||"Usuário"}*
┃ ⚙️ Prefixo: *${prefix}*
╰━━━━━━━━━━━━━━━━━━━━━━╯

『 🩶 GREY PACK 』
• ${prefix}cantada
• ${prefix}conselho
• ${prefix}fato
• ${prefix}caracoroa
• ${prefix}dado
• ${prefix}8ball
• ${prefix}anagrama
• ${prefix}minado
• ${prefix}saldo
• ${prefix}daily
• ${prefix}rankcoins

『 🎮 BASE 』
• ${prefix}velha
• ${prefix}ping
• ${prefix}figaleatoria
• ${prefix}tiktok
• ${prefix}play
• ${prefix}clima

Use *${prefix}menu* para o menu completo.`);
}};