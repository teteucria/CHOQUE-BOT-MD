const {allUsers}=require("../../utils/greyPack");
module.exports={nome:["rankcoins","rankingcoins"],categoria:"grey",executar:async({reply})=>{
const top=allUsers().sort((a,b)=>b.money-a.money).slice(0,10);
if(!top.length)return reply("🏆 Ainda não há jogadores.");
reply("🏆 *RANKING DE COINS*\n\n"+top.map((u,i)=>`${i+1}. ${u.nome||"Usuário"} — *${u.money}*`).join("\n"));
}};