module.exports = {
nome: ["brincadeiras", "brincadeira"],
executar: async ({
kira, reagir, prefix, from, NomeDoBot,
emojimenu, pushname, isCargo, date,
hora, logos, linguagem, selo}) => {

await reagir(from, "🎰");
await kira.sendMessage(from, {interactiveMessage: {
title: linguagem.brincadeiras(NomeDoBot, pushname, isCargo, hora, prefix, date, emojimenu),
footer: `🖤 KIRA SYSTEM 🤍`,
buttons: [
{
name: "single_select",
buttonParamsJson: JSON.stringify({
title: "🤍 𝗠𝗘𝗡𝗨𝗦 🖤",
sections: [
{
title: `🤍 Comandos completos`,
highlight_label: `${emojimenu}`,
rows: [{ title: "🤍 menu completo 🖤", description: "todos os comandos, num só lugar.", id: `${prefix}menup`, disabled: false }]
},
{
title: `🖤 Só pro dono`,
highlight_label: `${emojimenu}`,
rows: [{ title: "🖤 menu owner 🤍", description: "comandos restritos a quem manda em mim.", id: `${prefix}menudono`, disabled: false }]
},
{
title: `🤍 Administração`,
highlight_label: `${emojimenu}`,
rows: [{ title: "🤍 menu admin 🖤", description: "cuida do grupo do seu jeito.", id: `${prefix}menuadm`, disabled: false }]
},
{
title: `🖤 Diversão`,
highlight_label: `${emojimenu}`,
rows: [{ title: "🖤 menu diversão 🤍", description: "pra descontrair com o grupo.", id: `${prefix}brincadeiras`, disabled: false }]
},
{
title: `🤍 Logos & estilo`,
highlight_label: `${emojimenu}`,
rows: [{ title: "🤍 menu logos 🖤", description: "crie artes com texto do seu jeito.", id: `${prefix}menulogos`, disabled: false }]
},
{
title: `🖤 Casais`,
highlight_label: `${emojimenu}`,
rows: [{ title: "🖤 menu casais 🤍", description: "pra quem gosta de um clima a dois.", id: `${prefix}menutinder`, disabled: false }]
},
{
title: `🤍 Animes`,
highlight_label: `${emojimenu}`,
rows: [{ title: "🤍 menu animes 🖤", description: "imagens selecionadas pra você.", id: `${prefix}menuanimes`, disabled: false }]
}
]
})
}
],
image: {url: logos.img},
ai: true}}, {quoted: selo});
}
};