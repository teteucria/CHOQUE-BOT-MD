const path = require("path");
const fs = require("fs-extra");

class CommandRegistry {
  constructor() {
    this.commands = new Map();
    this.aliases = new Map();
    this.categories = new Map();
  }

  register(command) {

    const rawNomes = command.nome || command.name || [];
    const names = Array.isArray(rawNomes) ? rawNomes : [rawNomes];

    if (!names.length || !names[0] || typeof names[0] !== "string") {
      return false;
    }

    const primaryName = names[0].toLowerCase();

    const cmd = {
      ...command,
      name: primaryName,
      aliases: names.slice(1).map(n => n.toLowerCase()),
      category: command.category || "general",
      description: command.description || "",
      usage: command.usage || "",
      ownerOnly: !!command.ownerOnly,
      groupOnly: !!command.groupOnly,
      adminOnly: !!command.adminOnly,
      botAdminOnly: !!command.botAdminOnly,
    };

    this.commands.set(primaryName, cmd);
    for (const alias of cmd.aliases) {
      this.aliases.set(alias, primaryName);
    }

    if (!this.categories.has(cmd.category)) {
      this.categories.set(cmd.category, []);
    }
    this.categories.get(cmd.category).push(cmd);

    return true;
  }

  get(name) {
    const normalized = name.toLowerCase();
    if (this.commands.has(normalized)) return this.commands.get(normalized);
    if (this.aliases.has(normalized)) return this.commands.get(this.aliases.get(normalized));
    return null;
  }

  getAll() {
    return Array.from(this.commands.values());
  }

  getByCategory(category) {
    return this.categories.get(category) || [];
  }

  getCategories() {
    return Array.from(this.categories.keys());
  }

  async loadFromDirectory(dirPath) {
    let count = 0;
    const scan = (dir) => {
      if (!fs.existsSync(dir)) return;
      const files = fs.readdirSync(dir);
      for (const file of files) {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          scan(fullPath);
          continue;
        }
        if (!file.endsWith(".js")) continue;
        if (file === "registry.js" || file === "dispatcher.js") continue;
        try {
          const cmd = require(fullPath);
          if (this.register(cmd)) count++;
        } catch (err) {
          console.error(`[CommandRegistry] Falha ao carregar ${fullPath}:`, err.message);
        }
      }
    };
    scan(dirPath);
    return count;
  }
}

module.exports = new CommandRegistry();