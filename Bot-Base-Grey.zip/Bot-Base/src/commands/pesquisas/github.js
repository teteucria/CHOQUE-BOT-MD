module.exports = {
nome: ["github","githubsearch"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Nome do repo? Exemplo: *${prefix + command} baileys*`);
reagir(from, "💻");
try {
const res = await fetchJson(`${API_kira}/github-search?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const repos = res.dados || res.resultados || res.resultado || [];
const lista = (Array.isArray(repos) ? repos : [repos]).slice(0, 8)
.map((r, i) => `*${i + 1}.* ${r.nome || r.name || r.full_name}\n ⭐ Stars: ${r.stars || r.stargazers_count || "?"}\n 🔗 Link : ${r.link || r.html_url || r.url}`)
.join("\n\n");
reply(`*💻 GITHUB SEARCH 🛠️*\nHmph! Dev olhando GitHub, né? Eu não julgo... eu ajudo! 😼\n\n*🔍 Busca:* ${q}\n*📦 Repositórios:*\n\n${lista}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! O GitHub ignorou a gente..."); }
}
};
