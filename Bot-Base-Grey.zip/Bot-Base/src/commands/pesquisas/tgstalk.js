module.exports = {
nome: ["tgstalk"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual @ do Telegram? Exemplo: *${prefix + command} telegram*`);
reagir(from, "✈️");
try {
const user = q.replace("@", "");
const res = await fetchJson(`${API_kira}/stalk/telegram?username=${encodeURIComponent(user)}&apitoken=${KEY_kira}`);
const r = res.resultado || {};
const legenda = `✈️ *Nome:* *${r.title || "?"}*\n🆔 *Usuário:* *@${user}*\n📝 *Descrição:*\n${r.description || ""}\n\n🔗 ${r.url || ""}`;
if (r.image_url) await kira.sendMessage(from, { image: { url: r.image_url }, caption: legenda }, { quoted: info });
else reply(legenda);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Esse perfil do Telegram não existe..."); }
}
};
