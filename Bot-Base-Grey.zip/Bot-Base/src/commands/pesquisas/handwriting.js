module.exports = {
nome: ["handwriting"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Escrever o quê? Exemplo: *${prefix + command} eu te amo*`);
reagir(from, "✍️");
try {
const res = await fetchJson(`${API_kira}/info/handwriting?text=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const b64 = (res.resultado || "").split(",")[1];
if (!b64) return reply("Hmph! Não consegui gerar... tenta de novo, baka!");
const img = Buffer.from(b64, "base64");
await kira.sendMessage(from, { image: img, caption: "Hmph! Escrito com todo o meu carinho... n-não se acostume, tá?! ✍️" }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A caligrafia falhou..."); }
}
};
