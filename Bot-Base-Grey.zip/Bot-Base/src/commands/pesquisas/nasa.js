module.exports = {
nome: ["nasa"],
executar: async ({
from, info, reagir, reply, fetchJson, kira, API_kira, KEY_kira
}) => {
reagir(from, "🚀");
try {
const res = await fetchJson(`${API_kira}/nasa-apod?apitoken=${KEY_kira}`);
const r = res.resultado || {};
const foto = r.hdurl || r.url || "";
const explicacao = (r.explanation || "").slice(0, 400);
if (foto) {
await kira.sendMessage(from, { image: { url: foto }, caption: `*🚀 NASA APOD 🌌*\nHmph! O espaço é lindo demais... u-uau! ✨\n\n*📅 Data:* ${r.date || ""}\n*🪐 Título:* ${r.title || ""}\n*👨‍🚀 Autor:* ${r.copyright || "NASA"}\n\n${explicacao}` }, { quoted: info });
} else {
reply(`*🚀 NASA APOD 🌌*\n*📅 Data:* ${r.date || ""}\n*🪐 Título:* ${r.title || ""}\n\n${explicacao || "A foto não veio hoje, baka..."}`);
}
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A NASA não quis responder... tenta de novo!"); }
}
};
