module.exports = {
nome: ["wikipedia","wiki"],
executar: async ({
axios,
mess,
q,
  prefix,
  command,
reply
}) => {

try {
if (!q) return reply(`Hmph! Exemplo: *${prefix + command} JavaScript*... Até eu, que sou a melhor da academia, preciso de um tema pra pesquisar, baka!`);
reply(`Hmph! Aguarda aí que tô pesquisando... N-não é como se eu fizesse isso por qualquer um, tá?!`);
wikip = await axios.get(`https://pt.wikipedia.org/w/api.php?action=query&format=json&list=search&srsearch=${encodeURIComponent(q)}&prop=info&inprop=url`);
wikis = await axios.get(`https://pt.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&redirects=1&pageids=${wikip.data.query.search[0].pageid}`);
reply(mess.wikiResposta(wikis));
} catch (error) {
reply(mess.error());
}
}
};