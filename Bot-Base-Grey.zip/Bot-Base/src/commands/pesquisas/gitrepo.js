module.exports = {
nome: ["gitrepo"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q || !q.includes("github.com")) return reply(`Hmph! Manda o link do repositório... Exemplo: *${prefix + command} https://github.com/WhiskeySockets/Baileys*`);
reagir(from, "💻");
try {
const res = await fetchJson(`${API_kira}/github-repo?url=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const d = res.dados || {};
reply(`*📦 GITHUB REPO 💻*\nHmph! Código alheio é o que você gosta, né?! 😏\n\n*📦 Nome:* ${d.name || "?"}\n*🧾 Full:* ${d.fullName || ""}\n*✏️ Descrição:* ${(d.description || "sem descrição.").slice(0,200)}\n*⭐ Stars:* ${d.stars || "?"}\n*🍴 Forks:* ${d.forks || "?"}\n*🐞 Issues:* ${d.issues || "?"}\n*🛠️ Linguagem:* ${d.language || "?"}\n*📜 Licença:* ${d.license || "?"}\n*👤 Dono:* ${d.owner?.login || ""}\n*🔗 Link:* ${d.url || ""}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não achei esse repositório..."); }
}
};
