module.exports = {
nome: ["clima","previsao"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! De qual cidade? Exemplo: *${prefix + command} são paulo*`);
reagir(from, "🌦️");
try {
const res = await fetchJson(`${API_kira}/info/weather?city=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const r = res.resultado?.result || {};
const atual = r.current_condition?.[0] || {};
const area = r.nearest_area?.[0] || {};
const nomeArea = area.areaName?.[0]?.value || q;
const tempo = atual.weatherDesc?.[0]?.value || "indisponível";
reply(`*🌦️ CLIMA AGORA 🌦️*\nHmph! Agora não tem desculpa pra sair sem casaco, bobinho(a)! ☔\n\n*🌆 Cidade:* ${nomeArea} (${area.country?.[0]?.value || ""})\n*☁️ Tempo:* ${tempo}\n*🌡️ Temperatura:* ${atual.temp_C || "?"}°C (${atual.temp_F || "?"}°F)\n*🤔 Sensação:* ${atual.FeelsLikeC || "?"}°C\n*💧 Umidade:* ${atual.humidity || "?"}%\n*💨 Vento:* ${atual.windspeedKmph || "?"} km/h\n*🕐 Observado às:* ${atual.observation_time || ""}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não achei o clima dessa cidade..."); }
}
};
