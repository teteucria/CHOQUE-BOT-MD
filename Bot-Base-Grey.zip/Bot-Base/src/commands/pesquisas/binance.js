module.exports = {
nome: ["binance"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "📊");
try {
const res = await fetchJson(`${API_kira}/binance?apitoken=${KEY_kira}`);
const moedas = (res.resultados || []).slice(0, 10)
.map((m, i) => `*${i + 1}.* ${m.symbol}\n 💰 Preço: *${m.lastPrice || "?"}* (${m.priceChangePercent || "?"}%)\n 📈 Alta: ${m.highPrice || "?"} • 📉 Baixa: ${m.lowPrice || "?"}`)
.join("\n\n");
reply(`*📊 BINANCE 📈*\nMercado ao vivo, direto do futuro! 🚀\n\n*💰 Moedas:*\n\n${moedas || "Nada por aqui, baka!"}\n\nHmph! Investe com cuidado, viu?! Não quero você no prejuízo... 🥺`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A Binance travou..."); }
}
};
