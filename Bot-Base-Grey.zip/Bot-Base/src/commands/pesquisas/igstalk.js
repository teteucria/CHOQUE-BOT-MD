module.exports = {
nome: ["igstalk"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Manda o @ da pessoa... Exemplo: *${prefix + command} usuario*`);
reagir(from, "🕵️");
try {
const user = q.replace("@", "").trim();
const res = await fetchJson(`${API_kira}/ig-stalk?username=${encodeURIComponent(user)}&apitoken=${KEY_kira}`);
const r = res.resultado?.resultado || res.resultado || res;
if (r.error || r.not_found) { reagir(from, "❌"); return reply(`Hmph! O perfil *@${user}* não existe ou tá privado, baka!`); }
const legenda = `\n🕵️ *Nome:* *${r.nome || r.name || r.nickname || r.fullname || user}*\n🆔 *Usuário:* *@${r.usuario || r.username || user}*\n📈 *Seguidores:* *${r.seguidores || r.followers || "?"}*\n👣 *Seguindo:* *${r.seguindo || r.following || "?"}*\n📸 *Posts:* *${r.posts || r.videos || "?"}*\n\n${r.bio || r.descricao || r.biography || ""}`;
const foto = r.foto || r.avatar || r.profilePic || r.profile_pic_hd || r.profile_image || r.image_url;
if (foto) await kira.sendMessage(from, { image: { url: foto }, caption: legenda }, { quoted: info });
else reply(legenda);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Esse perfil não existe ou tá privado, baka!"); }
}
};
