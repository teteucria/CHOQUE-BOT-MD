const LOGOS_2TEXTOS = {
"wolfgalaxy": "/ephoto/wolf-galaxy",
"freefire": "/ephoto/free-fire",
"apexlegends": "/ephoto/apex-legends",
"deadpoollogo": "/ephoto360/deadpool-logo",
"thorlogo": "/ephoto360/thor-logo",
"starwarsmascot": "/ephoto360/star-wars-mascot",
"teamlogobw": "/ephoto360/team-logo-bw",
"bearlogo": "/ephoto360/bear-logo",
"footballlogo": "/ephoto360/football-logo",
"blackpinklogo2": "/ephoto360/blackpink-logo2",
"assassingaming": "/ephoto360/assassin-gaming",
"fpsgaming": "/ephoto360/fps-gaming",
"blueneonlogo": "/ephoto360/blue-neon-logo",
"metalmascot": "/ephoto360/metal-mascot",
"circlemascot": "/ephoto360/circle-mascot",
"companylogo": "/ephoto360/company-logo",
"gradient3dlogo": "/ephoto360/gradient-3d-logo",
"textlogo": "/ephoto360/text-logo",
"luxurylogo": "/ephoto360/luxury-logo",
"minimallogo": "/ephoto360/minimal-logo",
"astronautlogo": "/ephoto360/astronaut-logo",
"teamlogo": "/ephoto360/team-logo",
"avengers3d": "/ephoto360/avengers-3d",
"marvellogo": "/ephoto360/marvel-logo",
"bwlayerlogo": "/ephoto360/bw-layer-logo",
"metallogo": "/ephoto360/metal-logo",
"gamergirlmascot": "/ephoto360/gamer-girl-mascot",
"captainamerica": "/ephoto360/captain-america"
};

module.exports = {
nome: ["wolfgalaxy", "freefire", "apexlegends", "deadpoollogo", "thorlogo", "starwarsmascot", "teamlogobw", "bearlogo", "footballlogo", "blackpinklogo2", "assassingaming", "fpsgaming", "blueneonlogo", "metalmascot", "circlemascot", "companylogo", "gradient3dlogo", "textlogo", "luxurylogo", "minimallogo", "astronautlogo", "teamlogo", "avengers3d", "marvellogo", "bwlayerlogo", "metallogo", "gamergirlmascot", "captainamerica"],
executar: async ({
q,
from,
info,
command,
reply,
reagir,
kira,
API_kira,
KEY_kira
}) => {
if (!q || !q.includes("|")) return reply(`Hmph! Esse efeito precisa de *DOIS* textos, separados por *|*\n\nExemplo: *${"!" + command} kira|Sys*\n\nPresta atenção da próxima vez, bobinho(a)!`);
const [texto1, texto2] = q.split("|").map((t) => t.trim());
if (!texto1 || !texto2) return reply("Hmph! Faltou um dos textos... manda assim: *texto1|texto2*");
if (texto1.length > 25 || texto2.length > 25) return reply("Hmph! Cada texto pode ter no máximo 25 caracteres!");
reagir(from, "🎨");
try {
const rota = LOGOS_2TEXTOS[command];
await kira.sendMessage(from, { image: { url: `${API_kira}${rota}?text1=${encodeURIComponent(texto1)}&text2=${encodeURIComponent(texto2)}&apitoken=${KEY_kira}` } }, { quoted: info });
reagir(from, "✅");
} catch (e) {
console.log(e);
reagir(from, "❌");
reply("Hmph! Deu ruim na hora de gerar... tenta de novo!");
}
}
};