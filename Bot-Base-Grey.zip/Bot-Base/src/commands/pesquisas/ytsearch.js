module.exports = {
nome: ["ytsearch","pesquisa-ytb"],
executar: async ({
mess,
q,
reply,
yts
}) => {

if (q.trim().length < 4) return reply(`Hmph! Você esqueceu de colocar algum texto após o comando... Presta atenção, bobinho(a), até eu fico impaciente!`);
try {
const searchUrl = await yts(q);
const ABC = searchUrl.videos;
RST = ABC.map((v, index) =>
`*${index + 1}.* Título: *${v.title || "Não encontrado"}*\n• Descrição: *${v.description || "Não encontrado"}*\n• Duração: *${v.duration.timestamp || "Não encontrado"}*\n• Link: *${v.url || "Não encontrado"}*`
).join("\n–\n");
reply(`Hmph! Achei os resultados pra você... n-não se acostume, baka!\n> YouTube Search:\n–\n` + RST);
} catch (error) {
return reply(mess.error());
}
}
};