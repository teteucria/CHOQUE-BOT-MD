module.exports = {
nome: ["plaq10"],
executar: async ({
args, buffer, from, getBuffer, prefix, pushname, q, reagir, reply, selo, sender, kira, API_kira, KEY_kira
}) => {
if (args.length < 1) return reply("❕Hmph! Ei, humano... cadê o texto? N-não me faça esperar, baka!");
if (q.length > 25) return reply("❗Hmph! O texto tá longo demais... O máximo é 25 caracteres, bobinho(a). Até eu, que sou a melhor da academia, respeito as regras, viu?!");
reagir(from, "🥵");
buffer = await getBuffer(`${API_kira}/plaquinha10?nick=uzuback&apitoken=${KEY_kira}`);
await kira.sendMessage(sender, { image: buffer }, { quoted: selo });
reply(`Hmph! Eai, ${pushname}, preparado(a)? Tô enviando agora... verifica seu PV, tá?! N-não é como se eu me importasse... 😈🔥`);
}
};
