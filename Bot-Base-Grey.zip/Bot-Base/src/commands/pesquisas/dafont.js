module.exports = {
nome: ["dafont"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual fonte? Exemplo: *${prefix + command} orbitron*`);
reagir(from, "🔤");
try {
const res = await fetchJson(`${API_kira}/dafont?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const fontes = (res.dados || [])
.filter((f, i, a) => a.findIndex(x => x.linkFonte === f.linkFonte) === i)
.slice(0, 8)
.map((f, i) => `*${i + 1}.* ${f.fonte}\n 🎨 ${f.style || ""}\n 🔗 ${f.linkFonte}`)
.join("\n\n");
reply(`*🔤 DAFONT 🖋️*\nHmph! Fontes lindas pra deixar seu design top! 🎨\n\n*🔍 Busca:* ${q}\n*🖋️ Fontes:*\n\n${fontes || "Nenhuma fonte encontrada, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A busca de fontes falhou..."); }
}
};
