const LOGOS_1TEXTO = {
"3dcomic": "/ephoto360/3d-comic",
"typographymultilayers": "/ephoto360/typography-multi-layers",
"dragonball": "/ephoto360/dragon-ball",
"narutoshippuden": "/ephoto360/naruto-shippuden",
"3dfoilballoon": "/ephoto360/3d-foil-balloon",
"glossysilver3d": "/ephoto360/glossy-silver-3d",
"colorfulneonlight": "/ephoto360/colorful-neon-light",
"blackpinkbornpink": "/ephoto360/blackpink-born-pink",
"typographypavement": "/ephoto360/typography-pavement",
"pixelglitch": "/ephoto360/pixel-glitch",
"neonglitch": "/ephoto360/neon-glitch",
"digitalglitch": "/ephoto360/digital-glitch",
"erasertext": "/ephoto360/eraser-text",
"blackpinklogo": "/ephoto360/blackpink-logo",
"glowingtext": "/ephoto360/glowing-text",
"3dbeachtext": "/ephoto360/3d-beach-text",
"3dunderwater": "/ephoto360/3d-underwater",
"foggyglass": "/ephoto360/foggy-glass",
"vintagetv": "/ephoto360/vintage-tv",
"cartoongraffiti": "/ephoto360/cartoon-graffiti",
"graffitiwall": "/ephoto360/graffiti-wall",
"embroidery": "/ephoto360/embroidery",
"3dpapercut": "/ephoto360/3d-paper-cut",
"glittertext": "/ephoto360/glitter-text",
"watercolortext": "/ephoto360/watercolor-text",
"futuristiclight": "/ephoto360/futuristic-light",
"cloudssky": "/ephoto360/clouds-sky",
"vintagebulb": "/ephoto360/vintage-bulb",
"3dgradient": "/ephoto360/3d-gradient",
"sandbeach": "/ephoto360/sand-beach",
"luxurygold": "/ephoto360/luxury-gold",
"neonsignatures": "/ephoto360/neon-signatures",
"wetglass": "/ephoto360/wet-glass",
"sandbeach2": "/ephoto360/sand-beach-2",
"retroneon": "/ephoto360/retro-neon",
"fireworks": "/ephoto360/fireworks",
"1917style": "/ephoto360/1917-style",
"neongalaxy": "/ephoto360/neon-galaxy",
"royaltext": "/ephoto360/royal-text",
"doubleexposure": "/ephoto360/double-exposure",
"hollywoodstar": "/ephoto360/hollywood-star",
"3dhologram": "/ephoto360/3d-hologram",
"galaxyname": "/ephoto360/galaxy-name",
"greenneon": "/ephoto360/green-neon",
"glossychrome": "/ephoto360/glossy-chrome",
"metalavatar": "/ephoto360/metal-avatar",
"goldtext": "/ephoto360/gold-text",
"moderngold": "/ephoto360/modern-gold",
"capercut": "/ephoto360/caper-cut",
"matrixtext": "/ephoto360/matrix-text",
"greenbrush": "/ephoto360/green-brush",
"nightlend": "/ephoto360/night-lend",
"zombie3d": "/ephoto360/zombie-3d",
"writingcakes": "/ephoto360/writing-cakes",
"dragonfire": "/ephoto360/dragon-fire",
"noelchristmas": "/ephoto360/noel-christmas",
"thundertext": "/ephoto360/thunder-text",
"blackpinksignatures": "/ephoto360/blackpink-signatures",
"arrowsignature": "/ephoto360/arrow-signature",
"americanflag3d": "/ephoto360/american-flag-3d",
"roundthunder": "/ephoto360/round-thunder",
"3dcastle": "/ephoto360/3d-castle",
"3dsmartphone": "/ephoto360/3d-smartphone",
"typographyavatar": "/ephoto360/typography-avatar",
"blueneonavatar": "/ephoto360/blue-neon-avatar",
"graffitigirl": "/ephoto360/graffiti-girl",
"pornhubstyle": "/ephoto360/pornhub-style",
"tiktoktext": "/ephoto360/tiktok-text",
"3dcolorfulpaint": "/ephoto360/3d-colorful-paint",
"trianglemountain": "/ephoto360/triangle-mountain",
"watercolorpainting": "/ephoto360/watercolor-painting",
"portraitfence": "/ephoto360/portrait-fence",
"galaxywallpaper": "/ephoto360/galaxy-wallpaper"
};

module.exports = {
nome: ["3dcomic", "typographymultilayers", "dragonball", "narutoshippuden", "3dfoilballoon", "glossysilver3d", "colorfulneonlight", "blackpinkbornpink", "typographypavement", "pixelglitch", "neonglitch", "digitalglitch", "erasertext", "blackpinklogo", "glowingtext", "3dbeachtext", "3dunderwater", "foggyglass", "vintagetv", "cartoongraffiti", "graffitiwall", "embroidery", "3dpapercut", "glittertext", "watercolortext", "futuristiclight", "cloudssky", "vintagebulb", "3dgradient", "sandbeach", "luxurygold", "neonsignatures", "wetglass", "sandbeach2", "retroneon", "fireworks", "1917style", "neongalaxy", "royaltext", "doubleexposure", "hollywoodstar", "3dhologram", "galaxyname", "greenneon", "glossychrome", "metalavatar", "goldtext", "moderngold", "capercut", "matrixtext", "greenbrush", "nightlend", "zombie3d", "writingcakes", "dragonfire", "noelchristmas", "thundertext", "blackpinksignatures", "arrowsignature", "americanflag3d", "roundthunder", "3dcastle", "3dsmartphone", "typographyavatar", "blueneonavatar", "graffitigirl", "pornhubstyle", "tiktoktext", "3dcolorfulpaint", "trianglemountain", "watercolorpainting", "portraitfence", "galaxywallpaper"],
executar: async ({
q,
from,
info,
command,
prefix,
reply,
reagir,
kira,
API_kira,
KEY_kira
}) => {
if (!q) return reply(`Hmph! Cadê o texto, baka?\n\nExemplo: *${prefix + command} kira*\n\nN-não é como se eu quisesse fazer sua logo... mas manda logo o texto!`);
if (q.length > 30) return reply("Hmph! Texto grande demais... máximo 30 caracteres, bobinho(a)!");
reagir(from, "🎨");
try {
const rota = LOGOS_1TEXTO[command];
await kira.sendMessage(from, { image: { url: `${API_kira}${rota}?text1=${encodeURIComponent(q)}&apitoken=${KEY_kira}` } }, { quoted: info });
reagir(from, "✅");
} catch (e) {
console.log(e);
reagir(from, "❌");
reply("Hmph! A API travou... tenta de novo, baka!");
}
}
};