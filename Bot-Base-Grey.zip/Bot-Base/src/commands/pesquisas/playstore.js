module.exports = {
nome: ["playstore"],
executar: async ({
fetchJson,
from,
image,
q,
reagir,
reply,
selo,
kira,
API_kira,
KEY_kira
}) => {

{
if (!q) return reply("Hmph! Cadê o título do APK que você quer pesquisar? N-não é porque eu me importo, é que preciso do nome pra procurar, baka!");
await reagir(from, "🌟");
try {
const response = await fetchJson(`${API_kira}/playstore?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
if (!response || response.dados.resultado.length === 0) {
return reply("❌ Hmph! Nenhum aplicativo encontrado pra sua pesquisa... Eu sou boa nisso e mesmo assim não achei, viu?! Tanto faz, baka!");
}
const app = response.dados.resultado[0];
let textoPlay = `*✨ SEARCH PLAY STORE ✨*\nHmph! Achei o aplicativo pra você... só dessa vez, tá?!\n\n` +
`*📌 Nome:* ${app.nome}\n` +
`*👤 Dev:* ${app.desenvolvedor}\n` +
`*⭐ Nota:* ${app.estrelas || 'N/A'}\n` +
`*🔗 Link:* ${app.link}`;
await kira.sendMessage(from, {image: {url: app.imagem}, caption: textoPlay}, {quoted: selo});
await reagir(from, "✅");
} catch (err) {
console.error(err);
reply("🚨 Hmph! Erro ao processar a pesquisa na Play Store... Calma, eu resolvo, sou a melhor da academia. Tenta de novo, viu?!");
}
}
}
};