const axios = require('axios');
const cooldowns = new Map();

const HEADERS = {
"accept": "application/json, text/javascript, */*; q=0.01",
"accept-language": "en-US,en;q=0.9",
"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
"x-requested-with": "XMLHttpRequest",
"x-pinterest-appstate": "active",
"x-pinterest-pws-handler": "www/[username]/[slug].js",
"referer": "https://www.pinterest.com/",
"origin": "https://www.pinterest.com"
};

function normalize(url) {
return url.replace(/236x/g, "736x")
};

async function pinterestSearch(query) {
try {
const url = `https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=/search/pins/?q=${encodeURIComponent(query)}&data=${encodeURIComponent(JSON.stringify({
options: { query: query, scope: "pins" },
context: {}
}))}`;
const res = await axios.get(url, { headers: HEADERS })
const pins = res.data.resource_response.data.results
const urls = []
for (const pin of pins) {
if (pin.images?.orig?.url) {
urls.push(normalize(pin.images.orig.url))
}
};
return {
ok: true,
count: urls.length,
urls
};
} catch (e) {
return {
ok: false,
msg: e.message
}
}
};

module.exports = {
nome: ["pinterest","pin"],
executar: async ({
from,
prefix,
command,
q,
quoted,
reagir,
reply,
selo,
kira
}) => {

try {
if (!q) return reply(`❌ Hmph! Erro! Digite o que deseja buscar...\nExemplo: *${prefix + command} paisagens vintage*. Sou boa nisso, mas adivinhar não é meu forte, baka!`);
await reagir(from, '💖');
const resulty = await pinterestSearch(q);
const urlsy = resulty.urls;
if (urlsy.length > 0) {
const randomImg = urlsy[Math.floor(Math.random() * urlsy.length)];
await kira.sendMessage(from, {
interactiveMessage: {
title: `🎨 *SUA IMAGEM AQUI* 🎨\nHmph! Peguei pra você... só não se acostume, baka!`,
footer: `*kira SYSTEM*`,
buttons: [
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: "⏩ PRÓXIMO",
id: `${prefix + command} ${q}`
})
},
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: "📈 LATÊNCIA",
id: `${prefix}ping`
})
}
],
image: { url: randomImg }
}
}, {quoted: selo});
} else {
reply("❌ Hmph! Nenhuma imagem encontrada... Pesquisei até cansar, viu?! Tanto faz, baka!");
}
} catch (error) {
console.log(error);
reply("❌ Hmph! Erro ao processar a busca... F-foi mal, tenta de novo, tá?! Eu, a melhor da academia, vou resolver!");
}
}
};