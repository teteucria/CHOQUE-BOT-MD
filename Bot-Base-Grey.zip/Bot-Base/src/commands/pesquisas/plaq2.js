module.exports = {
nome: ["plaq2"],
executar: async ({
args,
buffer,
from,
getBuffer,
mess,
prefix,
pushname,
q,
reagir,
reply,
selo,
sender,
kira
}) => {

if (args.length < 1) return reply("❕Hmph! Ei, humano... cadê o texto? N-não me faça esperar, baka!");
if (q.length > 25) return reply("❗Hmph! O texto tá longo demais... O máximo é 25 caracteres, bobinho(a). Até eu, que sou a melhor da academia, respeito as regras, viu?!");
reagir(from, "🕒");
buffer = await getBuffer(`https://raptibef.sirv.com/images.jpeg?profile=Zanga%203.0&text.0.text=${q}&text.0.outline.blur=63`);
((sendMsg = kira.sendMessage(sender,{ image: buffer }, { quoted: selo })),
reply(`Hmph! Eai, ${pushname}, preparado(a)? Tô enviando agora... verifica seu PV, tá?! N-não é como se eu me importasse... 😈🔥`));
}
};