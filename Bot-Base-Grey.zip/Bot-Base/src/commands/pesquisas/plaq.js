module.exports = {
nome: ["plaq"],
executar: async ({
args,
buffer,
from,
getBuffer,
mess,
prefix,
pushname,
q,
reagir,
reply,
selo,
sender,
kira
}) => {

if (args.length < 1) return reply("❕Hmph! Ei, humano... cadê o texto? N-não me faça esperar, baka!");
if (q.length > 25) return reply("❗Hmph! O texto tá longo demais... O máximo é 25 caracteres, bobinho(a). Até eu, que sou a melhor da academia, respeito as regras, viu?!");
reagir(from, "🕒");
buffer = await getBuffer(`https://raptibef.sirv.com/images%20(3).jpeg?text.0.text=${q}&text.0.position.gravity=center&text.0.position.x=19%25&text.0.size=45&text.0.color=000000&text.0.opacity=55&text.0.font.family=Crimson%20Text&text.0.font.weight=300&text.0.font.style=italic&text.0.outline.opacity=21`);
((sendMsg = kira.sendMessage(sender, {image: buffer}, {quoted: selo})),
reply(`Hmph! Eai, ${pushname}, preparado(a)? Tô enviando agora... verifica seu PV, tá?! N-não é como se eu me importasse... 😈🔥`));
}
};