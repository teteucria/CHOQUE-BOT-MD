module.exports = {
nome: ["gptimage"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Descreve a imagem... Exemplo: *${prefix + command} ciberpunk cidade*`);
reagir(from, "🤖");
try {
const res = await fetchJson(`${API_kira}/gptimage?prompt=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const d = res.dados || {};
if (!d.url) return reply("Hmph! A imagem não veio... tenta de novo!");
await kira.sendMessage(from, { image: { url: d.url }, caption: `*🤖 GPT IMAGE 🎨*\nHmph! Nem a inteligência artificial resiste ao meu pedido... u-uau! 😤\n\n*🎨 Prompt:* ${q}\n*🤖 Gerador:* ${d.provider || "?"}` }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A IA travou..."); }
}
};
