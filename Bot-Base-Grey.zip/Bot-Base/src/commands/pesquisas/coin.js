module.exports = {
nome: ["coin"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual moeda? Exemplo: *${prefix + command} btc-bitcoin*`);
reagir(from, "🪙");
try {
const res = await fetchJson(`${API_kira}/info/coin?id=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const r = res.resultado?.result || {};
reply(`*🪙 CRYPTO INFO 📈*\nHmph! Isso é só uma olhadinha... eu não sou sua corretora, viu?!\n\n*🪙 Nome:* ${r.name || "?"} (${r.symbol || "?"})\n*🏅 Rank:* #${r.rank || "?"}\n*💾 Tipo:* ${r.type || "coin"}\n*🏷️ Tags:* ${(r.tags || []).slice(0, 5).map(t => t.name).join(", ") || "—"}\n*📄 Descrição:*\n${(r.description || "sem descrição.").slice(0,300)}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não achei essa moeda..."); }
}
};
