module.exports = {
nome: ["amazon","amazonsearch"],
executar: async ({
fetchJson,
from,
q,
reagir,
reply,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

if(q.trim().length < 4) return reply(`Hmph! Exemplo: *${prefix+command} fone redmi airdots 2*. Até eu, que sou a melhor da academia, não consigo adivinhar o que você quer com tão pouco texto, baka!`)
try {
reagir(from, "✅️");
const ABC = await fetchJson(`${API_kira}/amazon?titulo=${encodeURIComponent(q.trim())}&apitoken=${KEY_kira}`);
let RST = "Hmph! Achei os resultados pra você... só porque eu quis, tá?!\n\n🛒 *Pesquisa Amazon:*\n\n";
const resultados = ABC.dados.resultado;
for (let i = 0; i < Math.min(resultados.length, 40); i++) {
RST += `( ${i + 1} ) - Busca: ${q}
- Preço: ${resultados[i].valor}
- Url: ${resultados[i].link}
----------------------------\n`;
};

reply(RST);
} catch (e) {
return reply(`Hmph! Erro, não foi possível encontrar... Tenta de novo, viu? N-não é como se eu fosse desistir de você, baka!`)
console.log(e);
}
}
};