module.exports = {
nome: ["aptoide"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual app? Exemplo: *${prefix + command} genshin*`);
reagir(from, "📱");
try {
const res = await fetchJson(`${API_kira}/aptoide?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const d = res.dados || {};
if (!d.nome) return reply("Hmph! Não achei esse app, baka!");
const downloads = d.downloads ? (d.downloads >= 1000000 ? (d.downloads / 1000000).toFixed(1) + "M" : d.downloads >= 1000 ? (d.downloads / 1000).toFixed(1) + "K" : d.downloads) : "?";
reply(`*📱 APTOIDE 📲*\nHmph! Tá aí seu app... baixa sozinho, eu não vou instalar pra você! 😤\n\n*📦 App:* ${d.nome}\n*👤 Dev:* ${d.desenvolvedor || "?"}\n*💾 Tamanho:* ${d.tamanho || "?"}\n*⬇️ Baixado:* ${downloads} vezes\n*🔗 Link:* ${d.link || "?"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não achei esse app..."); }
}
};
