module.exports = {
nome: ["attp_white","attp_brat","attp_white_video","attp_brat_video"],
executar: async ({
from,
q,
quoted,
reagir,
reply,
selo,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

try {
if(!q.trim()) return reply(`🎬 Hmph! Exemplo: *${prefix+command} seu texto aqui*. N-não me obrigue a te ensinar do zero, baka!`);
reagir(from, "✅️");
const url = `${API_kira}/brat-animado?texto=${encodeURIComponent(q)}&apitoken=${KEY_kira}`;
kira.sendMessage(from, {sticker: {url: url}}, {quoted: selo}).catch(() => reply("❌ Hmph! Erro ao gerar figurinha... mas eu conserto, sou a melhor da academia. Tenta de novo, tá?!"));
} catch (e) {
return reply("❌ Hmph! Erro ao processar a busca, API offline... F-foi mal, baka, tenta mais tarde, viu?!");
}
}
};