module.exports = {
nome: ["newsgoogle"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! O que quer pesquisar? Exemplo: *${prefix + command} futebol*`);
reagir(from, "🔍");
try {
const res = await fetchJson(`${API_kira}/news/google?query=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const noticias = (res.resultado?.articles || []).slice(0, 8)
.map((n, i) => `*${i + 1}.* ${n.title}\n 🗞️ ${n.source || ""}\n 🔗 ${n.url}`)
.join("\n\n");
reply(`*🔍 GOOGLE NEWS 📰*\nHmph! Pesquisei tudo fresquinho pra você...\n\n*✏️ Busca:* ${q}\n*🗞️ Últimas:*\n\n${noticias || "Nenhuma notícia encontrada, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A busca de notícias falhou..."); }
}
};
