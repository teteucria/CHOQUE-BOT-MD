module.exports = {
nome: ["pensador","frase"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Frases de quê? Exemplo: *${prefix + command} amor*`);
reagir(from, "💭");
try {
const res = await fetchJson(`${API_kira}/pensador?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const frases = (res.dados || []).slice(0, 5)
.map((f, i) => `*${i + 1}.* "${f.frase}"\n — *${f.autor || "Desconhecido"}*`)
.join("\n\n");
reply(`*💭 PENSADOR 💭*\nHmph! Frases profundas... toma, reflete e depois me agradece! 🧠\n\n*📖 Tema:* ${q}\n*✨ Frases:*\n\n${frases || "Nenhuma frase encontrada, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não achei frases sobre isso..."); }
}
};
