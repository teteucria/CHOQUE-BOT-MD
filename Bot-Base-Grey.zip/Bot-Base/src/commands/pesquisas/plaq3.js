module.exports = {
nome: ["plaq3"],
executar: async ({
args,
buffer,
from,
getBuffer,
mess,
pushname,
plaq,
prefix,
q,
reagir,
reply,
selo,
sender,
kira
}) => {

if (args.length < 1) return reply("❕Hmph! Ei, humano... cadê o texto? N-não me faça esperar, baka!");
if (q.length > 25) return reply("❗Hmph! O texto tá longo demais... O máximo é 25 caracteres, bobinho(a). Até eu, que sou a melhor da academia, respeito as regras, viu?!");
reagir(from, "🕒");
buffer = await getBuffer(`https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${q}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`);
plaq = ` *Plaquinha feita ✓... Hmph! Só fiz porque quis, viu?!* `;
((sendMsg = kira.sendMessage(
sender,
{ image: buffer },
{ quoted: selo }
)),
reply(
`Hmph! Eai, ${pushname}, preparado(a)? Tô enviando agora... verifica seu PV, tá?! N-não é como se eu me importasse... 😈🔥`
));
}
};