module.exports = {
nome: ["saurasource"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "📡");
try {
const res = await fetchJson(`${API_kira}/saura-source?apitoken=${KEY_kira}`);
const fontes = (res.resultado?.sources || []).slice(0, 10)
.map((s, i) => `*${i + 1}.* ${s.name}\n 🗺️ ${s.country || ""} • ${s.language || ""}\n 🔗 ${s.url}`)
.join("\n\n");
reply(`*📡 SAURA SOURCES 🛰️*\nHmph! ${res.resultado?.sources?.length || "?"} fontes de notícias!\n\n*🌐 Fontes:*\n\n${fontes || "Nada por aqui, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Falhou, baka!"); }
}
};
