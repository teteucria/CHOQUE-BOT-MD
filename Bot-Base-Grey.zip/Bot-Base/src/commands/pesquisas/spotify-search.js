module.exports = {
nome: ["spotify-search"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Manda o titulo da música... Exemplo: *${prefix + command} matue*`);
reagir(from, "🎵");
try {
const res = await fetchJson(`${API_kira}/spotify-search?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const d = (res.dados?.resultados || [])[0] || {};
if (!d.titulo) return reply("Hmph! Não achei essa música, baka!");
const legenda = `*🎵 SPOTIFY 🎧*\nHmph! Boa escolha... até eu aprovo, baka!\n\n*🎵 Música:* ${d.titulo}\n*👤 Artista:* ${(d.artistas || [])[0] || "?"}\n*💿 Álbum:* ${d.album || "?"}\n*⏱️ Duração:* ${d.duracao_seg || "?"} (${d.duracao_ms || "?"})`;
if (d.imagem_album) await kira.sendMessage(from, { image: { url: d.imagem_album }, caption: legenda }, { quoted: info });
else reply(legenda);
if (d.link_mp3_direto) await kira.sendMessage(from, { audio: { url: d.link_mp3_direto }, mimetype: "audio/mpeg" }, { quoted: info }).catch(() => {});
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não consegui buscar no Spotify..."); }
}
};
