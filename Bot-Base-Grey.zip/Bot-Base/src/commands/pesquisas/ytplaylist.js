module.exports = {
nome: ["ytplaylist"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Nome da playlist? Exemplo: *${prefix + command} lofi anime*`);
reagir(from, "🗂️");
try {
const res = await fetchJson(`${API_kira}/yt-playlist?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const lista = (res.resultado || res.resultados || []).slice(0, 15)
.map((v, i) => `*${i + 1}.* ${v.title || v.titulo}\n ⏱️ ${v.duration?.timestamp || v.timestamp || "?"} • 👁️ ${v.views || "?"}\n 🔗 ${v.url || v.link}`)
.join("\n\n");
reply(`*🎧 YT PLAYLIST 🎶*\nHmph! Separei uma playlist só pra você... bota no volume máximo! 🔊\n\n*🎵 Busca:* ${q}\n*📃 Resultados:*\n\n${lista || "Nada encontrado, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não achei essa playlist..."); }
}
};
