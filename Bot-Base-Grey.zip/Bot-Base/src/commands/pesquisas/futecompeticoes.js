module.exports = {
nome: ["futecompeticoes"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "🏆");
try {
const res = await fetchJson(`${API_kira}/futeboll-competicao?apitoken=${KEY_kira}`);
const comps = (res.resultado?.competitions || []).slice(0, 12)
.map((c, i) => `*${i + 1}.* ${c.name}\n 🌍 ${c.area?.name || ""} • ${c.currentSeason?.startDate || ""} → ${c.currentSeason?.endDate || ""}`)
.join("\n\n");
reply(`*🏆 COMPETIÇÕES 🏆*\nHmph! ${res.resultado?.count || "?"} competições encontradas!\n\n*🏅 Competições:*\n\n${comps || "Nada por aqui, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Falhou, baka!"); }
}
};
