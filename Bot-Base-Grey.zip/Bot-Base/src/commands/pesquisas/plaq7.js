module.exports = {
nome: ["plaq7"],
executar: async ({
args,
getBuffer,
mess,
prefix,
pushname,
q,
reply,
selo,
sender,
kira
}) => {

if (args.length < 1) return reply("❕Hmph! Ei, humano... cadê o texto? N-não me faça esperar, baka!");
if (q.length > 25) return reply("❗Hmph! O texto tá longo demais... O máximo é 25 caracteres, bobinho(a). Até eu, que sou a melhor da academia, respeito as regras, viu?!");
buffer = await getBuffer(
`https://lerrewor.sirv.com/Teste/images%20(1)%20(10).jpeg?text.0.text=${q}&text.0.position.y=-25%25&text.0.size=41&text.0.color=000000&text.0.font.family=Vollkorn&text.0.background.opacity=100" width="193" height="261" alt="" />`
);
((sendMsg = kira.sendMessage(
sender,
{ image: buffer },
{ quoted: selo }
)),
reply(
`Hmph! Eai, ${pushname}, preparado(a)? Tô enviando agora... verifica seu PV, tá?! N-não é como se eu me importasse... 😈🔥`
));
}
};