module.exports = {
nome: ["encomenda","rastreio"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual o código da encomenda? Exemplo: *${prefix + command} RA123456789BR*`);
reagir(from, "📦");
try {
const res = await fetchJson(`${API_kira}/encomenda?pedido=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const d = res.dados || [];
if (!d.length) return reply(`Hmph! Não achei nada pra o código *${q}*... confere se está certo, baka!`);
const lista = d.map((e, i) => `*${i + 1}.* ${e.evento || e.titulo || ""}\n 📍 ${e.local || ""}\n 🕐 ${e.data || e.horario || ""}`).join("\n\n");
reply(`*📦 RASTREIO 🚚*\nHmph! Sua encomenda tá a caminho... quer dizer, quase! 😏\n\n*🏷️ Código:* ${q}\n*📍 Rastreio:*\n\n${lista}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! O rastreio falhou..."); }
}
};
