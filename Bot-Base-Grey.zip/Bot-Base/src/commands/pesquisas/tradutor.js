module.exports = {
nome: ["tradutor"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q || !q.includes("|")) return reply(`Hmph! Use assim: *${prefix + command} olá mundo|en*`);
reagir(from, "🌐");
try {
const [texto, lang] = q.split("|").map(t => t.trim());
if (!texto || !lang) return reply("Hmph! Manda assim: *texto|idioma* (ex: en, es, ja)");
const res = await fetchJson(`${API_kira}/tradutor?texto=${encodeURIComponent(texto)}&lang=${encodeURIComponent(lang)}&apitoken=${KEY_kira}`);
const d = res.dados || {};
reply(`*🌐 TRADUTOR 🌐*\nHmph! Até o Google se curva pra mim... 😤✨\n\n*📝 Original:* ${d.original || texto}\n*✅ Tradução:* ${d.translated || "?"}\n*🔄 De* ${d.fromName || d.from || "?"} *→* ${d.toName || d.to || "?"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não consegui traduzir..."); }
}
};
