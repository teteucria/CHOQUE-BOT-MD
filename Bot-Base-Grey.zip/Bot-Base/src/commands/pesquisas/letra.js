module.exports = {
nome: ["letra","lyrics"],
executar: async ({
fetchJson,
from,
info,
q,
reagir,
reply,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

{
if (!q) return reply(`*⚠️ ᴜꜱᴏ ɪɴᴄᴏʀʀᴇᴛᴏ!*\n\n*Exemplo:* ${prefix}${command} Matue 1993\n\nHmph! Nem a melhor aluna da academia salva texto vazio, viu?!`);
const [artista, ...musicaArray] = q.split(" ");
const letra = musicaArray.join(" ");
if (!artista || !letra) {
return reply(`Hmph! Use assim: .letra artista | música... F-foi difícil eu digitar isso pra você, baka!`);
}
try {
await reagir(from, "🎶");
const resu = await fetchJson(`${API_kira}/yt-search?titulo=${q}&apitoken=${KEY_kira}`);
const musica = await fetchJson(`${API_kira}/lyrics-song?artista=${artista}&musica=${letra}&apitoken=${KEY_kira}`);
const corpoLyrics = [
`Hmph! Peguei a letra pra você... não se acostume com essa atenção, baka!`,
`🎵 *TÍTULO:* ${musica.dados.title}`,
`👤 *COMPOSITOR:* ${musica.dados.artist || 'Desconhecido'}`,
` `,
`📝 *TRECHO:* _${musica.dados.lyrics.substring(0, 220).replace(/\n/g, ' ')}..._`
].join('\n');

await kira.sendMessage(from, {
interactiveMessage: {
title: `${corpoLyrics}`,
footer: `kira SYSTEM.`,
buttons: [
{
name: "cta_copy",
buttonParamsJson: JSON.stringify({
display_text: "📋 COPIAR LETRA",
copy_code: musica.dados.lyrics
})
}
],
image: {url: `${resu.resxz.thumbnail}`}
}
}, {quoted: info});

} catch (e) {
console.error("Erro Letra:", e);
reply("❌ Hmph! Erro ao processar a busca, API offline... Tenta de novo mais tarde, baka, eu também tenho meus dias ruins, viu?!");
}
}
}
};