module.exports = {
nome: ["spotify"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q || !q.includes("http")) return reply(`Hmph! Manda o LINK da música... Exemplo: *${prefix + command} https://open.spotify.com/track/xxxx*`);
reagir(from, "🎵");
try {
const res = await fetchJson(`${API_kira}/spotify-track?url=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const d = res.dados || {};
if (!d.name) return reply("Hmph! Não achei essa música, baka!");
const legenda = `*🎵 SPOTIFY 🎧*\nHmph! Boa escolha... até eu aprovo, baka!\n\n*🎵 Música:* ${d.name}\n*👤 Artista:* ${d.artist || "?"}\n*💿 Álbum:* ${d.album || "?"}\n*⏱️ Duração:* ${d.duration || "?"} (${d.year || "?"})`;
if (d.cover) await kira.sendMessage(from, { image: { url: d.cover }, caption: legenda }, { quoted: info });
else reply(legenda);
if (d.mp3) await kira.sendMessage(from, { audio: { url: d.mp3 }, mimetype: "audio/mpeg" }, { quoted: info }).catch(() => {});
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não consegui buscar no Spotify..."); }
}
};
