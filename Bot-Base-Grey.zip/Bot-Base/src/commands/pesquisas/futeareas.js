module.exports = {
nome: ["futeareas"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "🗺️");
try {
const res = await fetchJson(`${API_kira}/futeboll-areas?apitoken=${KEY_kira}`);
const areas = (res.resultado?.areas || []).slice(0, 12)
.map((a, i) => `*${i + 1}.* ${a.name} ${a.flag || ""}\n 🌐 ${a.parentArea || ""}`)
.join("\n\n");
reply(`*🗺️ ÁREAS DE FUTEBOL 🌍*\nHmph! ${res.resultado?.count || "?"} áreas cadastradas!\n\n*🏟️ Áreas:*\n\n${areas || "Nada por aqui, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Falhou, baka!"); }
}
};
