module.exports = {
nome: ["animesearch"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual wallpaper de anime? Exemplo: *${prefix + command} naruto*`);
reagir(from, "🖼️");
try {
const res = await fetchJson(`${API_kira}/anime-search?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const walls = (res.dados || []).slice(0, 8).map((w, i) => `*${i + 1}.* ${w.source || "wallhaven"}\n 🔗 ${w.url}`).join("\n\n");
reply(`*🌸 ANIME SEARCH 🌸*\nHmph! Wallpapers de anime... eu sei, eu sei, sou muito prestativa! 😌\n\n*🔍 Busca:* ${q}\n*🖼️ Wallpapers:*\n\n${walls || "Nenhum wallpaper encontrado, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A busca falhou..."); }
}
};
