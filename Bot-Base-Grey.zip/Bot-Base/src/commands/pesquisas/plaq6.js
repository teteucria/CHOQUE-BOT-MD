module.exports = {
nome: ["plaq6"],
executar: async ({
args,
getBuffer,
mess,
prefix,
pushname,
q,
reply,
selo,
sender,
kira
}) => {

if (args.length < 1) return reply("❕Hmph! Ei, humano... cadê o texto? N-não me faça esperar, baka!");
if (q.length > 25) return reply("❗Hmph! O texto tá longo demais... O máximo é 25 caracteres, bobinho(a). Até eu, que sou a melhor da academia, respeito as regras, viu?!");
buffer = await getBuffer(`https://lerrewor.sirv.com/Teste/images%20(1)%20(5).jpeg?text.0.text=${q}&text.0.position.x=-45%25&text.0.position.y=-29%25&text.0.size=36&text.0.color=000000&text.0.opacity=65&text.0.font.family=PT%20Sans%20Narrow" width="479" height="640" alt="" />`);
((sendMsg = kira.sendMessage(
sender,
{ image: buffer },
{ quoted: selo }
)),
reply(
`Hmph! Eai, ${pushname}, preparado(a)? Tô enviando agora... verifica seu PV, tá?! N-não é como se eu me importasse... 😈🔥`
));
}
};