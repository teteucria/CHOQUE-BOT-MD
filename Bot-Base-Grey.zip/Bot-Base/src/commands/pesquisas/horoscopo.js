module.exports = {
nome: ["horoscopo"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual o seu signo? Exemplo: *${prefix + command} aries*`);
reagir(from, "🔮");
try {
const res = await fetchJson(`${API_kira}/horoscopo?signo=${encodeURIComponent(q.toLowerCase())}&apitoken=${KEY_kira}`);
const d = res.dados || {};
if (d.imagem) {
await kira.sendMessage(from, { image: { url: d.imagem }, caption: `*🔮 HORÓSCOPO ${q.toUpperCase()} 🔮*\n${d["título"] || ""}\n\n${d.inform || "Hmph! As estrelas estão em silêncio hoje, baka..."}` }, { quoted: info });
} else {
reply(`Hmph! Não achei o signo *${q}*... confere aí!`);
}
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! As estrelas falharam... tenta outro signo!"); }
}
};
