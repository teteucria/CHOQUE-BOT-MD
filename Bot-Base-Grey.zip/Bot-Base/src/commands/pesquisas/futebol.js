module.exports = {
nome: ["futebol"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "⚽");
try {
const res = await fetchJson(`${API_kira}/futebol?apitoken=${KEY_kira}`);
const noticias = (res.dados || []).slice(0, 6)
.map((n, i) => `*${i + 1}.* ${n.titulo || n.trechoManchete || "Notícia"}\n 🕐 ${n.horarioPostagem || ""}\n 🔗 ${n.linkNoticia || ""}`)
.join("\n\n");
reply(`*⚽ FUTEBOL ⚽*\nAs últimas do mundo da bola! 🏟️\n\n*🥅 Manchetes:*\n\n${noticias || "Nada por aqui, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! O futebol não veio..."); }
}
};
