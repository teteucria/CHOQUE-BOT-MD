module.exports = {
nome: ["sauracnn"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "📰");
try {
const res = await fetchJson(`${API_kira}/saura-cnn?apitoken=${KEY_kira}`);
const noticias = (res.resultado?.articles || res.resultado?.results || res.dados || [])
.slice(0, 8)
.map((n, i) => `*${i + 1}.* ${n.title || n.titulo || "Notícia"}\n 🔗 ${n.url || n.linkNoticia || ""}`)
.join("\n\n");
reply(`*📺 SAURA CNN 📺*\n\n*🗞️ Últimas:*\n\n${noticias || "Nada por aqui, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! As notícias não quiseram sair... tenta de novo!"); }
}
};
