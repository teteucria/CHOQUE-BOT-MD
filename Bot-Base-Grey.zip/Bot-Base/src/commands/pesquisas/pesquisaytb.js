module.exports = {
nome: ["pesquisaytb"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q || q.trim().length < 3) return reply(`Hmph! Escreve o que quer procurar... Exemplo: *${prefix + command} naruto op*`);
reagir(from, "🔎");
try {
const res = await fetchJson(`${API_kira}/yt-search?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const vids = res.resultados || res.resultado || [];
const lista = (Array.isArray(vids) ? vids : [vids]).slice(0, 8)
.map((v, i) => `*${i + 1}.* ${v.title || "sem título"}\n ⏱️ ${v.duration?.timestamp || v.timestamp || "?"} • 👁️ ${v.views || "?"} • 🕐 ${v.ago || ""}\n 🎙️ Canal: ${v.author?.name || "?"}\n 🔗 Link: ${v.url}`)
.join("\n\n");
reply(`*🔎 YOUTUBE SEARCH 📺*\nHmph! Achei isso... n-não se acostume!\n\n*🔍 Busca:* ${q}\n*▶️ Vídeos:*\n\n${lista}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A busca falhou, baka!"); }
}
};
