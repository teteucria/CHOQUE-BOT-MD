module.exports = {
nome: ["threadstalk"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual @ do Threads? Exemplo: *${prefix + command} zuck*`);
reagir(from, "🧵");
try {
const user = q.replace("@", "");
const res = await fetchJson(`${API_kira}/stalk/threads?username=${encodeURIComponent(user)}&apitoken=${KEY_kira}`);
const r = res.resultado || {};
const legenda = `🧵 *Nome:* *${r.name || r.username || "?"}*\n🆔 *Usuário:* *@${r.username || user}*\n📈 *Seguidores:* *${r.followers || "?"}*\n📝 *Bio:*\n${r.bio || ""}\n\n🔗 ${r.url || ""}`;
if (r.profile_image) await kira.sendMessage(from, { image: { url: r.profile_image }, caption: legenda }, { quoted: info });
else reply(legenda);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Esse perfil do Threads não existe..."); }
}
};
