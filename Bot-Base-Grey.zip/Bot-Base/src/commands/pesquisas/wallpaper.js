module.exports = {
nome: ["wallsearch","wallpaper"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual wallpaper? Exemplo: *${prefix + command} naruto*`);
reagir(from, "🖼️");
try {
const res = await fetchJson(`${API_kira}/wallpaper-search?titulo=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const walls = (res.dados || []).slice(0, 8).map((w, i) => `*${i + 1}.* ${w.title}\n 🔗 ${w.url}`).join("\n\n");
reply(`*🖼️ WALLPAPER SEARCH 🌄*\nHmph! Papel de parede novinho pra você... personalize à vontade! 😼\n\n*🔍 Busca:* ${q}\n*🖼️ Wallpapers:*\n\n${walls || "Nenhum wallpaper encontrado, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A busca de wallpapers falhou..."); }
}
};
