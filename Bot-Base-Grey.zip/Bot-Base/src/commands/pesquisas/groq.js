module.exports = {
nome: ["groq"],
executar: async ({
q, from, reagir, reply, fetchJson, prefix, command, API_kira, KEY_kira
}) => {
try {
if (!q) return reply(`Hmph! Fale algo... Exemplo: *${prefix + command} bom dia*`);
const now = await fetchJson(`${API_kira}/ai/groq?text=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
reply(`🤖: ${now.resultado.result}`);
} catch (e) {
console.log(e);
reply(`🤖: deu erro..`);
reagir(from, "❌");
}
}
};
