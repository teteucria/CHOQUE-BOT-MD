module.exports = {
nome: ["carbon"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Qual código? Exemplo: *${prefix + command} console.log("oi")*`);
reagir(from, "🎨");
try {
const res = await fetchJson(`${API_kira}/info/carbon?code=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const b64 = (res.resultado || "").split(",")[1];
if (!b64) return reply("Hmph! Não consegui gerar... tenta de novo, baka!");
const img = Buffer.from(b64, "base64");
await kira.sendMessage(from, { image: img, caption: "Hmph! Seu código virou arte... até eu fiquei impressionada, baka! 🖼️" }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! Não consegui criar o carbon..."); }
}
};
