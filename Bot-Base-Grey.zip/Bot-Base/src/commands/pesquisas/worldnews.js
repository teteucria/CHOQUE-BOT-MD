module.exports = {
nome: ["worldnews"],
executar: async ({
from, reagir, reply, fetchJson, API_kira, KEY_kira
}) => {
reagir(from, "📰");
try {
const res = await fetchJson(`${API_kira}/world-news?apitoken=${KEY_kira}`);
const noticias = (res.resultado?.news || res.resultado?.results || res.dados || [])
.slice(0, 8)
.map((n, i) => `*${i + 1}.* ${n.title || n.titulo || "Notícia"}\n 🔗 ${n.url || n.linkNoticia || ""}`)
.join("\n\n");
reply(`*🌍 WORLD NEWS 🌎*\n\n*🗞️ Últimas:*\n\n${noticias || "Nada por aqui, baka!"}`);
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! As notícias não quiseram sair... tenta de novo!"); }
}
};
