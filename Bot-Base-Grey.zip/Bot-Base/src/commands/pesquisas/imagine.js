module.exports = {
nome: ["imagine"],
executar: async ({
q, from, info, reagir, reply, fetchJson, kira, prefix, command, API_kira, KEY_kira
}) => {
if (!q) return reply(`Hmph! Descreve a imagem... Exemplo: *${prefix + command} gato astronauta*`);
reagir(from, "🎨");
try {
const res = await fetchJson(`${API_kira}/imagine?prompt=${encodeURIComponent(q)}&apitoken=${KEY_kira}`);
const d = res.dados || {};
const foto = (d.images || [])[0];
if (!foto) return reply("Hmph! A imagem não veio... tenta de novo!");
await kira.sendMessage(from, { image: { url: foto }, caption: `*🎨 IMAGINE ✨*\nHmph! Olha o que eu criei pra você... sou boa demais, né?! 😌\n\n*🎨 Prompt:* ${d.prompt || q}\n*🎭 Estilo:* ${d.style || "?"}\n*🌱 Seed:* ${d.seed || "?"}` }, { quoted: info });
reagir(from, "✅");
} catch (e) { console.log(e); reagir(from, "❌"); reply("Hmph! A IA não quis desenhar..."); }
}
};
