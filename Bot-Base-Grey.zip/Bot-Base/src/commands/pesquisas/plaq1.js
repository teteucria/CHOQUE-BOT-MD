module.exports = {
nome: ["plaq1"],
executar: async ({
args,
buffer,
from,
pushname,
getBuffer,
mess,
prefix,
q,
reagir,
reply,
selo,
sender,
kira
}) => {

if (args.length < 1) return reply("❕Hmph! Ei, humano... cadê o texto? N-não me faça esperar, baka!");
if (q.length > 25) return reply("❗Hmph! O texto tá longo demais... O máximo é 25 caracteres, bobinho(a). Até eu, que sou a melhor da academia, respeito as regras, viu?!");
reagir(from, "🕒");
buffer = await getBuffer(`https://raptibef.sirv.com/images%20(1).jpeg?profile=Zanga%202.0&text.0.text=${q}`);
((sendMsg = kira.sendMessage(sender, {image: buffer}, {quoted: selo})),
reply(`Hmph! Eai, ${pushname}, preparado(a)? Tô enviando agora... verifica seu PV, tá?! N-não é como se eu me importasse... 😈🔥`));
}
};