module.exports = {
nome: ["attp","attp2"],
executar: async ({
from,
mess,
q,
quoted,
reagir,
reply,
selo,
kira,
API_kira,
  prefix,
  command,
KEY_kira
}) => {

reagir(from, '✅');
try {
if(!q.trim()) return reply(`Hmph! Exemplo: *${prefix+command} duck*. Escreve direito, bobinho(a), que eu faço a figurinha... só por essa vez, tá?!`);
kira.sendMessage(from, {sticker: {url: `${API_kira}/attp?texto=${encodeURIComponent(q)}&apitoken=${KEY_kira}`}}, {quoted: selo});
} catch (e) {
return reply(mess.error());
}
}
};