module.exports = {
nome: ["rankbaiana","rankbaianas"],
executar: async ({
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkbaiana,
somembros,
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `Hmph! RANK DAS 5 MAIS BAIANAS DO GRUPO 😴💤\n\n`;
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n`;
}
await mencionarIMG(ABC, rnkbaiana);
}
};