module.exports = {
nome: ["obesidade","obeso"],
executar: async ({
info,
obeso,
q,
reply,
  prefix,
  command,
replyWithReaction
}) => {

if (!q.includes("/"))
 return reply(`Hmph! Coloca do jeito certo, bobinho(a)... Ex.: *${prefix + command} peso/altura*. Até eu, a melhor da academia, preciso de dados certos!`);
var [peso, altura] = q.split("/");
var resultado = await obeso(peso, altura);
if (resultado <= 17 || resultado <= 18.4) {
 await replyWithReaction(`Hmph! Seu índice de massa corporal é de: *${resultado}* -> Você está abaixo do peso... e-eu só digo isso porque quero, tá?!`, {react: {text: "😸", key: info.key}});
} else if (resultado <= 18.5 || resultado <= 24.9) {
 await replyWithReaction(`Hmph! Seu índice de massa corporal é: *${resultado}* -> Você está no peso ideal... n-não é como se eu tivesse torcido por você, claro, viu?!`, {react: {text: "👍", key: info.key }});
} else if (resultado <= 25 || resultado <= 29.9) {
 await replyWithReaction(`Hmph! Seu índice de massa corporal é: *${resultado}* -> Você está com sobrepeso... hmph, aquele docinho extra, baka!`, {react: {text: "🫤", key: info.key }});
} else if (resultado <= 30 || resultado <= 39.9) {
 await replyWithReaction(`Hmph! Seu índice de massa corporal é: *${resultado}* -> Em situação de Obesidade... t-tem que se cuidar, tá?! Eu tô falando porque... porque sim!`, {react: {text: "🤨", key: info.key }});
} else if (resultado > 40) {
 await replyWithReaction(`Hmph! Seu índice de massa corporal é: *${resultado}* -> Obesidade mórbida! ...e-eu não vou te julgar, mas se cuida, viu?!`, {react: {text: `😵`, key: info.key }});
}
}
};