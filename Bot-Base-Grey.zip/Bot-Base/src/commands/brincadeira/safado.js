module.exports = {
nome: ["safado"],
executar: async ({
from,
imgsafado,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(
from,
{
 text: `Hmph! Deixa eu pesquisar a ficha de @${menc_os2.split("@")[0]}... fica quietinho(a) aí, já volto, tá?!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(
from,
{
image: { url: imgsafado },
 caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa safada?\n• A porcentagem de chance é *${random}%*... Hmph, n-não é como se eu tivesse sentido vergonha por você, claro, viu?!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
}, 7000);
}
};