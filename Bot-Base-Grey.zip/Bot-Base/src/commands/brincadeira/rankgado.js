module.exports = {
nome: ["rankgado","rankgados"],
executar: async ({
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkgado,
somembros
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `🐂 Hmph! *RANK DOS 5 MAIS GADO DO GRUPO:*\n—\n`;
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n`;
}
await mencionarIMG(ABC, rnkgado);
}
};