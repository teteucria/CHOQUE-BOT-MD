module.exports = {
nome: ["fiel"],
executar: async ({
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));

kira.sendMessage(from, {text: `🔎 Hmph! Deixa eu analisar o coração de *@${menc_os2.split("@")[0]}*... será que é fiel mesmo, hein?!`,
mentions: [menc_os2]}, { quoted: selo });

setTimeout(async () => {
let random = Math.floor(Math.random() * 101);

let titulo = "";
if (random <= 20) titulo = "💔 Coração de Pedra... frio(a), mas a gente entende, hmph!";
else if (random <= 50) titulo = "😏 Aventureiro... vai se acalmar, baka!";
else if (random <= 80) titulo = "💘 Comprometido... n-não é como se eu tivesse orgulho, claro!";
else titulo = "😇 Anjo Fiel... quase tão puro quanto meus docinhos, viu?!";

let barra = "█".repeat(Math.floor(random / 10)) + "░".repeat(10 - Math.floor(random / 10));

kira.sendMessage(from, {image: {url: `https://storage.oberonhosting.com.br/media/2168f346e72f836f.jpg`}, caption:
`💞 Hmph! Resultado da análise de fidelidade:\n\n` +
`👤 Usuário: *@${menc_os2.split("@")[0]}*\n` +
`📊 Fidelidade: *${random}%*\n` +
`🏆 Título: *${titulo}*\n\n` +
`📈 Barra de Fidelidade:\n[${barra}]\n\nNão é como se eu tivesse me esforçado por você, viu?!`,
mentions: [menc_os2]}, { quoted: selo });
}, 7000);

}
};