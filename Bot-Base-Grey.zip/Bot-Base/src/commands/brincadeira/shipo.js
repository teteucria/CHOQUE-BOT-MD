module.exports = {
nome: ["shipo"],
executar: async ({
isGroup,
isModobn,
menc_os2,
mention,
mess,
prefix,
reply,
groupMembers
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply("Hmph! Marca uma pessoa do grupo pra eu encontrar o par dela... E-eu sou boa nisso, sabe?! Então não erra, viu?!");
 await mention(`♥️ Hmph! E-eu shipo *@${groupMembers[Math.floor(Math.random() * groupMembers.length)].id.split("@")[0]} & @${menc_os2.split("@")[0]}* com uma porcentagem de *${Math.floor(Math.random() * 100) + "%"}*... Não fica achando que eu faço isso por qualquer um, tá?!`);
}
};