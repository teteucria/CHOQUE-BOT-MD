module.exports = {
nome: ["infiel"],
executar: async ({
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));

kira.sendMessage(from, {text: `⚠️ Hmph! Investigando a ficha de *@${menc_os2.split("@")[0]}*... será que é infiel? 👀 F-fica quietinho(a) que eu já descubro, tá?!`,
mentions: [menc_os2]}, { quoted: selo });

setTimeout(async () => {
let random = Math.floor(Math.random() * 101);

let frase = "";
if (random <= 20) frase = "Esse aí é quase um santo! 😇... hmph, até eu acreditei, viu?!";
else if (random <= 50)
frase = "Hmm... já começou a olhar pros lados. 👀 N-não me olha assim, baka!";
else if (random <= 80)
frase =
  "⚡ Perigo! Pode sumir e voltar com desculpa esfarrapada... E-eu só tô avisando porque quero, tá?!";
else
frase = "🔥 100% infiel! Nem o celular fica desbloqueado perto de você... hmph, cuidado, viu?!";

let barra = "█".repeat(Math.floor(random / 10)) + "░".repeat(10 - Math.floor(random / 10));

kira.sendMessage(from, {image: {url: `https://storage.oberonhosting.com.br/media/744d0516ce7ea886.jpg`},
caption:
`💔 Hmph! Análise concluída...\n\n` +
`👤 Usuário: *@${menc_os2.split("@")[0]}*\n` +
`📊 Infidelidade: *${random}%*\n\n` +
`📈 Barra de Infidelidade:\n[${barra}]\n\n` +
`💬 ${frase}`,
mentions: [menc_os2]}, {quoted: selo});
}, 7000);
}
};