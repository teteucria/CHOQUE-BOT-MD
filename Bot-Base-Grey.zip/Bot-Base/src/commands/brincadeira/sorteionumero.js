module.exports = {
nome: ["sorteionumero","sorteionumeros"],
executar: async ({
args,
isGroup,
isGroupAdmins,
mess,
reply,
  prefix,
groupMetadata
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!args.length > 1)
 return reply(`Hmph! Coloca algo após o comando, bobinho(a)... Por exemplo: *${prefix}sorteio* _de 100 R$_. N-não me faz repetir, tá?!`);
try {
 reply(`🤖🎉 Hmph! Parabéns ao(a) sortudo(a) do número *${Math.floor(Math.random() * groupMetadata.participants.length)}*, por ganhar o sorteio!\n–\n• Pra mais informações, fala com o(a) adm responsável pelo sorteio: _“${q}”_. S-só não fica se achando, viu?!`);
} catch (error) {
 reply("Hmph! Deu erro... Tenta de novo, baka! N-não foi culpa minha, tá?!");
}
}
};