module.exports = {
nome: ["feio"],
executar: async ({
from,
image,
imgfeio,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(from, {text: `Hmph! Deixa eu pesquisar a ficha de *@${menc_os2.split("@")[0]}*... fica aí esperando, viu?!`, mentions: [menc_os2]}, {quoted: selo});
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
feio = random;
if (feio < 20) {
 var bo = "Hmph! N-não é feio, viu?! ...mas não fica se achando, baka!";
 } else if (feio == 21) {
 var bo = "+/- feio... que vergonha alheia, viu?!";
 } else if (feio == 23) {
 var bo = "+/- feio... mas tem salvação, tá?!";
 } else if (feio == 24) {
 var bo = "+/- feio... não é como se eu fosse te julgar, claro!";
 } else if (feio == 25) {
 var bo = "+/- feio... bobinho(a), passa vergonha mas passa";
 } else if (feio == 26) {
 var bo = "+/- feio... que situação, hmph!";
 } else if (feio == 27) {
 var bo = "+/- feio... mas ninguém é perfeito, tá?!";
 } else if (feio == 2) {
 var bo = "+/- feio... s-só digo isso por você, viu?!";
 } else if (feio == 29) {
 var bo = "+/- feio... hmph, fica na sua!";
 } else if (feio == 30) {
 var bo = "+/- feio... e-eu tava sendo gentil, claro!";
 } else if (feio == 31) {
 var bo = "ainda tá na média... e-eu não tô julgando, tá?!";
 } else if (feio == 32) {
 var bo = "dá pra pegar umas(ns) novinha(o) ainda... hmph, não é conselho meu, claro!";
 } else if (feio == 33) {
 var bo = "D-dá pra pegar umas(ns) novinha(o) ainda... só não se empolga, bobinho(a)!";
 } else if (feio == 34) {
 var bo = "é fein, mas tem bom coração... hmph, isso conta muito, viu?!";
 } else if (feio == 35) {
 var bo = "tá na média, mas não deixa de ser feii... sinto muito, baka!";
 } else if (feio == 36) {
 var bo = "bonitin, mas é feio com orgulho... que isso, viu?!";
 } else if (feio == 37) {
 var bo = "feio e preguiçoso(a)... vai se arrumar, praga feia, hmph!";
 } else if (feio == 3) {
 var bo = "tenho... hmph, só te falo se você prometer não chorar, bobinho(a)!";
 } else if (feio == 39) {
 var bo = "feio, mas um banho e se arrumar resolve... n-não é como se eu quisesse te ajudar, claro!";
 } else if (feio == 40) {
 var bo = "fein... mas não existe gente feia, existe gente que não conhece os produtos Jequiti, viu?! Hmph!";
 } else if (feio == 41) {
 var bo = "você é feio, mas é legal... continua assim, hmph, t-tá?!";
 } else if (feio == 42) {
 var bo = "Nada que uma maquiagem e se arrumar não resolva... E-eu tenho um kit de confeitaria que faz milagre, mas não é seu, baka!";
 } else if (feio == 43) {
 var bo = "Feio que dói de ver... compra uma máscara que melhora, viu?! Hmph!";
 } else if (feio == 44) {
 var bo = "Feio, mas nada que um saco na cabeça não resolva, né?! ...Hmph, eu sou muito grossa, desculpa!";
 } else if (feio == 45) {
 var bo = "você é feio, mas tem bom gosto... isso conta muito, viu?! N-não é elogio!";
 } else if (feio == 46) {
 var bo = "feio, mas tem muitos amigos... hmph, isso prova que você é gente boa!";
 } else if (feio == 47) {
 var bo = "é feio, mas tem lábia pra pegar várias novinha... n-não me olha assim, baka!";
 } else if (feio == 4) {
 var bo = "feio e ainda não sabe se vestir... vixi, que situação, viu?!";
 } else if (feio == 49) {
 var bo = "feiooo demais, vey... Hmph, eu falei, não fica bravo(a) comigo!";
 } else if (feio == 50) {
 var bo = "você é feio, mas não se enxerga... E-eu tenho um espelho emprestado, se quiser, bobinho(a)!";
 } else if (feio > 51) {
 var bo = "você é feio demais, bixo... Hmph, n-não é como se eu me importasse, tá?!";
 }
await kira.sendMessage(from, {image: {url: imgfeio},
caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa feia?\n• A porcentagem de chance é *${random}%*, ${bo}. Hmph, e-eu só tô falando porque você insistiu, tá?!`,
mentions: [menc_os2], thumbnail: null}, {quoted: selo});
}, 7000);
}
};