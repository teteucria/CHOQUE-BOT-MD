module.exports = {
nome: ["gostoso"],
executar: async ({
caption,
from,
gifPlayback,
image,
imggostoso,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
quoted,
random,
reply,
selo,
setTimeout,
text,
url,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(
from,
{
 text: `Hmph! Deixa eu pesquisar a ficha de @${menc_os2.split("@")[0]}... fica quietinho(a) aí, já volto, tá?!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(
from,
{
image: { url: imggostoso },
 caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa gostosa?\n• A porcentagem de chance é *${random}%*... Hmph, e-eu sou boa nisso, pode confiar, viu?!`,
gifPlayback: true,
mentions: [menc_os2],
},
{ quoted: selo }
);
}, 7000);
}
};