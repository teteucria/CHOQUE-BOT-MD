module.exports = {
nome: ["chute","chutar"],
executar: async ({
chutecmd,
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply("Hmph! Marca o alvo que você quer dar um chute, bobinho(a)... a mensagem ou o @, tá?! Até pra chutar alguém você erra!");
await kira.sendMessage(from, {video: {url: chutecmd}, gifPlayback: true, caption: `Você acabou de dar um chute em *@${menc_os2.split("@")[0]}*... E-eu só fiz isso porque você pediu, não se acostume, tá?!`,
mentions: [menc_os2]}, {quoted: selo});
}
};