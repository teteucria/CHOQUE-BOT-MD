module.exports = {
nome: ["rankpau"],
executar: async ({
somembros,
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkpau
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `Hmph! *RANK DOS 5 PAU MAIOR DO GRUPO 📏*\n—\n`;
 TMPAU = [
 "Pequeno pra cact, se mata maluco... hmph, não fica triste, baka!",
 `Pequenininho chega a ser até fofo... n-não é como se eu achasse graça, tá?!`,
 `Menor que meu dedo mindinho, pequeno demais... e-eu tenho dedo fino, mas nem tanto, viu?!`,
 `Até que dá pra sentir, tá na média... hmph, pelo menos é normal, bobinho(a)!`,
 `Até que é grandinho... n-não tô elogiando, claro, tá?!`,
 `Grande até!... e-eu não vou confirmar mais nada, viu?!`,
 `Gigantesco igual meu braço... hmph, o que mais dizer, baka!`,
 `Enorme, quase chega no útero... s-socorro, que escândalo, tá?!`,
 `Grandão demais, ein... e uii, hmph, fica na sua, viu?!`,
 `Vara de pegar manga, grande demais... como sai na rua assim, hein?! N-não me olha, baka!`,
 "Que grandão, ein... nasceu metade animal, hmph, só digo isso!",
 ];
for (var i = 0; i < 5; i++) {
ABC += `• *${i + 1}°* @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMPAU[Math.floor(Math.random() * TMPAU.length)]} )\n`;
}
await mencionarIMG(ABC, rnkpau);
}
};