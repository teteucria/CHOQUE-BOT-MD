module.exports = {
nome: ["sorteio"],
executar: async ({
from,
isGroup,
isGroupAdmins,
mess,
q,
quoted,
reply,
selo,
kira,
  prefix,
groupMembers
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
 if (!q) return reply(`Hmph! Coloca algo após o comando, bobinho(a)... Por exemplo: *${prefix}sorteio* _de 100 R$_. Até pra sortear você erra, viu?!`);
try {
    const sorteado = groupMembers[Math.floor(Math.random() * groupMembers.length)].id;
    await kira.sendMessage(from, {text: `🤖🎉 Hmph! Parabéns, *@${sorteado.split("@")[0]}*... Você acaba de ser contemplado(a) como o(a) ganhador(a) do sorteio, viu?!\n–\n• Pra mais informações, fala com o(a) responsável do sorteio: _“${q}”_. N-não é como se eu tivesse manipulado pra te dar sorte, tá?!`}, {quoted: selo});
} catch (error) {
 reply("Hmph! Deu erro... Tenta de novo, baka! N-não foi culpa minha, tá?!");
}
}
};