module.exports = {
nome: ["surubao","suruba"],
executar: async ({
somembros,
isGroup,
isModobn,
mention,
mess,
prefix,
q,
reply
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!q) return reply(`Hmph! Eita... coloca o número de pessoas após o comando, bobinho(a)! Até eu, que sou boa nisso, preciso saber o número, tá?!`);
 if (Number(q) > 5) return reply("Hmph! Coloca um número menor, ou seja, abaixo de *5*... N-não fica exagerando, baka!");
emojiskk = ["🥵", "😈", "🫣", "😏"];
emojis = emojiskk[Math.floor(Math.random() * emojiskk.length)];
frasekk = [
  `tá querendo relações sexuais com ${q}, topa?... hmph, e-eu só repasso, viu?!`,
  `quer que *${q}* pessoas venham de *chicote, algema e corda de alpinista*... s-socorro, que loucura, tá?!`,
  `quer que ${q} pessoas deem tapa na cara, lhe chamem de cachorra e fud3r bem gostosinho... hmph, n-não é como se eu aprovasse, baka!`,
];
context = frasekk[Math.floor(Math.random() * frasekk.length)];
 ABC = `Hmph! ${emojis} @${sender.split("@")[0]} ${context}\n\n`;
for (var i = 0; i < q; i++) {
ABC += `@${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n`;
}
await mention(ABC);
}
};