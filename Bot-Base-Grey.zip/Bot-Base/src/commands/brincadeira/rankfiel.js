module.exports = {
nome: ["rankfiel","rankfieis"],
executar: async ({
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkfiel,
somembros
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));

 let ABC = `💖 Hmph! *RANK DOS 5 MAIS FIÉIS DO GRUPO!*\n—\n`;
 let TMFIÉIS = [
 "Esse aí nunca trai nem no zap... hmph, raridade!",
 "Companheiro fiel até no silêncio... n-não é como se eu me emocionasse, claro!",
 "Não larga da parceira(o), lealdade total... que bonito, bobinho(a)!",
 "Confiança é a palavra dele(a)... vou até anotar, viu?!",
 "Exemplo de fidelidade pro grupo... quase perfeito(a), hmph!",
 "Sempre presente, nunca decepciona... e-eu não tô impressionada, tá?!",
 "Amor sincero e inabalável... que dure para sempre, viu?!",
 "Pode confiar, nunca te deixa na mão... que responsabilidade, hmph!",
 "Coração puro, fiel até o fim... um raríssimo, baka!",
 "Esse aí é hard level de fidelidade... eu reconheço quando sou boa nisso, e ele(a) é, viu?!",
 ];

for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMFIÉIS[Math.floor(Math.random() * TMFIÉIS.length)]} )\n`;
}

await mencionarIMG(ABC, rnkfiel);
}
}
};