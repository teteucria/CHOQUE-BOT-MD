module.exports = {
nome: ["rankcorno","rankcornos"],
executar: async ({
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkcorno,
somembros
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `🐂 Hmph! *RANK DOS 5 MAIS CORNOS DO GRUPO!*\n—\n`;
 TMCRN = [
 "Familiar, leva até chifre com os parentes... hmph, que situação!",
 "Masoquista, leva chifre mas não larga a mulher... vai se amar, baka!",
 "Atéu, leva chifre e não acredita... n-não é como se eu quisesse te consolar, tá?!",
 "Político, só faz promessa e não cumpre o que fala... clássico, hmph!",
 "Esse aí leva chifre, vai embora e volta por causa das crianças... hmph, que romance complicado, viu?!",
 "Xuxa, não larga a mulher por causa dos baixinhos... e-eu até acho fofo, mas não conta pra ninguém!",
 "Famoso, por onde passa é reconhecido... s-só não se orgulha disso, baka!",
 "Inflação, a cada dia que passa o chifre aumenta... hmph, vai negociar com seu coração, viu?!",
 ];
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMCRN[Math.floor(Math.random() * TMCRN.length)]} )\n`;
}
await mencionarIMG(ABC, rnkcorno);
}
};