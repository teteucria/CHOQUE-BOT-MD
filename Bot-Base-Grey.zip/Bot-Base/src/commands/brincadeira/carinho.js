module.exports = {
nome: ["carinho"],
executar: async ({
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
quoted,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
 if (typeof isModobn !== 'undefined' && !isModobn) return reply("Hmph! O modo brincadeira tá desativado... N-não é como se eu quisesse brincar mesmo, tá?!");
 if (!menc_os2) return reply("Hmph! Marca o alvo que você quer dar um carinho, bobinho(a)... a mensagem ou o @, tá?! Até pra pedir carinho você erra!");
await kira.sendMessage(from, {video: {url: `https://telegra.ph/file/2b6b4f4e38214bd6164ce.mp4` },
gifPlayback: true, caption: `Você acabou de dar um carinho no(a) *@${menc_os2.split("@")[0]}* ✨... Hmph, não é como se eu fosse fazer isso por qualquer pessoa, viu?!`,
mentions: [menc_os2]}, {quoted: selo});
}
};