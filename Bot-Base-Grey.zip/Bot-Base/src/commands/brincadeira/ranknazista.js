module.exports = {
nome: ["ranknazista","ranknazistas"],
executar: async ({
somembros,
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnknazista
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `*Hmph! 💂‍♂RANK DOS 5 MAIS NAZISTAS DO GRUPO 卐🤡*\n—\n`;
 TMNZTS = [
 "Soldado nazista, marcha com estilo... hmph, que ridículo, viu?!",
 "Comandante implacável, lidera com rigor... n-não é como se eu desse importância, tá?!",
 "Nazista estrategista, conquista territórios... que estratégia fraca, baka!",
 "Mestre da ordem, disciplina em primeiro lugar... hmph, pelo menos tem foco, viu?!",
 "Soldado de elite, nazista hardcore... credo, s-sai daqui!",
 "General invencível, domina as batalhas... que mania, hein?!",
 "Nazista disciplinado, fiel à causa... hmph, a causa errada, baka!",
 "Líder autoritário, impõe respeito... e-eu não tô impressionada, tá?!",
 "Soldado feroz, nazismo no coração... que coração estranho, viu?!",
 "Mestre da propaganda, convence com palavras... n-não me convence não, baka!",
 "Nazista moderno, tecnologia na guerra... hmph, que desperdício de tecnologia!",
 "Máquina de guerra, implacável e eficiente... s-se cuida, tá?!",
 "Comandante supremo, nazismo eterno... hmph, até quando, hein?!",
 "Soldado leal, marcha em nome da ideologia... e-eu prefiro marchar pra confeitaria, baka!",
 "Nazista clássico, revive o passado... que passado ruim, viu?!",
 "General poderoso, nazista do século XXI... credo, no meu século não, hmph!",
 "Comandante inabalável, nazista de honra... que honra duvidosa, tá?!",
 "Soldado devoto, nazismo no sangue... hmph, troca essa veia, baka!",
 "Mestre da retórica nazista, convence a todos... e-eu não caio nessa, viu?!",
 "Nazista visionário, futuro sob a suástica... hmph, que futuro sombrio, s-sou eu que digo!",
 ];
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMNZTS[Math.floor(Math.random() * TMNZTS.length)]} )\n`;
}
await mencionarIMG(ABC, rnknazista);
}
};