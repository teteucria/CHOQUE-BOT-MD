module.exports = {
nome: ["ranksafado","ranksafados"],
executar: async ({
somembros,
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnksafado
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `Hmph! RANK DOS 5 MAIS SAFADOS DO GRUPO 🥵🔥\n\n`;
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n`;
}
await mencionarIMG(ABC, rnksafado);
}
};