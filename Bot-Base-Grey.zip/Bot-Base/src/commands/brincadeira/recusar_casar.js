const { Pedido } = require("../../database");

module.exports = {
nome: ["recusar_casar"],
executar: async ({
q,
reply,
sender
}) => {

const pedidoId = q.trim();
const pedido = await Pedido.findOne({
id: pedidoId
});
if (!pedido) return;
if (sender !== pedido.p2) {
 return reply("❌ Hmph! Você não pode recusar algo que não foi pra você... Não fica se metendo no romance alheio, baka!");
}
 reply(`💔 Hmph! Infelizmente @${pedido.p2.split("@")[0]} deu um fora em @${pedido.p1.split("@")[0]}... N-não é como se eu estivesse triste por vocês, claro. Tanto faz, viu?!`, {mentions: [pedido.p1, pedido.p2]});
await Pedido.deleteOne({
id: pedidoId
});
}
};