module.exports = {
nome: ["baiana"],
executar: async ({
from,
image,
imgbaiana,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(from, { text: `Hmph! Deixa eu pesquisar a ficha de @${menc_os2.split("@")[0]}... aguenta aí, viu?!`, mentions: [menc_os2]}, {quoted: selo});
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(from, {image: {url: imgbaiana}, caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa baiana?\n• A porcentagem de chance é *${random}%*... Hmph, n-não fica achando que eu escolhi o número por você, baka!`, mentions: [menc_os2]}, {quoted: selo});
}, 7000);
}
};