module.exports = {
nome: ["baiano"],
executar: async ({
from,
imgbaiano,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(from, {text: `Hmph! Deixa eu pesquisar a ficha de @${menc_os2.split("@")[0]}... fica quieto(a) que eu já volto, tá?!`, mentions: [menc_os2]}, { quoted: selo });
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(from, {image: {url: imgbaiano}, caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa baiana?\n• A porcentagem de chance é *${random}%*... Hmph, n-não é como se eu estivesse torcendo pelo resultado, tá?!`, mentions: [menc_os2]},{ quoted: selo });
}, 7000);
}
};