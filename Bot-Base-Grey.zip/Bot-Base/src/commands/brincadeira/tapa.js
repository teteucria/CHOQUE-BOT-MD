module.exports = {
nome: ["tapa"],
executar: async ({
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
quoted,
reply,
selo,
tapacmd,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply("Hmph! Marca o alvo que você quer dar um tapa, bobinho(a)... a mensagem ou o @, tá?! Que preguiça de repetir, viu?!");
await kira.sendMessage(from, {video: {url: tapacmd}, gifPlayback: true, caption: `Você acabou de dar um tapa na raba de *@${menc_os2.split("@")[0]}*. 😼 Hmph! Não é como se eu tivesse ajudado, claro, tá?!`,
mentions: [menc_os2]}, {quoted: selo});
}
};