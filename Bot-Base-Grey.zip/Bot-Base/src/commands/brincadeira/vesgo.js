module.exports = {
nome: ["vesgo"],
executar: async ({
from,
imgvesgo,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(from, {text: `Hmph! Deixa eu pesquisar a ficha de vesgo @${menc_os2.split("@")[0]}... aguarde, viu?!`,
mentions: [menc_os2]}, {quoted: selo});
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(
from,
{
image: { url: imgvesgo },
 caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa vesga?\n• A porcentagem de chance é *${random}%*... Hmph, e-eu quase caí da cadeira de tanto rir, mas não conta pra ninguém, tá?!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
}, 7000);
}
};