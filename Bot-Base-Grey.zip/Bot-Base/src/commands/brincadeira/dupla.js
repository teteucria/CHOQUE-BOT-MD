const { Casal } = require("../../database");

module.exports = {
nome: ["dupla", "casal"],
executar: async ({
from,
info,
moment,
reagir,
reply,
sender,
kira,
prefix
}) => {

const casalEncontrado = await Casal.findOne({
$or: [
{ p1: sender },
{ p2: sender }
]
});
const userCasal = casalEncontrado ? casalEncontrado.lean() : null;

if (!userCasal) {
 return reply("Hmph! Você ainda não tem uma dupla... Usa o comando casar pra pedir alguém, bobinho(a)! N-não é como se eu quisesse ver você sozinho(a), claro!");
}

await reagir(from, "💖");
let dataCasamento = moment(userCasal.data, "YYYY-MM-DD HH:mm:ss");
let agora = moment().tz("America/Sao_Paulo");
let meses = agora.diff(dataCasamento, "months");
dataCasamento.add(meses, "months");
let dias = agora.diff(dataCasamento, "days");
dataCasamento.add(dias, "days");
let horas = agora.diff(dataCasamento, "hours");
const corpoCasal = [
`💏 *INFORMAÇÕES DA DUPLA*`,
` `,
`👤 *P1:* @${userCasal.p1.split("@")[0]}`,
`👤 *P2:* @${userCasal.p2.split("@")[0]}`,
` `,
`⏳ *Tempo de União:*`,
`🗓️ ${dias} Dias & ${horas} Horas`,
` `,
`_"O amor é capaz de unir laços_`,
`_muito fortes e também firmes."_`,
` `,
  `✨ *STATUS DO CASAL* ✨... Hmph, não é como se eu estivesse com inveja do romance de vocês, tá?!`
].join("\n");

await kira.sendMessage(
from,
{
interactiveMessage: {
title: corpoCasal,
footer: "*kira SYSTEM - ROMANCE*",
buttons: [
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: "💔 TERMINAR",
id: `${prefix}terminar`
})
}
],
image: {
url: "https://i.ibb.co/m5tHXjTP/2a7d1d0c-fff2-471e-9916-f3f4f447fc44.jpg"
},
contextInfo: {
mentionedJid: [
userCasal.p1,
userCasal.p2
]
}
}
},
{quoted: info});
}
};