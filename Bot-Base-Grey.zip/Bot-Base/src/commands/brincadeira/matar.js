module.exports = {
nome: ["matar","mata"],
executar: async ({
from,
isGroup,
isModobn,
matarcmd,
menc_os2,
mentions,
mess,
prefix,
quoted,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply("Hmph! Marca o alvo que você quer matar, bobinho(a)... a mensagem ou o @, tá?! V-você quer que eu adivinhe?!");
kira.sendMessage(from, {video: {url: matarcmd}, gifPlayback: true, caption: `Você acabou de matar o(a) *@${menc_os2.split("@")[0]}*, seu... 😵‍💫💅🏻 Hmph! Não é como se eu aprovasse, mas... tanto faz, baka!`,
mentions: [menc_os2]}, {quoted: selo});
}
};