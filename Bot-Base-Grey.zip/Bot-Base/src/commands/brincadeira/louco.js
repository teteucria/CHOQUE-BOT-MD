module.exports = {
nome: ["louco"],
executar: async ({
from,
imglouco,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(
from,
{
 text: `Hmph! Deixa eu pesquisar a ficha de @${menc_os2.split("@")[0]}... fica calmo(a), já volto, tá?!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(
from,
{
image: { url: imglouco },
 caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa louca?\n• A porcentagem de chance é *${random}%*... Hmph, n-não é como se eu quisesse te assustar, viu?!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
}, 7000);
}
};