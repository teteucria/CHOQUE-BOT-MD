module.exports = {
nome: ["dogolpe"],
executar: async ({
from,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
quoted,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (!menc_os2) return reply("Hmph! Marca a mensagem com o comando ou o @ do usuário, bobinho(a)... Até eu, a melhor da academia, não consigo adivinhar!");
randomF = [
  "em iludir pessoas... hmph, que mania!",
  "em ferir os sentimentos, baka!",
  "em dar chifre... não é como se eu julgasse, claro!",
];
await kira.sendMessage(from, {text: `♥️☠️ Hmph! *@${menc_os2.split("@")[0]}* é especialista *${randomF[Math.floor(Math.random() * randomF.length)]}*. N-não fica triste, eu tava só sendo sincera, viu?!`,
mentions: [menc_os2]}, {quoted: selo});
}
};