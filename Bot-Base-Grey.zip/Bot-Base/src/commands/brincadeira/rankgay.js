module.exports = {
nome: ["rankgay","rankgays"],
executar: async ({
somembros,
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkgay
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `🏳️‍🌈 Hmph! *RANK DOS 5 MAIS GAYS DO GRUPO!*\n—\n`;
 TMGAYS = [
 "Esse aí gosta de cheirar banana até umas horas kakak... hmph, sem comentários!",
 "Gosta de ser dominado e chicoteado... e-eu não vou comentar, tá?!",
 "Viadinho gente boa, nada contra os veados... respeito, viu?! Hmph!",
 "Esse aí roda mais que roda de caminhão... que canseira, baka!",
 "Mapoa é você, meu amor?... hmph, pergunta pra pessoa, não pra mim!",
 "Esse aí ainda tá no armário, a franga tá presa... s-sai daí, baka!",
 "Profissional na garganta profunda... e-eu não confirmo nada, viu?!",
 "Essa bicha é finíssima... que classe, hmph, eu aprovo!",
 "Essa aí precisa sair do closet ainda... t-tem coragem, viu?! Eu torço por você!",
 "Vixi, esse aí é vitaminado... cheio de energia, hmph!",
 "Vixi, um gay vulgo Irene... icon, s-só isso que digo, baka!",
 "Poc fechosa, amo tu, mona!... hmph, não é como se eu me importasse com a moda, claro!",
 ];
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMGAYS[Math.floor(Math.random() * TMGAYS.length)]} )\n`;
}
await mencionarIMG(ABC, rnkgay);
}
};