module.exports = {
nome: ["rankgostosos","rankgostoso"],
executar: async ({
somembros,
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkgostoso
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `Hmph! *RANK DOS 5 MAIS GOSTOSOS DO GRUPO* 😏🔥\n—\n`;
 TMGSTS = [
 "Você tá olhando pra um semi-deus... hmph, modéstia, baka!",
 "Mds, me apaixonei! Passa o insta, gatinho?... não é como se eu quisesse, claro!",
 "Ei, ei, gatinhas, o gostosão do grupo chegou... que presunção, viu?!",
 "Gostoso? É, pena que é homem galinha... hmph, que desperdício!",
 "Não sei se comparo esse gostoso com o Ares Ridalgo... s-só acho que perdeu, baka!",
 "Cruz credo, por que tu tá aqui? Tu é feio, desgraça... hmph, eu tava só brincando, tá?!",
 ];
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMGSTS[Math.floor(Math.random() * TMGSTS.length)]} )\n`;
}
await mencionarIMG(ABC, rnkgostoso);
}
};