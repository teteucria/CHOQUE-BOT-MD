module.exports = {
nome: ["quando"],
executar: async ({
args,
reply,
body
}) => {

 if (args.length < 1) return reply("Hmph! Digita a pergunta, bobinho(a)... Até eu, que sou boa nisso, preciso saber o que responder, tá?!");
const meupirul = [
"Hoje",
"Amanhã",
"Nunca",
"dia",
"semana",
"mês",
"ano",
];
const meupirul2 = ["dias", "semanas", "meses", "anos"];
randomm = meupirul[Math.floor(Math.random() * meupirul.length)];
random2 = `${Math.floor(Math.random() * 11) + 1}`;
if (
randomm == "Hoje" ||
randomm == "Amanhã" ||
randomm == "Nunca"
) {
 texto = `Hmph! Pergunta: ${body.slice(1)}\nResposta: ${randomm}... e-eu sei porque sou boa nisso, tá?!`;
} else if (random2 == 1) {
 texto = `Hmph! Pergunta: ${body.slice(1)}\nResposta:1 ${randomm}... não se acostume com isso, viu?!`;
} else {
random3 = meupirul2[Math.floor(Math.random() * meupirul2.length)];
 texto = `Hmph! Pergunta: ${body.slice(1)}\nResposta: ${random2} ${random3}... f-fica esperto(a) que eu não adivinho duas vezes, tá?!`;
}
reply(texto);
}
};