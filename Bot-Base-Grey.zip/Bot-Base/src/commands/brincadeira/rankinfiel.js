module.exports = {
nome: ["rankinfiel","rankinfieis"],
executar: async ({
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkinfiel,
somembros
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));

 let ABC = `💔 Hmph! *RANK DOS 5 MAIS INFIEIS DO GRUPO!*\n—\n`;
 let TMINFIEIS = [
 "Esse aí muda de crush todo dia... que coração confuso, hmph!",
 "Cuidado, coração volúvel demais... s-sou eu que aviso, tá?!",
 "Não segura ninguém, sempre traindo... que triste, viu?!",
 "Segue o fluxo, ninguém segura... vai se ajeitar, baka!",
 "Amor passageiro é seu lema... hmph, nem se esforça, hein!",
 "Já foi de todos os grupos, cuidado... e-eu não tô julgando, claro!",
 "O famoso coração quebrado andando... que drama, viu?!",
 "Se apaixonar? Só por 5 minutos... hmph, nem pra dar uma chance!",
 "Desleal mas carismático(a)... que perigo, bobinho(a)!",
 "Sempre um romance novo na manga... e-eu até queria, mas não confesso, tá?!",
 ];

for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMINFIEIS[Math.floor(Math.random() * TMINFIEIS.length)]} )\n`;
}

await mencionarIMG(ABC, rnkinfiel);
}
}
};