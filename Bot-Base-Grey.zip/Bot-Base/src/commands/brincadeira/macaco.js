module.exports = {
nome: ["macaco"],
executar: async ({
from,
imgmacaco,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(
from,
{
 text: `Hmph! Deixa eu pesquisar a ficha de @${menc_os2.split("@")[0]}... aguarda aí, bobinho(a), já volto!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(
from,
{
image: { url: imgmacaco },
 caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser um macaco?\n• A porcentagem de chance é *${random}%*... Hmph, n-não é como se eu estivesse rindo de você, tá?!`,
mentions: [menc_os2],
},
{ quoted: selo }
);
}, 7000);
}
};