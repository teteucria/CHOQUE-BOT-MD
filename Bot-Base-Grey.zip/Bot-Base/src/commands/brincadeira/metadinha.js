module.exports = {
nome: ["metadinha"],
executar: async ({
fetchJson,
from,
mess,
reagir,
reply,
selo,
kira
}) => {

try {
await reagir(from, "💖");
anuData = await fetchJson("https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json");
let selectRandom = anuData[Math.floor(Math.random() * anuData.length)];
await kira.sendMessage(from, {image: {url: selectRandom.male}, caption: "• Perfil Masculino... Hmph, não é como se eu tivesse escolhido pra você, tá?!"}, {quoted: selo});
await kira.sendMessage(from, {image: {url: selectRandom.female}, caption: `• Perfil Feminino... e-eu até que achei bonito, mas não fica achando que eu me importo, viu?!`}, {quoted: selo});
} catch (e) {
reply(mess.error());
}
}
};