module.exports = {
nome: ["bebado"],
executar: async ({
from,
imgbebado,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(from, {text: `Hmph! Deixa eu pesquisar a ficha de @${menc_os2.split("@")[0]}... aguarde, viu?! N-não fica com pressa!`, mentions: [menc_os2]}, {quoted: selo});
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(from, {image: {url: imgbebado}, caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa bêbada?\n• A porcentagem de chance é *${random}%*... Hmph, e-eu que sofro pra calcular isso, tá?!`,
mentions: [menc_os2]}, {quoted: selo});
}, 7000);
}
};