module.exports = {
nome: ["rankputa","rankputas"],
executar: async ({
somembros,
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkputa
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `Hmph! RANK DAS 5 MAIS PUTAS DO GRUPO 😈🔥\n\n`;
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]}\n`;
}
await mencionarIMG(ABC, rnkputa);
}
};