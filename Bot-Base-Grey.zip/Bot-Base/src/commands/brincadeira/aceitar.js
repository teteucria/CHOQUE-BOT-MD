module.exports = {
nome: ["aceitar"],
executar: async ({
from,
isBotGroupAdmins,
isGroup,
isGroupAdmins,
mess,
reply,
kira
}) => {

{
if (!isGroup) return reply(mess.onlyGroup());
if (!isGroupAdmins) return reply(mess.onlyAdmins());
if (!isBotGroupAdmins) return reply(mess.onlyBotAdmin());
const pendentes = await kira.groupRequestParticipantsList(from);
const total = pendentes?.length || 0;
if (total === 0)
 return reply('Hmph! *N-não tem solicitações pendentes...* Eu verifiquei direitinho, viu?! Não me faça perder tempo à toa, baka!');
for (const p of pendentes) {
await kira.groupRequestParticipantsUpdate(from, [p.jid], 'approve');
}
 reply(`Hmph! *${total} solicitação(ões) aceita(s)!* E-eu fiz isso porque quis, não é como se eu me importasse com o seu grupo, tá?!`);
}
}
};