module.exports = {
nome: ["morte","death"],
executar: async ({
args,
axios,
deathcmd,
from,
isGroup,
isModobn,
mentions,
mess,
prefix,
reply,
selo,
sender,
  command,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 if (args.length == 0) return reply(`Hmph! Tá faltando o nome da pessoa... Por exemplo: ${prefix + command} Victor. N-não é difícil assim, baka!`);
predea = await axios.get(`https://api.agify.io/?name=${encodeURIComponent(args[0])}`);
 if (predea.data.age == null) return reply(`Hmph! Nome inválido... Insere um sem acentos, emojis, números ou coisa assim, viu?! S-sou eu que tenho que ensinar tudo, hein?!`);
await kira.sendMessage(from, {video: {url: deathcmd}, gifPlayback: true, caption: `Hmph! Pessoas com esse nome citado, “${predea.data.name}”, tendem a morrer aos ${predea.data.age} anos... N-não é como se eu quisesse assustar você, tá?! V-você que pediu, viu?!`,
mentions: [sender]}, {quoted: selo});
}
};