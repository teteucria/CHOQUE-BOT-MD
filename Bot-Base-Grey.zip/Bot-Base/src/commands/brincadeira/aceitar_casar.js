const { Casal, Pedido } = require("../../database");

module.exports = {
nome: ["aceitar_casar"],
executar: async ({
from,
moment,
q,
reagir,
reply,
sender
}) => {

const pedidoId = q.trim();

const pedido = await Pedido.findOne({
id: pedidoId
});

if (!pedido)
 return reply("❌ Hmph! Esse pedido expirou ou já foi respondido... E-eu procurei, mas não tem mais nada aqui, viu?! Tanto faz, baka!");

if (sender !== pedido.p2) {
 return reply(
  `❌ Hmph! S-só o(a) @${pedido.p2.split("@")[0]} pode aceitar este pedido... Não fica se intrometendo, tá?!`,
{
mentions: [pedido.p2]
}
);
}

const alguemCasou = await Casal.findOne({
$or: [
{ p1: pedido.p1 },
{ p2: pedido.p1 },
{ p1: pedido.p2 },
{ p2: pedido.p2 }
]
});

if (alguemCasou) {

await Pedido.deleteOne({
_id: pedido._id
});

 return reply(
  "Hmph! Tarde demais... Um de vocês já se casou com outra pessoa. N-não é como se eu estivesse triste por você, claro, baka!"
);

}

await Casal.create({
p1: pedido.p1,
p2: pedido.p2,
data: moment()
.tz("America/Sao_Paulo")
.format("YYYY-MM-DD HH:mm:ss")
});

await Pedido.deleteOne({
_id: pedido._id
});

 reply(
  `🎉 Parabéns... @${pedido.p2.split("@")[0]} e @${pedido.p1.split("@")[0]} agora estão oficialmente casados! Hmph, não é como se eu tivesse torcido por vocês, tá?! Sejam felizes, viu?!`,
{
mentions: [pedido.p1, pedido.p2]
}
);
await reagir(from, "❤️");
}
};