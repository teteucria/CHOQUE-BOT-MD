module.exports = {
nome: ["rankgostosas","rankgostosa"],
executar: async ({
somembros,
isGroup,
isModobn,
mencionarIMG,
mess,
prefix,
reply,
rnkgostosa
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
 ABC = `Hmph! *RANK DAS 5 MAIS GOSTOSAS DO GRUPO* 😏🔥\n—\n`;
 TMGSTS = [
 "Calma, novinha, assim eu não resisto... hmph, segura essa, viu?!",
 "Mds, me apaixonei no sorriso dessa gata... que azar o meu, baka!",
 "Eita gatinha, passa o insta quando? rs... n-não é como se eu quisesse seguir, tá?!",
 "Credo, sai daqui, dragão... hmph, nem comento!",
 "Ui, gata, que rabão, ein... e-eu não tava olhando, viu?!",
 ];
for (var i = 0; i < 5; i++) {
ABC += `• ${i + 1}° *[${Math.floor(Math.random() * 100)}%]* - @${somembros[Math.floor(Math.random() * somembros.length)].split("@")[0]} -> ( ${TMGSTS[Math.floor(Math.random() * TMGSTS.length)]} )\n`;
}
await mencionarIMG(ABC, rnkgostosa);
}
};