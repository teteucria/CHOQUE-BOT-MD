module.exports = {
nome: ["corno"],
executar: async ({
from,
imgcorno,
isGroup,
isModobn,
menc_os2,
mentions,
mess,
prefix,
reply,
selo,
kira
}) => {

if (!isGroup) return reply(mess.onlyGroup());
if (!isModobn) return reply(mess.onlyGroupFun(prefix));
await kira.sendMessage(from, {text: `Hmph! Deixa eu pesquisar a ficha de corno @${menc_os2.split("@")[0]}... aguarde, viu?!`,
mentions: [menc_os2]}, {quoted: selo});
setTimeout(async () => {
random = `${Math.floor(Math.random() * 110)}`;
await kira.sendMessage(from, {image: { url: imgcorno },
caption: `O quanto *@${menc_os2.split("@")[0]}* pode ser uma pessoa chifruda?\n• A porcentagem de chance é *${random}%*... Hmph, e-eu tenho pena, mas não é como se eu me importasse, tá?!`,
mentions: [menc_os2]}, {quoted: selo});
}, 7000);
}
};