const { Casal, Pedido } = require("../../database");

module.exports = {
nome: ["casar"],
executar: async ({
from,
info,
isGroup,
menc_os2,
mess,
reagir,
reply,
sender,
kira,
prefix,
botNumber
}) => {

if (!isGroup) return reply(mess.group);
 if (!menc_os2)
  return reply("Hmph! Marca a pessoa que você deseja pedir em casamento... s-sou eu que tenho que te lembrar disso, baka?!");
const pretendente = sender;
const alvo = menc_os2;
if (alvo === botNumber)
 return reply("Hmph! E-eu já sou casada com o meu trabalho, tá?! 🤖 Não vem com essa ideia torta não, bobinho(a)!");
if (alvo === pretendente)
 return reply("Hmph! Não pode casar consigo mesmo(a), idiota... E-eu até acho graça, mas não deixa de ser triste, viu?!");

const jaCasado = await Casal.findOne({
$or: [
{ p1: pretendente },
{ p2: pretendente },
{ p1: alvo },
{ p2: alvo }
]
});

if (jaCasado)
 return reply("Hmph! Uma das partes já possui um compromisso... N-não é como se eu não tivesse conferido, baka! Presta atenção!");

const pedidoId = Math.random()
.toString(36)
.substring(2, 9);

await Pedido.create({
id: pedidoId,
p1: pretendente,
p2: alvo,
status: "pendente",
timestamp: Date.now()
});

await reagir(from, "💍");
const corpoCasorio = [
`🤵 *De:* @${pretendente.split("@")[0]}`,
`👰 *Para:* @${alvo.split("@")[0]}`,
` `,
`_Você aceita unir seus dados com esta pessoa para sempre?_`,
` `,
  `💖 *PROPOSTA DE UNIÃO* 💖... Hmph, só porque eu fiz isso não quer dizer que eu me importo com vocês, tá?!`
].join("\n");

await kira.sendMessage(from, {interactiveMessage: {
title: corpoCasorio,
footer: "*kira SYSTEM - ROMANCE*",
buttons: [
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: "✅ ACEITAR",
id: `${prefix}aceitar_casar ${pedidoId}`
})
},
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: "❌ RECUSAR",
id: `${prefix}recusar_casar ${pedidoId}`
})
}
],
image: {
url: "https://i.ibb.co/7JWDPgYN/ecbdbbc4-6b53-4367-b3b4-0acaa78670f0.jpg"
},
contextInfo: {
mentionedJid: [pretendente, alvo]
}
}
},
{
quoted: info
}
);
}
};