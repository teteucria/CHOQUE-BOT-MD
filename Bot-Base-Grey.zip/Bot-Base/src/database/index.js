const fs = require("fs-extra");
const path = require("path");
const crypto = require("crypto");

const SAVE_DEBOUNCE_MS = 300;

const PROXY_CACHE = new WeakMap();

function makeTracked(target, onMutate) {
  if (target === null || typeof target !== "object") return target;
  const cached = PROXY_CACHE.get(target);
  if (cached) return cached;
  const proxy = new Proxy(target, {
    get(obj, prop, receiver) {
      if (prop === "lean") {
        const rawClone = typeof structuredClone === "function" ? structuredClone(obj) : JSON.parse(JSON.stringify(obj));
        return () => rawClone;
      }
      const value = Reflect.get(obj, prop, receiver);
      return typeof value === "object" && value !== null ? makeTracked(value, onMutate) : value;
    },
    set(obj, prop, value, receiver) {
      const ok = Reflect.set(obj, prop, value, receiver);
      onMutate();
      return ok;
    },
    deleteProperty(obj, prop) {
      const ok = Reflect.deleteProperty(obj, prop);
      onMutate();
      return ok;
    },
  });
  PROXY_CACHE.set(target, proxy);
  return proxy;
}

class JsonStore {
  constructor(filePath, defaults = {}) {
    this.filePath = filePath;
    this.defaults = defaults;
    this._raw = this._load();
    this.data = makeTracked(this._raw, () => this._scheduleSave());
    this._saveTimer = null;
    process.on("exit", () => this.flushSync());
  }

  _load() {
    try {
      if (fs.existsSync(this.filePath)) {
        return JSON.parse(fs.readFileSync(this.filePath, "utf8"));
      }
    } catch {
      /* corrupt/absent -> defaults */
    }
    const init = Array.isArray(this.defaults) ? [] : { ...this.defaults };
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this.filePath, JSON.stringify(init, null, 2));
    } catch (e) {
      console.error(`[JsonStore] Erro ao criar ${this.filePath}:`, e.message);
    }
    return init;
  }

  _scheduleSave() {
    if (this._saveTimer) return;
    this._saveTimer = setTimeout(() => {
      this._saveTimer = null;
      this.flushSync();
    }, SAVE_DEBOUNCE_MS);
    if (this._saveTimer.unref) this._saveTimer.unref();
  }

  flushSync() {
    if (this._saveTimer) {
      clearTimeout(this._saveTimer);
      this._saveTimer = null;
    }
    try {
      const dir = path.dirname(this.filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(this.filePath, JSON.stringify(this._raw, null, 2));
    } catch (e) {
      console.error(`[JsonStore] Erro ao salvar ${this.filePath}:`, e.message);
    }
  }

  _genId() {
    return crypto.randomBytes(12).toString("hex");
  }

  _match(doc, query) {
    if (Array.isArray(query.$or)) return query.$or.some((sub) => this._match(doc, sub));
    if (Array.isArray(query.$and)) return query.$and.every((sub) => this._match(doc, sub));
    for (const key of Object.keys(query)) {
      const val = query[key];
      const docVal = doc[key];
      if (docVal === undefined || docVal === null) return false;
      if (typeof val === "object" && val !== null && !Array.isArray(val)) {
        for (const op of Object.keys(val)) {
          if (op === "$gte" && docVal < val[op]) return false;
          if (op === "$lte" && docVal > val[op]) return false;
          if (op === "$gt" && docVal <= val[op]) return false;
          if (op === "$lt" && docVal >= val[op]) return false;
          if (op === "$in" && !val[op].includes(docVal)) return false;
          if (op === "$nin" && val[op].includes(docVal)) return false;
          if (op === "$ne" && docVal === val[op]) return false;
        }
      } else if (Array.isArray(docVal)) {
        if (!docVal.includes(val)) return false;
      } else if (docVal !== val) {
        return false;
      }
    }
    return true;
  }

  _applySet(doc, setObj) {
    for (const key of Object.keys(setObj)) {
      if (key.includes(".")) {
        const parts = key.split(".");
        let obj = doc;
        for (let i = 0; i < parts.length - 1; i++) {
          if (!obj[parts[i]] || typeof obj[parts[i]] !== "object") obj[parts[i]] = {};
          obj = obj[parts[i]];
        }
        obj[parts[parts.length - 1]] = setObj[key];
      } else {
        doc[key] = setObj[key];
      }
    }
  }

  async findOne(query = {}) {
    if (Object.keys(query).length === 0) return this.data || null;
    if (Array.isArray(this.data)) return this.data.find((doc) => this._match(doc, query)) || null;
    return this._match(this.data, query) ? this.data : null;
  }

  async findById(id) {
    if (!Array.isArray(this.data)) return null;
    return this.data.find((doc) => doc._id === id) || null;
  }

  async create(doc = {}) {
    const newDoc = {
      _id: this._genId(),
      ...this.defaults,
      ...doc,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    if (Array.isArray(this.data)) {
      this.data.push(newDoc);
    } else {
      Object.keys(this.data).forEach((k) => delete this.data[k]);
      Object.assign(this.data, newDoc);
    }
    return newDoc;
  }

  async updateOne(query, update) {
    if (!Array.isArray(this.data)) return { modifiedCount: 0 };
    const idx = this.data.findIndex((doc) => this._match(doc, query));
    if (idx === -1) return { modifiedCount: 0 };
    const doc = this.data[idx];
    if (update.$set) this._applySet(doc, update.$set);
    if (update.$push) {
      for (const key of Object.keys(update.$push)) {
        if (!Array.isArray(doc[key])) doc[key] = [];
        doc[key].push(update.$push[key]);
      }
    }
    if (update.$pull) {
      for (const key of Object.keys(update.$pull)) {
        if (Array.isArray(doc[key])) {
          doc[key] = doc[key].filter((v) => v !== update.$pull[key]);
        }
      }
    }
    doc.updatedAt = new Date().toISOString();
    return { modifiedCount: 1 };
  }

  async deleteOne(query) {
    if (!Array.isArray(this.data)) return { deletedCount: 0 };
    const idx = this.data.findIndex((doc) => this._match(doc, query));
    if (idx === -1) return { deletedCount: 0 };
    this.data.splice(idx, 1);
    return { deletedCount: 1 };
  }

  async find(query = {}) {
    if (!Array.isArray(this.data)) return Object.keys(query).length === 0 ? [this.data] : [];
    if (Object.keys(query).length === 0) return this.data;
    return this.data.filter((doc) => this._match(doc, query));
  }
}

class GroupStore {
  constructor(dirPath, defaults = {}) {
    this.dirPath = dirPath;
    this.defaults = defaults;
    this.cache = {};
    if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
  }

  _hash(groupId) {
    return groupId.replace(/[^a-zA-Z0-9._-]/g, "_") + ".json";
  }

  _filePath(groupId) {
    return path.join(this.dirPath, this._hash(groupId));
  }

  _load(groupId) {
    if (this.cache[groupId]) return this.cache[groupId];
    const fp = this._filePath(groupId);
    try {
      if (fs.existsSync(fp)) {
        this.cache[groupId] = JSON.parse(fs.readFileSync(fp, "utf8"));
        return this.cache[groupId];
      }
    } catch {}
    return null;
  }

  _save(groupId, data) {
    const fp = this._filePath(groupId);
    try {
      fs.writeFileSync(fp, JSON.stringify(data, null, 2));
      this.cache[groupId] = data;
    } catch (e) {
      console.error(`[GroupStore] Erro ao salvar ${fp}:`, e.message);
    }
  }

  _all() {
    try {
      if (!fs.existsSync(this.dirPath)) return [];
      return fs
        .readdirSync(this.dirPath)
        .filter((f) => f.endsWith(".json"))
        .map((f) => {
          try {
            const gid = f.slice(0, -5);
            if (this.cache[gid]) return this.cache[gid];
            const doc = JSON.parse(fs.readFileSync(path.join(this.dirPath, f), "utf8"));
            this.cache[gid] = doc;
            return doc;
          } catch {
            return null;
          }
        })
        .filter(Boolean);
    } catch {
      return [];
    }
  }

  _match(doc, query) {
    if (Array.isArray(query.$or)) return query.$or.some((sub) => this._match(doc, sub));
    if (Array.isArray(query.$and)) return query.$and.every((sub) => this._match(doc, sub));
    for (const key of Object.keys(query)) {
      const val = query[key];
      const docVal = doc[key];
      if (docVal === undefined || docVal === null) return false;
      if (typeof val === "object" && val !== null && !Array.isArray(val)) {
        for (const op of Object.keys(val)) {
          if (op === "$gte" && docVal < val[op]) return false;
          if (op === "$lte" && docVal > val[op]) return false;
          if (op === "$gt" && docVal <= val[op]) return false;
          if (op === "$lt" && docVal >= val[op]) return false;
          if (op === "$in" && !val[op].includes(docVal)) return false;
          if (op === "$nin" && val[op].includes(docVal)) return false;
          if (op === "$ne" && docVal === val[op]) return false;
        }
      } else if (docVal !== val) {
        return false;
      }
    }
    return true;
  }

  _applySet(doc, setObj) {
    for (const key of Object.keys(setObj)) {
      if (key.includes(".")) {
        const parts = key.split(".");
        let obj = doc;
        for (let i = 0; i < parts.length - 1; i++) {
          if (!obj[parts[i]] || typeof obj[parts[i]] !== "object") obj[parts[i]] = {};
          obj = obj[parts[i]];
        }
        obj[parts[parts.length - 1]] = setObj[key];
      } else {
        doc[key] = setObj[key];
      }
    }
  }

  async findOne(query = {}) {
    if (query.groupId) {
      const doc = this._load(query.groupId);
      return doc ? { ...doc } : null;
    }
    for (const doc of this._all()) {
      if (this._match(doc, query)) return { ...doc };
    }
    return null;
  }

  async findById(id) {
    for (const doc of this._all()) {
      if (doc._id === id) return { ...doc };
    }
    return null;
  }

  async find(query = {}) {
    const results = [];
    for (const doc of this._all()) {
      if (Object.keys(query).length === 0 || this._match(doc, query)) {
        results.push({ ...doc });
      }
    }
    return results;
  }

  async create(doc = {}) {
    if (!doc.groupId) throw new Error("groupId é obrigatório para documentos de grupo");
    const newDoc = {
      _id: crypto.randomBytes(12).toString("hex"),
      ...this.defaults,
      ...doc,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this._save(newDoc.groupId, newDoc);
    return { ...newDoc };
  }

  async updateOne(query, update) {
    let groupId = query.groupId;
    if (!groupId) {
      for (const doc of this._all()) {
        if (this._match(doc, query)) {
          groupId = doc.groupId;
          break;
        }
      }
    }
    if (!groupId) return { modifiedCount: 0 };

    const doc = this._load(groupId);
    if (!doc) return { modifiedCount: 0 };

    if (update.$set) this._applySet(doc, update.$set);
    if (update.$push) {
      for (const key of Object.keys(update.$push)) {
        if (!Array.isArray(doc[key])) doc[key] = [];
        doc[key].push(update.$push[key]);
      }
    }
    if (update.$pull) {
      for (const key of Object.keys(update.$pull)) {
        if (Array.isArray(doc[key])) {
          doc[key] = doc[key].filter((v) => v !== update.$pull[key]);
        }
      }
    }
    doc.updatedAt = new Date().toISOString();
    this._save(groupId, doc);
    return { modifiedCount: 1 };
  }

  async deleteOne(query) {
    let groupId = query.groupId;
    if (!groupId) {
      for (const doc of this._all()) {
        if (this._match(doc, query)) {
          groupId = doc.groupId;
          break;
        }
      }
    }
    if (!groupId) return { deletedCount: 0 };

    const fp = this._filePath(groupId);
    try {
      if (fs.existsSync(fp)) {
        fs.unlinkSync(fp);
        delete this.cache[groupId];
        return { deletedCount: 1 };
      }
    } catch {}
    return { deletedCount: 0 };
  }
}

const dbDir = path.join(__dirname, "..", "db");
const grupoDir = path.join(dbDir, "grupos");

const grupoDefaults = {
  name: "",
  antifake: false,
  legend_estrangeiro: "0",
  antispam: { active: false, tempo: 5 },
  antiimg: false,
  antivideo: false,
  antiaudio: false,
  antisticker: false,
  antidoc: false,
  antictt: false,
  antiloc: false,
  ANTI_DDD: { active: false, listaProibidos: [] },
  antilinkgp: false,
  antilinkhard: false,
  antilinkeasy: false,
  antinotas: false,
  antistatus: false,
  antipagamento: false,
  anticatalogo: false,
  wellcome: [{ 
  bemvindo1: false,
  legendabv: "🥱 H-hmph! Bem-vindo(a) ao grupo #numerodele#... não que eu esteja animada com isso ou nada assim! Leia as regras na descrição, viu? Não quero trabalho extra depois, tá?",
  legendasaiu: "😑 Ora, o membro #numerodele# saiu do grupo? Hmph, não é como se eu fosse sentir falta ou algo do tipo! ...Mas, adeus, amiguinho. C-cuide-se, ok? Não que eu me importe muito com isso!" }],
  simi1: false,
  autosticker: { isAutofigu: false, IsAutofigu: false, autofigu: false },
  autoresposta: false,
  jogos: false,
  porno: false,
  autodown: false,
  bangp: false,
  antipalavrao: { palavras: [] },
  anti_flood: false,
  anti_edit_grupo: false,
  soadm: false,
  multiprefix: false,
  prefixos: [],
};

const Grupo = new GroupStore(grupoDir, grupoDefaults);

const Nescessario = new JsonStore(path.join(dbDir, "nesc.json"), {
  antipv: false,
  verificado: true,
  anticall: true,
  modo_aluguel: false,
  visualizarmsg: false,
  emojimenu: "🌹",
  botoff: false,
  Odelete: true,
});

const Pedido = new JsonStore(path.join(dbDir, "pedidos.json"));
const Casal = new JsonStore(path.join(dbDir, "casais.json"));
const Muted = new JsonStore(path.join(dbDir, "mute.json"), []);
const Take = new JsonStore(path.join(dbDir, "take.json"), []);
const Banned = new JsonStore(path.join(dbDir, "banned.json"), { numeros: {} });

const stores = [Nescessario, Pedido, Casal, Muted, Take, Banned];

function flushAll() {
  for (const s of stores) s.flushSync();
}

module.exports = { Grupo, Nescessario, Pedido, Casal, Muted, Take, Banned, JsonStore, GroupStore, flushAll };
