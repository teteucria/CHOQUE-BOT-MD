const { verificarSpam, resetarSpam, sleep, mess } = require("../utils/helpers");

async function handleAntiStatus(ctx) {
  const { kira, info, sender, from, isBotGroupAdmins, isGroupAdmins, SoDono, IS_DELETE } = ctx;
  if (!isBotGroupAdmins || isGroupAdmins || SoDono) return;
  if (!info.message?.groupStatusMentionMessage) return;

  await sleep(400);
  await kira.groupParticipantsUpdate(from, [sender], "remove");
  await kira.sendMessage(from, {
    text: `🚫 *@${sender.split("@")[0]}* foi removido por mencionar o grupo nos status...!`,
    mentions: [sender]
  });
  await kira.sendMessage(from, {
    delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
  });
}

async function handleAntiPayment(ctx) {
  const { kira, info, sender, from, isBotGroupAdmins, isGroupAdmins, SoDono, IS_DELETE, groupMembers, groupMetadata } = ctx;
  if (!isBotGroupAdmins || isGroupAdmins || SoDono) return;
  if (!info.message?.requestPaymentMessage) return;

  const wasAlreadyClosed = !!groupMetadata?.announce;

  if (!wasAlreadyClosed) {
    try {
      await kira.groupSettingUpdate(from, "announcement");
    } catch (err) {
      console.log("❌ Erro ao fechar grupo (anti pagamento):", err?.message || err);
    }
  }

  if (IS_DELETE) {
    const deletePayload = { remoteJid: from, fromMe: false, id: info.key.id, participant: sender };
    console.log("🗑️ [antiPagamento] Tentando apagar:", JSON.stringify(deletePayload));
    try {
      const result = await kira.sendMessage(from, { delete: deletePayload });
      console.log("🗑️ [antiPagamento] Resultado da exclusão:", JSON.stringify(result));
    } catch (err) {
      console.log("❌ [antiPagamento] Erro ao apagar mensagem de pagamento:", err?.message || err);
      console.log(err?.stack || err);
    }
  }

  if (JSON.stringify(groupMembers).includes(sender)) {
    try {
      await kira.groupParticipantsUpdate(from, [sender], "remove");
    } catch (err) {
      console.log("❌ Erro ao banir por pagamento:", err?.message || err);
    }
  }

  if (!wasAlreadyClosed) {
    try {
      await kira.groupSettingUpdate(from, "not_announcement");
    } catch (err) {
      console.log("❌ Erro ao reabrir grupo (anti pagamento):", err?.message || err);
    }
  }
}

async function handleAntiNotas(ctx) {
  const { kira, info, sender, from, budy, budy2, isBotGroupAdmins, isGroupAdmins, SoDono, IS_DELETE, groupMembers } = ctx;
  if (!isBotGroupAdmins || isGroupAdmins || SoDono) return;
  if (info.message?.reactionMessage?.text) return;

  const match = budy2.toString().match(/(💳|💎|💸|💵|💷|💶|🪙|💰|🤑|⚖️)/gi);
  if (!match || budy2.length < 20) return;
  if (budy.length < 100) return;

  if (IS_DELETE) {
    setTimeout(async () => {
      await kira.sendMessage(from, {
        delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
      });
    }, 500);
  }

  if (!JSON.stringify(groupMembers).includes(sender)) return;
  await kira.groupParticipantsUpdate(from, [sender], "remove");
}

async function handleAntiPrivate(ctx) {
  const { kira, sender, from, isGroup, SoDono } = ctx;
  if (isGroup || SoDono) return;

  await sleep(5000);
  await kira.updateBlockStatus(sender, "block").catch(() => {});
}

async function handleMute(ctx) {
  const { kira, info, sender, from, isGroup, muted, selo, groupMembers } = ctx;
  if (!isGroup) return;

  const grupoMute = Array.isArray(muted) ? muted.find(i => i.grupo === from) : null;
  if (!grupoMute) return;

  if (grupoMute.silenciados?.includes(sender)) {
    await kira.sendMessage(from, {
      delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
    }).catch(() => {});
    return true;
  }

  if (grupoMute.mutados?.includes(sender)) {
    await kira.sendMessage(from, {
      delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
    }).catch(() => {});
    await kira.sendMessage(from, {
      text: `*LEVOU POR NAO FICAR QUIETO 💢*\nHmph! Eu avisei pra ficar quieto... n-não fica triste, foi você que não me obedeceu, baka!`,
      mentions: [sender]
    }, { quoted: selo });
    await kira.groupParticipantsUpdate(from, [sender], "remove");
    grupoMute.mutados = grupoMute.mutados.filter(id => id !== sender);
    return true;
  }

  return false;
}

async function handleAntiSpam(ctx) {
  const { kira, sender, from, isGroup, isGroupAdmins, SoDono, isBot,
    tempoAntiSpam, isAntiSpam } = ctx;

  if (!isGroup || !isAntiSpam || isGroupAdmins || SoDono || isBot) return;

  const { spam, quantidade } = verificarSpam(from, sender, tempoAntiSpam, 5);

  if (quantidade >= 2 && quantidade < 5) {
    await kira.sendMessage(from, {
      text: `⚠️ *@${sender.split("@")[0]}* vai com calma, baka!\nHmph! Detectei um possível spam... n-não me obriga a agir, tá?\n• Avisos Total: ${quantidade}/5`,
      mentions: [sender]
    });
  }

  if (spam) {
    await kira.sendMessage(from, {
      text: `🚫 *@${sender.split("@")[0]}* removido.\nHmph! Limite atingido: 5/5... Eu avisei, viu? Agora aguenta as consequências, idiota!`,
      mentions: [sender]
    });
    await kira.groupParticipantsUpdate(from, [sender], "remove");
    resetarSpam(from, sender);
    return true;
  }

  return false;
}

async function handleAntiPalavrao(ctx) {
  const { kira, sender, from, isGroup, isPalavrao, isBotGroupAdmins,
    SoDono, isGroupAdmins, budy2, dataGp, IS_DELETE, groupMembers, selo, info } = ctx;

  if (!isGroup || !isPalavrao || !isBotGroupAdmins || SoDono || isGroupAdmins) return;

  const palavras = dataGp[0]?.antipalavrao?.palavras || [];
  const normalized = budy2.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  if (palavras.some(p => normalized.includes(p.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")))) {
    setTimeout(() => {
      if (!JSON.stringify(groupMembers).includes(sender)) return;
      kira.groupParticipantsUpdate(from, [sender], "remove");
      setTimeout(() => {
        kira.sendMessage(from, {
          delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
        });
      }, 500);
    }, 2000);
    kira.sendMessage(from, { text: mess.permissionDenied_rUser() }, { quoted: selo });
  }
}

module.exports = {
  handleAntiStatus,
  handleAntiPayment,
  handleAntiNotas,
  handleAntiPrivate,
  handleMute,
  handleAntiSpam,
  handleAntiPalavrao,
};