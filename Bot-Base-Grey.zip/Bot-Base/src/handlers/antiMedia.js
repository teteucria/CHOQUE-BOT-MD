const MEDIA_TYPES = {
  imageMessage: { flagKey: "isAntiImg" },
  stickerMessage: { flagKey: "isAntiSticker" },
  documentMessage: { flagKey: "Antidoc" },
  videoMessage: { flagKey: "isAntiVid" },
  audioMessage: { flagKey: "isAntiAudio" },
  contactMessage: { flagKey: "isAntiCtt" },
  contactsArrayMessage: { flagKey: "isAntiCtt" },
  locationMessage: { flagKey: "Antiloc" },
  productMessage: { flagKey: "isAnticatalogo" },
};

async function handleAntiMedia(ctx) {
  const { type, isBotGroupAdmins, isGroupAdmins, SoDono, info, from, kira, IS_DELETE, groupMembers, selo, ...flags } = ctx;

  if (!isBotGroupAdmins || isGroupAdmins || SoDono || info.key.fromMe) return;

  const mediaConfig = MEDIA_TYPES[type];
  if (!mediaConfig || !flags[mediaConfig.flagKey]) return;

  if (IS_DELETE) {
    setTimeout(async () => {
      await kira.sendMessage(from, {
        delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: ctx.sender }
      });
    }, 500);
  }

  if (!JSON.stringify(groupMembers).includes(ctx.sender)) return;
  await kira.groupParticipantsUpdate(from, [ctx.sender], "remove");
}

module.exports = { handleAntiMedia };