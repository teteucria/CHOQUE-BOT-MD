const util = require("util");
const { GPT } = require("../../arquivos/funcoes/functions.js");

async function handleEval(ctx) {
  const { body, SoDono, reply } = ctx;
  if (!body.startsWith(">") || !SoDono) return;

  try {
    let evaled = await eval(body.slice(1));
    if (evaled === undefined || (evaled && evaled.key)) return;
    if (typeof evaled !== "string") {
      evaled = util.inspect(evaled);
    }
    await reply(evaled);
  } catch (err) {
    await reply(String(err));
  }
}

async function handleSimi(ctx) {
  const { kira, info, budy, isGroup, isSimi, from, selo, mess, reagir } = ctx;
  if (!isGroup || !isSimi || !budy) return;
  if (["imageMessage", "audioMessage", "stickerMessage"].includes(ctx.type)) return;
  if (info.key.fromMe) return;

  const emojisList = ["🤠", "😝", "🥳", "😵‍💫", "😴", "🤫"];
  await reagir(from, emojisList[Math.floor(Math.random() * emojisList.length)]);

  const userId = "12345";
  const result = await GPT.handler(userId, budy);
  await kira.sendMessage(from, {
    text: result.payload.response
  }, { quoted: selo }).catch(async () => {
    ctx.reply(mess.errorResponseSimi());
  });
}

async function handlePrefixoEcho(ctx) {
  const { budy2, prefix, reply, kira, from, selo, logos, NomeDoBot, pushname, hora, date } = ctx;
  if (budy2 !== "prefixo") return;

  await kira.sendMessage(from, {
    text: `╭════════════════╮
║  🫦Bot: ${NomeDoBot}
║  👤Voce: ${pushname}
║  🎡Prefix: "${prefix}"
║  📆Hoje: ${date()}
║  Horas: ${hora()}
╰════════════════╯`
  }, { quoted: selo });
}

module.exports = { handleEval, handleSimi, handlePrefixoEcho };