const { jaProcessou, marcarComoProcessado } = require("../utils/helpers");

const DOMINIOS_AUTODOWN = {
instagram: /(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:reel|p|tv)\/[^\s]+/gi,
tiktok: /(?:https?:\/\/)?(?:vm\.|vt\.)?tiktok\.com\/[^\s]+/gi,
facebook: /(?:https?:\/\/)?(?:www\.|m\.|web\.)?(?:facebook|fb)\.com\/[^\s]+/gi,
youtube: /(?:https?:\/\/)?(?:www\.|m\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)[^\s]+/gi,
};

function buildApiUrl(url, API_kira, KEY_kira) {
if (url.includes("tiktok.com") || url.includes("vm.tiktok") || url.includes("vt.tiktok")) {
return `${API_kira}/tiktok-video?url=${url}&apitoken=${KEY_kira}`;
} else if (url.includes("instagram.com")) {
return `${API_kira}/insta-video?url=${url}&apitoken=${KEY_kira}`;
} else if (url.includes("facebook.com") || url.includes("fb.com")) {
return `${API_kira}/face-video?url=${url}&apitoken=${KEY_kira}`;
} else if (url.includes("youtube.com") || url.includes("youtu.be")) {
return `${API_kira}/youtube-video2?url=${url}&apitoken=${KEY_kira}`;
}
return null;
}

async function handleAutoDown(ctx) {
const { kira, info, from, body, isGroup, isAutodown,
API_kira, KEY_kira, reagir } = ctx;

if (!isAutodown) return false;

const text = body || "";

for (const [platform, regex] of Object.entries(DOMINIOS_AUTODOWN)) {
const match = text.match(regex);
if (match && match[0]) {
const url = match[0];
const msgId = info.key.id;

if (jaProcessou(msgId)) return true;
marcarComoProcessado(msgId);

const apiUrl = buildApiUrl(url, API_kira, KEY_kira);
if (!apiUrl) return false;
await reagir(from, "💽");
try {
await kira.sendMessage(from, { video: { url: apiUrl }, caption: "Download concluído...!" });
await reagir(from, "✅");
} catch {
await reagir(from, "❌");
}
return true;
}
}

return false;
}

module.exports = { handleAutoDown };