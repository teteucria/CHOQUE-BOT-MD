// Anti-flood: detecta rajadas de mensagens (inclusive "invisíveis" pra alguns
// clientes) e bombas de menção, banindo quem floodar. Funciona porque o bot
// recebe TODO evento de mensagem via Baileys, independente do que aparece
// ou não na tela de cada pessoa.

const janelas = new Map(); // key: from+"_"+sender -> [timestamps...]

const JANELA_MS = 6_000;    // período analisado
const LIMITE_MSGS = 3;      // nº de mensagens nesse período pra considerar flood
const LIMITE_MENCOES = 5;   // nº de menções numa única mensagem pra considerar bomba

async function banir(ctx, motivo) {
  const { kira, sender, from, info } = ctx;
  try {
    await kira.sendMessage(from, {
      delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
    }).catch(() => {});
    await kira.groupParticipantsUpdate(from, [sender], "remove");
    await kira.sendMessage(from, {
      text: `🚫 *@${sender.split("@")[0]}* banido por ${motivo}.\nHmph! Não vou deixar ninguém floodar o grupo enquanto eu tô de olho, viu?!`,
      mentions: [sender]
    });
  } catch (err) {
    console.log("❌ [antiFlood] Erro ao banir:", err?.message || err);
  }
}

async function handleAntiFlood(ctx) {
  const {
    from, sender, isGroup, isGroupAdmins, SoDono, isBot,
    isBotGroupAdmins, isAntiFlood, mentionedJid
  } = ctx;

  if (!isGroup || !isAntiFlood || !isBotGroupAdmins) return false;
  if (isGroupAdmins || SoDono || isBot) return false;

  // 1) bomba de menção: uma mensagem só marcando muita gente
  if (Array.isArray(mentionedJid) && mentionedJid.length >= LIMITE_MENCOES) {
    await banir(ctx, `mencionar ${mentionedJid.length} pessoas de uma vez`);
    return true;
  }

  // 2) rajada de mensagens em pouco tempo
  const key = `${from}_${sender}`;
  const agora = Date.now();
  let lista = janelas.get(key) || [];
  lista = lista.filter((t) => agora - t < JANELA_MS);
  lista.push(agora);
  janelas.set(key, lista);

  if (lista.length >= LIMITE_MSGS) {
    janelas.delete(key);
    await banir(ctx, "floodar mensagens no grupo");
    return true;
  }

  return false;
}

module.exports = { handleAntiFlood };