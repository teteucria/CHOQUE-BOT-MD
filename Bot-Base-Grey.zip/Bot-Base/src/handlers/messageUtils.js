function getContentType(message) {
  if (!message) return undefined;
  for (const key of Object.keys(message)) {
    if (message[key] == null) continue;
    if (key === "senderKeyDistributionMessage") continue;
    if (key === "conversation") return "conversation";
    if (key.endsWith("Message")) return key;
  }
  return undefined;
}

function extractBody(info) {
  const msg = info.message || {};
  if (msg.protocolMessage || msg.reactionMessage || msg.senderKeyDistributionMessage) return "";
  return msg.conversation ||
    msg.viewOnceMessageV2?.message?.imageMessage?.caption ||
    msg.viewOnceMessageV2?.message?.videoMessage?.caption ||
    msg.imageMessage?.caption ||
    msg.videoMessage?.caption ||
    msg.extendedTextMessage?.text ||
    msg.viewOnceMessage?.message?.videoMessage?.caption ||
    msg.viewOnceMessage?.message?.imageMessage?.caption ||
    msg.documentWithCaptionMessage?.message?.documentMessage?.caption ||
    msg.buttonsMessage?.imageMessage?.caption ||
    msg.buttonsResponseMessage?.selectedButtonId ||
    msg.listResponseMessage?.singleSelectReply?.selectedRowId ||
    msg.templateButtonReplyMessage?.selectedId ||
    msg.editedMessage?.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text ||
    msg.editedMessage?.message?.protocolMessage?.editedMessage?.imageMessage?.caption ||
    safeParamsId(msg) ||
    info?.text || "";
}

function safeParamsId(msg) {
  try {
    return JSON.parse(msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || "{}")?.id;
  } catch {
    return "";
  }
}

function extractQuotedBody(info) {
  const quoted = info.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (!quoted) return "";
  return quoted.conversation ||
    quoted.extendedTextMessage?.text ||
    quoted.imageMessage?.caption ||
    quoted.videoMessage?.caption ||
    "";
}

function buildMediaFlags(type) {
  const isImage = type === "imageMessage";
  const isVideo = type === "videoMessage";
  const isAudio = type === "audioMessage";
  const isSticker = type === "stickerMessage";
  const isContact = type === "contactMessage";
  const isLocation = type === "locationMessage";
  const isProduct = type === "productMessage";
  const isMedia = isImage || isVideo || isAudio || type === "viewOnceMessage" || type === "viewOnceMessageV2";

  let typeMessage = (type || "text").substring(0, 50);
  if (isImage) typeMessage = "Image";
  else if (isVideo) typeMessage = "Video";
  else if (isAudio) typeMessage = "Audio";
  else if (isSticker) typeMessage = "Sticker";
  else if (isContact) typeMessage = "Contact";
  else if (isLocation) typeMessage = "Location";
  else if (isProduct) typeMessage = "Product";

  return { isImage, isVideo, isAudio, isSticker, isContact, isLocation, isProduct, isMedia, typeMessage };
}

function buildQuotedFlags(type, content) {
  const isExtText = type === "extendedTextMessage";
  return {
    isQuotedMsg: isExtText && content.includes("conversation"),
    isQuotedMsg2: isExtText && content.includes("text"),
    isQuotedImage: isExtText && content.includes("imageMessage"),
    isQuotedVisuU: isExtText && content.includes("viewOnceMessage"),
    isQuotedVisuU2: isExtText && content.includes("viewOnceMessageV2"),
    isQuotedVideo: isExtText && content.includes("videoMessage"),
    isQuotedDocument: isExtText && content.includes("documentMessage"),
    isQuotedDocW: isExtText && content.includes("documentWithCaptionMessage"),
    isQuotedAudio: isExtText && content.includes("audioMessage"),
    isQuotedSticker: isExtText && content.includes("stickerMessage"),
    isQuotedContact: isExtText && content.includes("contactMessage"),
    isQuotedLocation: isExtText && content.includes("locationMessage"),
    isQuotedProduct: isExtText && content.includes("productMessage"),
  };
}

function detectMessageType(type) {
  const types = {
    conversation: "Texto", extendedTextMessage: "Texto",
    imageMessage: "Imagem", videoMessage: "Vídeo",
    audioMessage: "Áudio", stickerMessage: "Figurinha",
    documentMessage: "Documento", contactMessage: "Contato",
    locationMessage: "Localização",
  };
  return types[type] || "Texto";
}

module.exports = {
  getContentType,
  extractBody,
  extractQuotedBody,
  buildMediaFlags,
  buildQuotedFlags,
};