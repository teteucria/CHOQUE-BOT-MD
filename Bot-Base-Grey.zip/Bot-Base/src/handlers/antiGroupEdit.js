// Anti-edição de grupo: se alguém que NÃO é admin conseguir mudar nome,
// descrição, foto ou as configurações do grupo (algo que só deveria ser
// possível pra admin), a kira detecta e bane na hora.

const { getGroupAdmins } = require("../utils/helpers");

const NOMES_ACAO = {
  subject: "mudar o nome do grupo",
  description: "mudar a descrição do grupo",
  picture: "trocar a foto do grupo",
  restrict: "mexer na configuração de edição do grupo",
  announce: "mexer na configuração de quem pode mandar mensagem",
};

async function handleAntiGroupEdit(kira, event, { Grupo, botNumber }) {
  const { action, author, id: groupId } = event;
  if (!NOMES_ACAO[action]) return;
  if (!author || !groupId) return;

  let grupo;
  try {
    grupo = await Grupo.findOne({ groupId });
  } catch (e) { return; }
  if (!grupo || !grupo.anti_edit_grupo) return;

  let metadata;
  try {
    metadata = await kira.groupMetadata(groupId);
  } catch (e) { return; }

  const admins = getGroupAdmins(metadata.participants || []);
  const authorNumero = author.split("@")[0];

  if (!admins.includes(botNumber)) return; // bot precisa ser admin pra agir
  if (admins.some((a) => a.replace(/\D/g, "") === authorNumero.replace(/\D/g, ""))) return; // é admin de verdade, ok

  try {
    await kira.sendMessage(groupId, {
      text: `🚫 *@${authorNumero}* banido por ${NOMES_ACAO[action]} sem ser admin.\nHmph! Só admin pode fazer isso... N-não pense que vai escapar assim, baka!`,
      mentions: [author]
    });
    await kira.groupParticipantsUpdate(groupId, [author], "remove");
  } catch (err) {
    console.log("❌ [antiGroupEdit] Erro ao banir:", err?.message || err);
  }
}

module.exports = { handleAntiGroupEdit };