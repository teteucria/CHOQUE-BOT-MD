const { Grupo, Nescessario, Muted } = require("../database");

async function loadGroupData(groupId) {
  if (!groupId) return null;
  let grupo = await Grupo.findOne({ groupId });
  if (!grupo) {
    grupo = await Grupo.create({ groupId });
  }
  return grupo;
}

async function loadGlobalData() {
  let nescessario = await Nescessario.findOne({});
  if (!nescessario) {
    nescessario = await Nescessario.create({});
  }
  return nescessario;
}

async function loadMuted() {
  return await Muted.find({});
}

module.exports = { loadGroupData, loadGlobalData, loadMuted };