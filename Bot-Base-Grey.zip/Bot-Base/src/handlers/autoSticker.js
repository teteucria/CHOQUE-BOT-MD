const fs = require("fs-extra");
const { exec } = require("child_process");

async function handleAutoSticker(ctx) {
  const { kira, info, type, sender, from, isGroup, isMedia, rgtake,
    NomeDoBot, pushname, groupName, selo, getFileBuffer, DLT_FL,
    sendImageAsSticker2, sendVideoAsSticker2, getExtension, getRandom, prefix } = ctx;

  if (!isGroup) return;

  const budy = ctx.budy || "";
  const STICKER_CMDS = ["sticker", "s", "stk", "st", "fsticker", "f", "fstiker"];
  if (STICKER_CMDS.some(cmd => budy.includes(`${prefix}${cmd}`))) return;

  if (type === "imageMessage") {
    const indexTake = rgtake.findIndex(i => i.usuario === sender);
    const packSticker = indexTake !== -1
      ? `${rgtake[indexTake].mcdagua1}`
      : ` Bot: ${NomeDoBot}\nCriador: ${pushname}\n`;
    const authorSticker = indexTake !== -1
      ? `${rgtake[indexTake].mcdagua2}`
      : `\nGrupo: ${groupName}\n Site: waguapis.online`;

    try {
      const owgi = await getFileBuffer(info.message.imageMessage, "image");
      const encmediaa = await sendImageAsSticker2(kira, from, owgi, selo, {
        packname: packSticker, author: authorSticker
      });
      DLT_FL(encmediaa);
    } catch (e) { /* ignore */ }
  }

  if (type === "videoMessage" && isMedia && info.message.videoMessage.seconds < 11) {
    const indexTake = rgtake.findIndex(i => i.usuario === sender);
    const packSticker = indexTake !== -1
      ? `${rgtake[indexTake].mcdagua1}`
      : `Bot: ${NomeDoBot}\nCriador: ${pushname}\n`;
    const authorSticker = indexTake !== -1
      ? `${rgtake[indexTake].mcdagua2}`
      : `\nGrupo: ${groupName}\n Site: waguapis.online`;

    try {
      const owgi = await getFileBuffer(info.message.videoMessage, "video");
      const encmedia = await sendVideoAsSticker2(kira, from, owgi, selo, {
        packname: packSticker, author: authorSticker
      });
      DLT_FL(encmedia);
    } catch (e) { /* ignore */ }
  }
}

async function handleAutoStickerFfmpeg(ctx) {
  const { kira, info, type, from, isGroup, selo, getFileBuffer, getExtension, getRandom } = ctx;

  if (!isGroup) return;

  if (type === "imageMessage") {
    try {
      const ext = await getExtension(info.message.imageMessage.mimetype);
      const rane = getRandom("." + ext);
      const buffimg = await getFileBuffer(info.message.imageMessage, "image");
      fs.writeFileSync(rane, buffimg);
      const rano = getRandom(".webp");

      await new Promise((resolve) => {
        exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${rano}`,
          (err) => {
            fs.unlinkSync(rane);
            if (!err) {
              const buffer = fs.readFileSync(rano);
              kira.sendMessage(from, { sticker: buffer }, { quoted: selo });
            }
            try { fs.unlinkSync(rano); } catch (e) {}
            resolve();
          }
        );
      });
    } catch (e) { /* ignore */ }
  }
}

module.exports = { handleAutoSticker, handleAutoStickerFfmpeg };