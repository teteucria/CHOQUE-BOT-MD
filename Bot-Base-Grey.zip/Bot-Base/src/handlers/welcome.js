const { getGroupAdmins, extractDDD, extractStateFromDDD, extractStateFromNumber, getName, time, prefix: configPrefix, config } = require("../utils/helpers");
const { mess } = require("../utils/messages.js");

async function handleWelcome(ctx) {
  const { kira, event, Grupo, mess, NomeDoBot, fundo1, API_kira, KEY_kira } = ctx;

  const wagu2 = event;
  const jid = wagu2.participants[0]?.phoneNumber || wagu2.participants[0]?.id || wagu2.participants[0];
  if (!jid) return;

  const numeroParticipante = jid.split("@")[0];
  const grupo = await Grupo.findOne({ groupId: wagu2.id });
  if (!grupo) return;

  let grpmdt;
  try {
    grpmdt = await kira.groupMetadata(wagu2.id);
  } catch (e) { return; }

  const isGroup2 = grpmdt.id.endsWith("@g.us");

  let GroupMetadata_;
  try {
    GroupMetadata_ = isGroup2 ? await kira.groupMetadata(wagu2.id) : "";
  } catch (e) { return; }

  const membros_ = isGroup2 ? GroupMetadata_.participants : "";
  const groupAdmins_ = isGroup2 ? getGroupAdmins(membros_) : "";

  if (wagu2.action === "remove") {
    global.num = jid;
  }

  if (grupo.antifake && wagu2.action === "add" && !numeroParticipante.startsWith("55")) {
    if (grupo.legend_estrangeiro !== "0") {
      await kira.sendMessage(GroupMetadata_.id, { text: grupo.legend_estrangeiro });
    }
    setTimeout(async () => {
      kira.groupParticipantsUpdate(GroupMetadata_.id, [jid], "remove");
    }, 1000);
    return;
  }

  if (grupo.ANTI_DDD?.active && wagu2.action === "add" &&
    grupo.ANTI_DDD.listaProibidos.includes(extractDDD(numeroParticipante))) {
    kira.sendMessage(GroupMetadata_.id, {
      text: mess.forbiddenStateFromDDD(numeroParticipante, extractStateFromDDD, extractDDD),
      mentions: [jid]
    });
    setTimeout(async () => {
      kira.groupParticipantsUpdate(GroupMetadata_.id, [jid], "remove");
    }, 1000);
    return;
  }

  let mdata_2;
  try {
    mdata_2 = isGroup2 ? await kira.groupMetadata(wagu2.id) : "";
  } catch (e) { return; }

  const welc = grupo.wellcome?.[0];
  const isWelcomed = welc?.legendabv != null;
  const isByed = welc?.legendasaiu !== 0;
  const groupDesc = await mdata_2.desc;

  if (welc?.bemvindo1 === true) {
    if (wagu2.action === "add") {
      let teks;
      if (isWelcomed) {
        teks = grupo.wellcome[0].legendabv
          .replace("#hora#", time())
          .replace("#nomedogp#", mdata_2.subject)
          .replace("#numerodele#", "@" + numeroParticipante)
          .replace("#numerobot#", kira.user.id)
.replace("#prefixo#", grupo.multiprefix === true ? grupo.prefixos[0] : configPrefix)
          .replace("#descrição#", groupDesc)
          .replace("#estado#", extractStateFromNumber(numeroParticipante));
      } else {
        teks = `Bem-vindo(a) @${numeroParticipante}! Hmph! N-não fica se achando especial, mas... se comporte, tá?!`;
      }

      let ppimg;
      try {
        ppimg = await kira.profilePictureUrl(jid, "image");
      } catch (e) {
        ppimg = "https://files.catbox.moe/l0kjxz.jpeg";
      }

      const shortpc = encodeURIComponent(ppimg);
      kira.sendMessage(mdata_2.id, {
        image: { url: `${API_kira}/canvas/welcome2?fundo=${fundo1}&logo=${shortpc}&titulo=Bem-vindo(a)!&numero=${numeroParticipante.slice(0, 12)}&grupo=${mdata_2.subject}&apitoken=${KEY_kira}` },
        mentions: [jid], caption: teks
      });
    }
  }

  if (wagu2.action === "remove" && welc?.bemvindo1 === true) {
    let teks;
    if (isByed) {
      teks = grupo.wellcome[0].legendasaiu
        .replace("#hora#", time())
        .replace("#nomedogp#", mdata_2.subject)
        .replace("#numerodele#", "@" + numeroParticipante)
        .replace("#numerobot#", kira.user.id)
.replace("#prefixo#", grupo.multiprefix === true ? grupo.prefixos[0] : configPrefix)
        .replace("#descrição#", groupDesc)
        .replace("#estado#", extractStateFromNumber(numeroParticipante));
    } else {
      teks = mess.phrasesLeft(getName, numeroParticipante, encodeURIComponent);
    }

    let ppimg;
    try {
      ppimg = await kira.profilePictureUrl(jid, "image");
    } catch (e) {
      ppimg = "https://i.ibb.co/r1p36H3/WGsps.jpg";
    }

    const shortpc = encodeURIComponent(ppimg);
    kira.sendMessage(mdata_2.id, {
      image: { url: `${API_kira}/canvas/welcome2?fundo=${fundo1}&logo=${shortpc}&titulo=Goodbye!&numero=${numeroParticipante.slice(0, 12)}&grupo=${mdata_2.subject}&apitoken=${KEY_kira}` },
      mentions: [jid], caption: teks
    });
  }
}

module.exports = { handleWelcome };