const { readJSON, extractDomain, registrarNumeroSuspeito } = require("../utils/helpers");

const DOMINIOS_IGNORADOS = [
  "instagram.com/reel", "instagram.com/share/reel",
  "tiktok.com", "vm.tiktok.com", "vt.tiktok.com", "www.tiktok.com",
  "facebook.com", "fb.com", "www.facebook.com",
  "kwai.com", "s.kw.ai",
  "youtube.com", "youtu.be",
  "pinterest.com", "pin.it",
];

function isDominioIgnorado(url) {
  return DOMINIOS_IGNORADOS.some(dom => url.includes(dom));
}

async function handleAntiLinkHard(ctx) {
  const { kira, info, sender, from, Procurar_String, PR_String,
    isBotGroupAdmins, isGroupAdmins, groupMembers, IS_DELETE } = ctx;

  if (!isBotGroupAdmins || isGroupAdmins || info.key.fromMe) return;

  if (isDominioIgnorado(Procurar_String)) return;

  if (Procurar_String.includes("chat.whatsapp.com")) {
    const linkGrupo = await kira.groupInviteCode(from);
    if (Procurar_String.match(linkGrupo)) {
      return ctx.reply("Hmph! Esse é o link do nosso próprio grupo, baka! N-não vou remover, tá?! Presta atenção antes de me acionar!");
    }
  }

  const dominiosProibidos = readJSON("./arquivos/database/antilink_proibido.json", { links: [] }).links;
  const dominioMsg = extractDomain(PR_String);

  if (dominioMsg && dominiosProibidos.some(d => dominioMsg.includes(d.toLowerCase()))) {
    registrarNumeroSuspeito(sender, dominioMsg);

    if (IS_DELETE) {
      await kira.sendMessage(from, {
        delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
      });
    }

    if (!JSON.stringify(groupMembers).includes(sender)) return;
    await kira.groupParticipantsUpdate(from, [sender], "remove");
    return;
  }

  if (IS_DELETE) {
    setTimeout(async () => {
      await kira.sendMessage(from, {
        delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
      });
    }, 500);
  }

  await kira.groupSettingUpdate(from, "announcement");
  setTimeout(async () => {
    await kira.groupSettingUpdate(from, "not_announcement");
  }, 1200);

  if (!JSON.stringify(groupMembers).includes(sender)) return;
  await kira.groupParticipantsUpdate(from, [sender], "remove");
}

async function handleAntiLinkEasy(ctx) {
  const { kira, info, sender, from, Procurar_String, PR_String,
    isBotGroupAdmins, isGroupAdmins, IS_DELETE, groupMembers } = ctx;

  if (!isBotGroupAdmins || isGroupAdmins || info.key.fromMe) return;

  if (isDominioIgnorado(Procurar_String)) return;

  if (Procurar_String.includes("chat.whatsapp.com")) {
    const linkGrupo = await kira.groupInviteCode(from);
    if (Procurar_String.match(linkGrupo)) {
      return ctx.reply("Hmph! Esse é o link do nosso próprio grupo, idiota! N-não vou deletar, viu?! Olha o que você me faz passar...");
    }
  }

  const dominiosProibidos = readJSON("./arquivos/database/antilink_proibido.json", { links: [] }).links;
  const dominioMsg = extractDomain(PR_String);

  if (dominioMsg && dominiosProibidos.some(d => dominioMsg.includes(d.toLowerCase()))) {
    registrarNumeroSuspeito(sender, dominioMsg);

    if (IS_DELETE) {
      await kira.sendMessage(from, {
        delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
      });
    }

    if (!JSON.stringify(groupMembers).includes(sender)) return;
    await kira.groupParticipantsUpdate(from, [sender], "remove");
    return;
  }

  if (IS_DELETE) {
    setTimeout(async () => {
      await kira.sendMessage(from, {
        delete: { remoteJid: from, fromMe: false, id: info.key.id, participant: sender }
      });
    }, 500);
  }
}

module.exports = { handleAntiLinkHard, handleAntiLinkEasy };